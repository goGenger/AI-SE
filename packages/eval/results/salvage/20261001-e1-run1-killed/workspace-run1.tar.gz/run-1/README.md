# TaskBoard

TaskBoard 任务看板 Web 应用。运行时为 Node.js 22，仅使用 Node 标准库，零运行时依赖。
工程形态为 pnpm 工程，仓库根目录已提交 `pnpm-lock.yaml`。

## 安装

```bash
pnpm install --frozen-lockfile
```

## 启动

```bash
pnpm start
```

- 等价于 `node src/server.js`（见 package.json 的 `start` 脚本）。
- `PORT`：服务端口，默认 `3000`。
- `DATA_DIR`：数据目录，默认 `./data`；数据在进程重启后保留。

自定义端口与数据目录示例：

```bash
PORT=8080 DATA_DIR=./data pnpm start
```

## 测试

```bash
pnpm test
```

- 等价于 `node --test`（Node 内置测试运行器）。

## 构建镜像

```bash
docker build -t taskboard .
```

## 运行镜像

```bash
docker run --rm -p 3000:3000 -v taskboard-data:/data -e DATA_DIR=/data taskboard
```

- `-p 3000:3000`：映射容器 3000 端口到宿主机。
- `-v taskboard-data:/data`：把数据卷挂载到容器的 `/data`，容器重启后数据保留。
- `-e DATA_DIR=/data`：显式设置数据目录为 `/data`（与 Dockerfile 里 `VOLUME /data` 一致）。
