'use strict';

/**
 * Password Hasher.
 *
 * Derives and verifies password digests with node:crypto scrypt and a per-user
 * random salt. The module is stateless and business-agnostic: it knows nothing
 * about users, requests or storage, so it can be reused by the register and
 * login handlers and by the user repository.
 *
 * Guarantees
 *   - Every call to hashPassword() draws a fresh random salt (randomBytes(16));
 *     no global or shared salt is ever used.
 *   - Only derived material leaves the module: algorithm, salt, encoded scrypt
 *     parameters and digest (Base64 by default, Hex on request). The plaintext
 *     password is never returned, stored or logged.
 *   - verifyPassword() recomputes the digest and compares it with
 *     crypto.timingSafeEqual, so a wrong password costs the same as the right
 *     one and no secret-dependent short circuit exists.
 *   - Trust-boundary validation: non-string / empty / oversized passwords and
 *     malformed credentials are rejected (TypeError when hashing, false when
 *     verifying) before or instead of any crypto work, so attacker-shaped input
 *     can never reach the KDF or throw out of the auth path.
 *
 * Credential shape (what hashPassword returns and verifyPassword accepts):
 *   { algo: 'scrypt', salt: <string>, params: <string>, hash: <string> }
 * Stored records use the snake_case projection produced by toPasswordFields():
 *   { password_algo, password_salt, password_params, password_hash }
 */

const crypto = require('node:crypto');

const ALGO = 'scrypt';
const SUPPORTED_ALGOS = Object.freeze(['scrypt']);
const SALT_BYTES = 16;
const KEY_LENGTH = 64;
const MIN_PASSWORD_LENGTH = 1;
const MAX_PASSWORD_LENGTH = 4096;
const DEFAULT_ENCODING = 'base64';
const SUPPORTED_ENCODINGS = Object.freeze(['base64', 'hex']);
const DEFAULT_PARAMS = Object.freeze({ N: 16384, r: 8, p: 1, keylen: KEY_LENGTH });
const MAX_N = 1 << 20;
const MAX_R = 64;
const MAX_P = 16;
const MIN_KEY_LENGTH = 16;
const MAX_KEY_LENGTH = 1024;
const MIN_SALT_BYTES = 8;
const MAX_SALT_BYTES = 128;
const DEFAULT_MAXMEM = 32 * 1024 * 1024;
const PARAMS_TEXT = /^scrypt\$N=(\d+),r=(\d+),p=(\d+),keylen=(\d+)$/;
const HEX_TEXT = /^[0-9a-fA-F]+$/;

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/** Coerce a numeric field, returning null for anything unusable. */
function toInteger(value) {
  if (typeof value === 'number' && Number.isInteger(value)) {
    return value;
  }
  if (typeof value === 'string' && /^[0-9]+$/.test(value.trim())) {
    return Number(value.trim());
  }
  return null;
}

function isPowerOfTwo(value) {
  return typeof value === 'number' && value > 1 && (value & (value - 1)) === 0;
}

/** Validate the password at the trust boundary before any KDF work happens. */
function assertPasswordInput(password, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const maxLength = toInteger(opts.maxPasswordLength) || MAX_PASSWORD_LENGTH;
  if (typeof password !== 'string') {
    throw new TypeError('password must be a string');
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    throw new TypeError('password must not be empty');
  }
  if (password.length > maxLength) {
    throw new TypeError('password exceeds the maximum supported length');
  }
  return password;
}

function normalizeEncoding(encoding) {
  if (encoding === undefined || encoding === null || encoding === '') {
    return DEFAULT_ENCODING;
  }
  const value = String(encoding).toLowerCase();
  if (!SUPPORTED_ENCODINGS.includes(value)) {
    throw new TypeError('encoding must be one of: ' + SUPPORTED_ENCODINGS.join(', '));
  }
  return value;
}

/** Validate and canonicalise the scrypt cost parameters. */
function normalizeParams(params) {
  const source = params === undefined || params === null ? DEFAULT_PARAMS : params;
  if (!isPlainObject(source)) {
    throw new TypeError('scrypt params must be an object');
  }
  const rawN = source.N === undefined ? (source.n === undefined ? source.cost : source.n) : source.N;
  const N = toInteger(rawN);
  const r = toInteger(source.r === undefined ? source.blockSize : source.r);
  const p = toInteger(source.p === undefined ? source.parallelism : source.p);
  const rawKeylen =
    source.keylen === undefined ? (source.keyLength === undefined ? source.dkLen : source.keyLength) : source.keylen;
  const keylen = toInteger(rawKeylen);
  if (!isPowerOfTwo(N) || N > MAX_N) {
    throw new TypeError('scrypt N must be a power of two greater than 1');
  }
  if (r === null || r < 1 || r > MAX_R) {
    throw new TypeError('scrypt r must be a positive integer within range');
  }
  if (p === null || p < 1 || p > MAX_P) {
    throw new TypeError('scrypt p must be a positive integer within range');
  }
  if (keylen === null || keylen < MIN_KEY_LENGTH || keylen > MAX_KEY_LENGTH) {
    throw new TypeError('scrypt keylen must be a positive integer within range');
  }
  return { N, r, p, keylen };
}

/** Encode scrypt cost parameters as a single storable string. */
function formatParams(params) {
  const normalized = normalizeParams(params);
  return (
    'scrypt$N=' + normalized.N + ',r=' + normalized.r + ',p=' + normalized.p + ',keylen=' + normalized.keylen
  );
}

/** Parse an encoded parameter string (or a plain object) into validated numbers. */
function parseParams(params) {
  if (isPlainObject(params)) {
    return normalizeParams(params);
  }
  if (typeof params === 'string') {
    const text = params.trim();
    const match = PARAMS_TEXT.exec(text);
    if (match) {
      return normalizeParams({ N: match[1], r: match[2], p: match[3], keylen: match[4] });
    }
    if (text.startsWith('{')) {
      let parsed = null;
      try {
        parsed = JSON.parse(text);
      } catch (error) {
        throw new TypeError('scrypt params are not valid JSON');
      }
      return normalizeParams(parsed);
    }
  }
  throw new TypeError('scrypt params must be an encoded parameter string or an object');
}

/** Memory ceiling for scrypt: 128 * N * r bytes, with headroom and a floor. */
function maxmemFor(params) {
  return Math.max(DEFAULT_MAXMEM, 256 * params.N * params.r);
}

/** Derive a raw digest for the supplied password, salt and parameters. */
function deriveKey(password, salt, params) {
  return new Promise((resolve, reject) => {
    const kdfOptions = { N: params.N, r: params.r, p: params.p, maxmem: maxmemFor(params) };
    crypto.scrypt(password, salt, params.keylen, kdfOptions, (error, derivedKey) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(derivedKey);
    });
  });
}

/**
 * Hash a password with a fresh per-user random salt.
 *
 * @param {string} password
 * @param {{salt?: Buffer|string, params?: object|string, encoding?: string}} [options]
 * @returns {Promise<{algo: string, salt: string, params: string, hash: string, encoding: string}>}
 */
async function hashPassword(password, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const plaintext = assertPasswordInput(password, opts);
  const params = normalizeParams(opts.params);
  const encoding = normalizeEncoding(opts.encoding);
  let salt;
  if (Buffer.isBuffer(opts.salt)) {
    salt = Buffer.from(opts.salt);
  } else if (typeof opts.salt === 'string' && opts.salt.length > 0) {
    salt = Buffer.from(opts.salt, encoding);
  } else {
    salt = crypto.randomBytes(SALT_BYTES);
  }
  if (salt.length < MIN_SALT_BYTES || salt.length > MAX_SALT_BYTES) {
    throw new TypeError('salt length is outside the supported range');
  }
  const derived = await deriveKey(plaintext, salt, params);
  return {
    algo: ALGO,
    salt: salt.toString(encoding),
    params: formatParams(params),
    hash: derived.toString(encoding),
    encoding,
  };
}

/** Decode a stored field, preferring the encoding whose byte length matches. */
function decodeField(text, expectedLength) {
  if (!isNonEmptyString(text)) {
    return null;
  }
  const raw = text.trim();
  const hexShaped = HEX_TEXT.test(raw) && raw.length % 2 === 0;
  const order = hexShaped ? ['hex', 'base64'] : ['base64'];
  let fallback = null;
  for (const encoding of order) {
    const decoded = Buffer.from(raw, encoding);
    if (decoded.length === 0) {
      continue;
    }
    if (expectedLength === null) {
      if (decoded.length >= MIN_SALT_BYTES && decoded.length <= MAX_SALT_BYTES) {
        return decoded;
      }
      if (fallback === null) {
        fallback = decoded;
      }
      continue;
    }
    if (decoded.length === expectedLength) {
      return decoded;
    }
  }
  return fallback;
}

function pickString(source, names) {
  for (const name of names) {
    const value = source[name];
    if (typeof value === 'string' && value.trim().length > 0) {
      return value;
    }
  }
  return null;
}

function pickParams(source, names) {
  for (const name of names) {
    const value = source[name];
    if (typeof value === 'string' && value.trim().length > 0) {
      return value;
    }
    if (isPlainObject(value)) {
      try {
        return formatParams(value);
      } catch (error) {
        return null;
      }
    }
  }
  return null;
}

/**
 * Read a credential from either the camelCase credential shape or the stored
 * snake_case record fields. Returns null when any required part is missing.
 */
function fromPasswordFields(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  const algo = pickString(source, ['password_algo', 'algo']);
  const salt = pickString(source, ['password_salt', 'salt']);
  const hash = pickString(source, ['password_hash', 'hash', 'digest']);
  const params = pickParams(source, ['password_params', 'params']);
  if (algo === null || salt === null || hash === null || params === null) {
    return null;
  }
  return { algo: algo.toLowerCase(), salt, params, hash };
}

/** True when a record carries a complete, shape-valid password credential. */
function hasPasswordFields(source) {
  return fromPasswordFields(source) !== null;
}

/** Project a credential onto the persisted snake_case column names. */
function toPasswordFields(credential) {
  const stored = fromPasswordFields(credential);
  if (stored === null) {
    throw new TypeError('credential must contain algo, salt, params and hash');
  }
  return {
    password_algo: stored.algo,
    password_salt: stored.salt,
    password_params: stored.params,
    password_hash: stored.hash,
  };
}

/** Constant-time comparison; equal input lengths never short circuit. */
function safeEqual(left, right) {
  const a = Buffer.isBuffer(left) ? left : Buffer.from(String(left), 'utf8');
  const b = Buffer.isBuffer(right) ? right : Buffer.from(String(right), 'utf8');
  if (a.length === b.length) {
    return crypto.timingSafeEqual(a, b);
  }
  // Fold both sides to a fixed-size digest so differing lengths still cost the
  // same, then report inequality without leaking which side was longer.
  const foldedA = crypto.createHash('sha256').update(a).digest();
  const foldedB = crypto.createHash('sha256').update(b).digest();
  crypto.timingSafeEqual(foldedA, foldedB);
  return false;
}

/**
 * Verify a candidate password against a stored credential.
 * Always resolves to a boolean; malformed credentials, unsupported algorithms
 * and non-string passwords are a plain false, never an exception.
 */
async function verifyPassword(password, credential, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const maxLength = toInteger(opts.maxPasswordLength) || MAX_PASSWORD_LENGTH;
  if (typeof password !== 'string' || password.length < MIN_PASSWORD_LENGTH || password.length > maxLength) {
    return false;
  }
  const stored = fromPasswordFields(credential);
  if (stored === null || !SUPPORTED_ALGOS.includes(stored.algo)) {
    return false;
  }
  let params;
  try {
    params = parseParams(stored.params);
  } catch (error) {
    return false;
  }
  const salt = decodeField(stored.salt, null);
  const expected = decodeField(stored.hash, params.keylen);
  if (salt === null || expected === null) {
    return false;
  }
  let derived;
  try {
    derived = await deriveKey(password, salt, params);
  } catch (error) {
    return false;
  }
  return safeEqual(derived, expected);
}

/** Synchronous shape check for stored records; never touches the plaintext. */
function describeHash(credential) {
  const stored = fromPasswordFields(credential);
  if (stored === null) {
    return null;
  }
  return {
    algo: stored.algo,
    saltLength: stored.salt.length,
    hashLength: stored.hash.length,
    params: stored.params,
  };
}

module.exports = {
  ALGO,
  SUPPORTED_ALGOS,
  SALT_BYTES,
  KEY_LENGTH,
  MIN_PASSWORD_LENGTH,
  MAX_PASSWORD_LENGTH,
  DEFAULT_ENCODING,
  SUPPORTED_ENCODINGS,
  DEFAULT_PARAMS,
  hashPassword,
  verifyPassword,
  deriveKey,
  formatParams,
  parseParams,
  normalizeParams,
  toPasswordFields,
  fromPasswordFields,
  hasPasswordFields,
  describeHash,
  assertPasswordInput,
  safeEqual,
};
