'use strict';

/**
 * Secret Store.
 *
 * Resolves the token signing key exactly once per process:
 *   - TOKEN_SECRET from the environment wins when it is a non-empty string.
 *   - Otherwise a cryptographically random key (crypto.randomBytes, 32 bytes) is
 *     generated on first start and persisted under DATA_DIR with restricted
 *     permissions (0600) so a later process start reuses the same key and
 *     previously issued tokens stay verifiable.
 *
 * The raw key material is only reachable through getKeyBuffer() / getKey(), which
 * the Token Service needs. describe()/toJSON() expose metadata only and the
 * module never writes to stdout, so the key can never leak through a log line or
 * a serialised response object.
 *
 * Trust-boundary validation
 *   - DATA_DIR must be a non-empty string without NUL bytes; the secret file name
 *     must be a plain file name (no separators, traversal or surrounding
 *     whitespace) so a caller-supplied name cannot escape DATA_DIR.
 *   - A persisted value must decode to exactly 32 bytes of canonical Base64;
 *     anything else is treated as corrupt and its original bytes are moved to a
 *     timestamped sidecar backup before a fresh key is generated.
 *   - An empty or missing file is a normal first start, not a corruption.
 *
 * Failure handling: a persistence or read failure downgrades to an in-memory key
 * instead of crashing the process, and is surfaced through describe().keyState
 * so startup problems stay observable without breaking token signing.
 */

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const SECRET_FILE_NAME = 'token-secret.key';
const SECRET_ENTRY_KEY = 'token_secret';
const KEY_BYTES = 32;
const KEY_ENCODING = 'base64';
const READ_ENCODING = 'utf8';
const PRIVATE_FILE_MODE = 0o600;
const DATA_DIR_MODE = 0o700;
const SAFE_FILE_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const BASE64_TEXT = /^[A-Za-z0-9+/]+={0,2}$/;
const TEMP_SUFFIX = '.tmp';

class SecretStoreError extends Error {
  constructor(message, options) {
    const opts = options && typeof options === 'object' ? options : {};
    super(message);
    this.name = 'SecretStoreError';
    this.code = typeof opts.code === 'string' ? opts.code : 'SECRET_STORE_ERROR';
    if (opts.cause !== undefined) {
      this.cause = opts.cause;
    }
  }
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/** Resolve (and validate) DATA_DIR; it must never be empty and never contain NUL. */
function resolveDataDir(dataDir) {
  if (!isNonEmptyString(dataDir)) {
    throw new SecretStoreError('DATA_DIR must be a non-empty path string', { code: 'INVALID_DATA_DIR' });
  }
  const absolute = path.resolve(dataDir);
  if (absolute.length === 0 || absolute.includes('\u0000')) {
    throw new SecretStoreError('DATA_DIR contains an invalid character', { code: 'INVALID_DATA_DIR' });
  }
  return absolute;
}

/** Validate the secret file name so it can never traverse outside DATA_DIR. */
function sanitizeSecretFileName(fileName) {
  const candidate = fileName === undefined || fileName === null ? SECRET_FILE_NAME : fileName;
  if (typeof candidate !== 'string') {
    throw new SecretStoreError('Secret file name must be a string', { code: 'INVALID_FILE_NAME' });
  }
  if (candidate !== candidate.trim() || candidate.length === 0) {
    throw new SecretStoreError('Secret file name must not have surrounding whitespace', {
      code: 'INVALID_FILE_NAME',
    });
  }
  if (!SAFE_FILE_NAME.test(candidate) || candidate === '.' || candidate === '..') {
    throw new SecretStoreError('Secret file name must be a plain file name without path separators', {
      code: 'INVALID_FILE_NAME',
    });
  }
  return candidate;
}

/** Generate a fresh 32-byte random signing key. */
function generateSecret() {
  return crypto.randomBytes(KEY_BYTES);
}

/** Encode a raw key as the canonical Base64 text persisted on disk. */
function encodeSecret(buffer) {
  return Buffer.from(buffer).toString(KEY_ENCODING);
}

/** Strictly decode a persisted 32-byte Base64 key; null when unusable. */
function decodeSecret(text) {
  if (typeof text !== 'string') {
    return null;
  }
  const raw = text.trim();
  if (raw.length === 0 || !BASE64_TEXT.test(raw)) {
    return null;
  }
  let decoded;
  try {
    decoded = Buffer.from(raw, KEY_ENCODING);
  } catch (error) {
    return null;
  }
  if (decoded.length !== KEY_BYTES) {
    return null;
  }
  if (decoded.toString(KEY_ENCODING) !== raw) {
    return null;
  }
  return decoded;
}

/** Read the env-provided secret; any non-empty string is accepted as UTF-8 bytes. */
function secretFromEnvironment(env) {
  if (!isPlainObject(env)) {
    return null;
  }
  const raw = env.TOKEN_SECRET;
  if (typeof raw !== 'string' || raw.length === 0) {
    return null;
  }
  return Buffer.from(raw, 'utf8');
}

/** Atomically persist the key with 0600 permissions (temp file + rename + chmod). */
function writeSecretFileSync(filePath, buffer) {
  if (!isNonEmptyString(filePath)) {
    throw new SecretStoreError('Secret file path must be a non-empty string', { code: 'INVALID_FILE_PATH' });
  }
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    throw new SecretStoreError('Secret key material must be a non-empty Buffer', { code: 'INVALID_KEY' });
  }
  const directory = path.dirname(filePath);
  const base = path.basename(filePath);
  const tempPath = path.join(
    directory,
    '.' + base + '.' + process.pid + '.' + crypto.randomBytes(6).toString('hex') + TEMP_SUFFIX
  );
  let fd = null;
  try {
    fs.mkdirSync(directory, { recursive: true, mode: DATA_DIR_MODE });
    fd = fs.openSync(tempPath, 'wx', PRIVATE_FILE_MODE);
    fs.writeFileSync(fd, encodeSecret(buffer) + '\n', { encoding: READ_ENCODING });
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;
    fs.renameSync(tempPath, filePath);
  } catch (error) {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch (closeError) {
        // ignore
      }
    }
    try {
      fs.unlinkSync(tempPath);
    } catch (unlinkError) {
      // The temp file was never created or the rename already moved it.
    }
    throw new SecretStoreError('Failed to persist the token signing key', {
      code: 'SECRET_WRITE_FAILED',
      cause: error,
    });
  }
  try {
    fs.chmodSync(filePath, PRIVATE_FILE_MODE);
  } catch (error) {
    // Some filesystems ignore chmod; the mode requested at open() still applies.
  }
  return filePath;
}

/** Move a corrupt key file aside so its original bytes are never silently lost. */
function backupCorruptFile(filePath) {
  const backupPath = filePath + '.' + Date.now() + '.corrupt';
  try {
    fs.renameSync(filePath, backupPath);
    return backupPath;
  } catch (error) {
    return null;
  }
}

/**
 * Secret Store.
 *
 * Options:
 *   dataDir?      path to DATA_DIR (defaults to process.env.DATA_DIR or ./data)
 *   fileName?     plain file name inside DATA_DIR (default token-secret.key)
 *   tokenSecret?  explicit secret override (non-empty string)
 *   env?          environment object (default process.env)
 *   autoload?     resolve the key on construction (default true)
 */
class SecretStore {
  constructor(options) {
    const opts = isPlainObject(options) ? options : {};
    this.env = isPlainObject(opts.env) ? opts.env : process.env;
    let rawDataDir;
    if (opts.dataDir !== undefined && opts.dataDir !== null) {
      // An explicitly supplied DATA_DIR is validated: an empty or malformed
      // value is a trust-boundary error, never a silent default.
      rawDataDir = opts.dataDir;
    } else {
      const envDataDir = this.env.DATA_DIR;
      rawDataDir = typeof envDataDir === 'string' && envDataDir.trim().length > 0 ? envDataDir : './data';
    }
    this.dataDir = resolveDataDir(rawDataDir);
    this.fileName = sanitizeSecretFileName(opts.fileName);
    this.filePath = path.join(this.dataDir, this.fileName);
    this.explicitSecret = typeof opts.tokenSecret === 'string' ? opts.tokenSecret : null;
    this.state = {
      source: 'unresolved',
      fileExists: false,
      corrupt: false,
      backupPath: null,
      persisted: false,
      created: false,
      keyState: 'unresolved',
    };
    this._key = null;
    if (opts.autoload !== false) {
      this.resolve();
    }
  }

  /** Resolve the signing key from, in order: explicit secret, env, file, fresh key. */
  resolve() {
    const explicitBuffer = isNonEmptyString(this.explicitSecret)
      ? Buffer.from(this.explicitSecret, 'utf8')
      : null;
    const envBuffer = explicitBuffer === null ? secretFromEnvironment(this.env) : null;
    const supplied = explicitBuffer !== null ? explicitBuffer : envBuffer;
    if (supplied !== null) {
      this._key = supplied;
      this.state.source = 'environment';
      this.state.fileExists = fs.existsSync(this.filePath);
      this.state.corrupt = false;
      this.state.backupPath = null;
      this.state.persisted = false;
      this.state.created = false;
      this.state.keyState = 'environment';
      return this.getKeyBuffer();
    }

    const fromFile = this.readSecretFile();
    if (fromFile !== null) {
      this._key = fromFile;
      this.state.source = 'file';
      this.state.keyState = 'file';
      return this.getKeyBuffer();
    }

    const generated = generateSecret();
    this._key = generated;
    this.state.source = 'generated';
    this.state.created = true;
    this.state.persisted = this.persistSecret(generated);
    this.state.keyState = this.state.persisted ? 'generated' : 'generated_memory_only';
    return this.getKeyBuffer();
  }

  /** Re-resolve the key (used by tests that simulate a process restart). */
  reload() {
    return this.resolve();
  }

  /** Load and validate the persisted key file; null when absent, empty or unusable. */
  readSecretFile() {
    let text;
    try {
      text = fs.readFileSync(this.filePath, READ_ENCODING);
    } catch (error) {
      if (error && error.code === 'ENOENT') {
        this.state.fileExists = false;
        this.state.corrupt = false;
        this.state.backupPath = null;
        return null;
      }
      this.state.keyState = 'read_failed';
      return null;
    }
    this.state.fileExists = true;
    if (typeof text === 'string' && text.trim().length === 0) {
      // First start wrote nothing yet: treat as absent, not as corruption.
      return null;
    }
    const decoded = decodeSecret(text);
    if (decoded === null) {
      this.state.corrupt = true;
      this.state.backupPath = backupCorruptFile(this.filePath);
      return null;
    }
    this.state.corrupt = false;
    this.state.backupPath = null;
    return decoded;
  }

  /** Persist the key with restricted permissions; returns true on success. */
  persistSecret(buffer) {
    try {
      writeSecretFileSync(this.filePath, buffer);
      this.state.fileExists = true;
      // NB: the corrupt flag is deliberately preserved so describe() still
      // reports that a previously unreadable key file was recovered.
      return true;
    } catch (error) {
      return false;
    }
  }

  /** True when a key has been resolved. */
  isReady() {
    return Buffer.isBuffer(this._key) && this._key.length > 0;
  }

  /** Raw HMAC key bytes (copy); the only way to obtain key material. */
  getKeyBuffer() {
    if (!this.isReady()) {
      this.resolve();
    }
    return Buffer.from(this._key);
  }

  /** Canonical Base64 encoding of the key (the persisted on-disk form). */
  getKey() {
    return encodeSecret(this.getKeyBuffer());
  }

  /** Key length in bytes. */
  getKeyLength() {
    return this.getKeyBuffer().length;
  }

  /** True when the key came from the environment rather than DATA_DIR. */
  isFromEnvironment() {
    return this.state.source === 'environment';
  }

  /** Secret-free metadata: never contains key material. */
  describe() {
    return {
      source: this.state.source,
      keyState: this.state.keyState,
      keyBytes: this.isReady() ? this._key.length : 0,
      fileName: this.fileName,
      dataDir: this.dataDir,
      filePath: this.filePath,
      fileExists: this.state.fileExists,
      corrupt: this.state.corrupt,
      corruptBackup: this.state.backupPath === null ? null : path.basename(this.state.backupPath),
      persisted: this.state.persisted,
      created: this.state.created,
    };
  }

  /** JSON.stringify(store) yields metadata only, never the key. */
  toJSON() {
    return this.describe();
  }
}

let defaultStore = null;

/** Create an isolated secret store (one per test or per injected service). */
function createSecretStore(options) {
  return new SecretStore(options);
}

/** Process-wide secret store, built lazily from process.env on first use. */
function getSecretStore() {
  if (defaultStore === null) {
    defaultStore = new SecretStore({});
  }
  return defaultStore;
}

/** Inject a pre-built store (used by the app bootstrap). */
function setSecretStore(store) {
  defaultStore = store && typeof store.getKeyBuffer === 'function' ? store : null;
  return defaultStore;
}

/** Forget the memoised store so a fresh environment can be picked up (tests). */
function resetSecretStore() {
  defaultStore = null;
}

module.exports = {
  SECRET_FILE_NAME,
  SECRET_ENTRY_KEY,
  KEY_BYTES,
  KEY_ENCODING,
  PRIVATE_FILE_MODE,
  DATA_DIR_MODE,
  SecretStoreError,
  SecretStore,
  createSecretStore,
  getSecretStore,
  setSecretStore,
  resetSecretStore,
  resolveDataDir,
  sanitizeSecretFileName,
  generateSecret,
  encodeSecret,
  decodeSecret,
  secretFromEnvironment,
  writeSecretFileSync,
  backupCorruptFile,
};
