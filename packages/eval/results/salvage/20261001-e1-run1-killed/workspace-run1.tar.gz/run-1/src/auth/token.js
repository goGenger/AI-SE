'use strict';

/**
 * Token Service.
 *
 * Issues and verifies self-contained, unforgeable tokens:
 *
 *   token = base64url(payloadJson) + '.' + base64url(HMAC-SHA256(header + '.' + payload))
 *
 * The signed message is the exact encoded payload segment, so every byte matters.
 * The payload carries the subject (user id), the issued-at time and an optional
 * expiry:
 *   { sub: <user id>, iat: <unix seconds>, exp?: <unix seconds> }
 *
 * Guarantees
 *   - Signing uses HMAC-SHA256 with the Secret Store key, which may come from
 *     TOKEN_SECRET or from the key persisted under DATA_DIR (see secretStore.js).
 *   - Verification splits on the '.' delimiter, recomputes the HMAC over the
 *     received payload segment and compares it with crypto.timingSafeEqual. A
 *     token altered in any single character, or truncated, therefore fails.
 *   - Verification NEVER throws: missing, non-string, malformed, oversized,
 *     wrongly signed, structurally invalid or expired tokens all return the
 *     unified failure result { ok: false, code, reason } so an attacker-shaped
 *     header can never turn into a 5xx.
 *   - The signing key and any signature material never appear in a token, a
 *     return value considered client-safe, or a log line. The raw key is only
 *     read from the Secret Store and used inside sign/verify.
 *
 * Trust-boundary validation: subject must be a non-empty, bounded string; exp/
 * ttl must be finite numbers; the key must be a non-empty Buffer. Bad input is
 * rejected with a semantic failure result, never an exception.
 */

const crypto = require('node:crypto');

const { getSecretStore } = require('./secretStore.js');

const ALGORITHM = 'HS256';
const DIGEST = 'sha256';
const DELIMITER = '.';
const SEGMENT_COUNT = 2;
const URL_SEGMENT = /^[A-Za-z0-9_-]+$/;
const MAX_TOKEN_LENGTH = 4096;
const MAX_SUBJECT_LENGTH = 128;
const DEFAULT_TTL_SECONDS = 7 * 24 * 60 * 60;

/** Non-throwing failure codes returned by verifyToken(). */
const TOKEN_FAILURES = Object.freeze({
  MISSING: 'MISSING_TOKEN',
  MALFORMED: 'MALFORMED_TOKEN',
  INVALID_SIGNATURE: 'INVALID_SIGNATURE',
  EXPIRED: 'EXPIRED_TOKEN',
});

/** Non-throwing failure codes returned by issueToken(). */
const ISSUE_FAILURES = Object.freeze({
  NO_KEY: 'MISSING_SIGNING_KEY',
  BAD_SUBJECT: 'INVALID_SUBJECT',
  BAD_EXP: 'INVALID_EXPIRY',
});

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/** Base64url encode a Buffer or UTF-8 string. */
function base64urlEncode(value) {
  const buffer = Buffer.isBuffer(value) ? value : Buffer.from(String(value), 'utf8');
  return buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** Base64url decode; strict about the alphabet and returns null when invalid. */
function base64urlDecode(text) {
  if (typeof text !== 'string' || text.length === 0 || !URL_SEGMENT.test(text)) {
    return null;
  }
  const padded = text.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (text.length % 4)) % 4);
  try {
    return Buffer.from(padded, 'base64');
  } catch (error) {
    return null;
  }
}

/**
 * Canonical base64url decode: additionally requires that re-encoding the decoded
 * bytes reproduces the exact input segment.
 *
 * A trailing base64url character carries spare bits, so otherwise two different
 * strings can decode to identical bytes (e.g. "...A" and "...B"). Enforcing the
 * canonical form makes every single-character change - including the last one -
 * observable, which is exactly what "a token altered in any one character is
 * invalid" (AC-12) requires. Non-canonical input returns null.
 */
function base64urlDecodeCanonical(text) {
  const buffer = base64urlDecode(text);
  if (buffer === null) {
    return null;
  }
  if (base64urlEncode(buffer) !== text) {
    return null;
  }
  return buffer;
}

/** Decode a base64url JSON payload into a plain object, or null when unusable. */
function decodePayload(segment) {
  const buffer = base64urlDecode(segment);
  if (buffer === null || buffer.length === 0) {
    return null;
  }
  let parsed;
  try {
    parsed = JSON.parse(buffer.toString('utf8'));
  } catch (error) {
    return null;
  }
  return isPlainObject(parsed) ? parsed : null;
}

/** Constant-time comparison that never short circuits on a length mismatch. */
function safeEqualBytes(left, right) {
  const a = Buffer.isBuffer(left) ? left : Buffer.from(String(left), 'utf8');
  const b = Buffer.isBuffer(right) ? right : Buffer.from(String(right), 'utf8');
  if (a.length === b.length) {
    return crypto.timingSafeEqual(a, b);
  }
  const foldedA = crypto.createHash(DIGEST).update(a).digest();
  const foldedB = crypto.createHash(DIGEST).update(b).digest();
  crypto.timingSafeEqual(foldedA, foldedB);
  return false;
}

/** Resolve the signing key Buffer from an injected store or the process store. */
function resolveKey(provideKey) {
  if (Buffer.isBuffer(provideKey)) {
    return provideKey.length > 0 ? provideKey : null;
  }
  if (provideKey && typeof provideKey.getKeyBuffer === 'function') {
    const key = provideKey.getKeyBuffer();
    return Buffer.isBuffer(key) && key.length > 0 ? key : null;
  }
  const store = getSecretStore();
  const key = store.getKeyBuffer();
  return Buffer.isBuffer(key) && key.length > 0 ? key : null;
}

/** Compute the raw HMAC-SHA256 signature over a message. */
function computeSignature(message, key) {
  return crypto.createHmac(DIGEST, key).update(message, 'utf8').digest();
}

function toUnixSeconds(value) {
  if (value instanceof Date) {
    return Math.floor(value.getTime() / 1000);
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return Math.floor(value);
  }
  return null;
}

/**
 * Build the canonical payload for a subject.
 * Returns null when the input cannot produce a valid payload.
 */
function buildPayload(input, now) {
  const options = isPlainObject(input) ? input : {};
  const subject = options.subject !== undefined ? options.subject : options.userId;
  if (typeof subject !== 'string' || subject.length === 0 || subject.length > MAX_SUBJECT_LENGTH) {
    return null;
  }
  const issuedAt = toUnixSeconds(options.now) || now;
  const payload = { sub: subject, iat: issuedAt };
  let exp = null;
  if (options.exp !== undefined && options.exp !== null) {
    exp = toUnixSeconds(options.exp);
    if (exp === null) {
      return null;
    }
  } else if (options.ttlSeconds !== undefined && options.ttlSeconds !== null) {
    const ttl = toUnixSeconds(options.ttlSeconds);
    if (ttl === null || ttl <= 0) {
      return null;
    }
    exp = issuedAt + ttl;
  } else if (options.expiresIn !== undefined && options.expiresIn !== null) {
    const ttl = toUnixSeconds(options.expiresIn);
    if (ttl === null || ttl <= 0) {
      return null;
    }
    exp = issuedAt + ttl;
  } else if (options.noExpiry !== true) {
    exp = issuedAt + DEFAULT_TTL_SECONDS;
  }
  if (exp !== null) {
    payload.exp = exp;
  }
  return payload;
}

/**
 * Sign a payload object. Returns the token string, or null when the payload is
 * not JSON-serialisable; a missing key throws so a misconfigured deployment fails
 * loudly at startup rather than silently issuing unsigned tokens.
 */
function sign(payload, options) {
  const opts = isPlainObject(options) ? options : {};
  const key = resolveKey(opts.key || opts.secretStore);
  if (key === null) {
    throw new Error('Token signing key is unavailable');
  }
  const segment = base64urlEncode(JSON.stringify(payload));
  const signature = computeSignature(segment, key);
  return segment + DELIMITER + base64urlEncode(signature);
}

/**
 * Issue a signed token for a subject.
 *
 * @param {{subject?: string, userId?: string, iat?: number, exp?: number,
 *          ttlSeconds?: number, expiresIn?: number, noExpiry?: boolean}} input
 * @param {{key?: Buffer|object, secretStore?: object}} [options]
 * @returns {{ok: true, token: string, payload: object} | {ok: false, code: string}}
 */
function issueToken(input, options) {
  const opts = isPlainObject(options) ? options : {};
  const nowSeconds = toUnixSeconds(opts.now) || Math.floor(Date.now() / 1000);
  const payload = buildPayload(input, nowSeconds);
  if (payload === null) {
    const raw = isPlainObject(input) ? input : {};
    const subject = raw.subject !== undefined ? raw.subject : raw.userId;
    const code =
      typeof subject !== 'string' || subject.length === 0 ? ISSUE_FAILURES.BAD_SUBJECT : ISSUE_FAILURES.BAD_EXP;
    return { ok: false, code };
  }
  let key;
  try {
    key = resolveKey(opts.key || opts.secretStore);
  } catch (error) {
    return { ok: false, code: ISSUE_FAILURES.NO_KEY };
  }
  if (key === null) {
    return { ok: false, code: ISSUE_FAILURES.NO_KEY };
  }
  const segment = base64urlEncode(JSON.stringify(payload));
  const signature = computeSignature(segment, key);
  return { ok: true, token: segment + DELIMITER + base64urlEncode(signature), payload };
}

/** Build the unified failure result (never contains token or key material). */
function failure(code) {
  return { ok: false, code };
}

/** Extract the caller identity from a verified payload. */
function getSubject(payload) {
  if (!isPlainObject(payload)) {
    return null;
  }
  if (isNonEmptyString(payload.sub)) {
    return payload.sub;
  }
  return isNonEmptyString(payload.userId) ? payload.userId : null;
}

/**
 * Verify a token and return a unified result object.
 *
 * @param {unknown} token
 * @param {{key?: Buffer|object, secretStore?: object, now?: number,
 *          clockSkewSeconds?: number, requireExp?: boolean}} [options]
 * @returns {{ok: true, payload: object, subject: string, expiresAt: number|null}
 *          | {ok: false, code: string}}
 */
function verifyToken(token, options) {
  const opts = isPlainObject(options) ? options : {};
  try {
    if (typeof token !== 'string' || token.length === 0) {
      return failure(TOKEN_FAILURES.MISSING);
    }
    if (token.length > MAX_TOKEN_LENGTH) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    const segments = token.split(DELIMITER);
    if (segments.length !== SEGMENT_COUNT) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    const [payloadSegment, signatureSegment] = segments;
    if (payloadSegment.length === 0 || signatureSegment.length === 0) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    if (!URL_SEGMENT.test(signatureSegment)) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    if (base64urlDecodeCanonical(payloadSegment) === null) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    const payload = decodePayload(payloadSegment);
    if (payload === null) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    const subject = getSubject(payload);
    if (subject === null || subject.length > MAX_SUBJECT_LENGTH) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    let key;
    try {
      key = resolveKey(opts.key || opts.secretStore);
    } catch (error) {
      return failure(TOKEN_FAILURES.INVALID_SIGNATURE);
    }
    if (key === null) {
      return failure(TOKEN_FAILURES.INVALID_SIGNATURE);
    }
    // Compare the canonical encoded signature segment against the signature
    // recomputed over the received payload segment. Comparing the encoded text
    // (not decoded bytes) makes every single-character change - including the
    // last one, whose base64url spare bits would otherwise decode identically -
    // an INVALID_SIGNATURE, and keeps the check constant-time via safeEqualBytes.
    const expectedSignatureSegment = base64urlEncode(computeSignature(payloadSegment, key));
    if (!safeEqualBytes(expectedSignatureSegment, signatureSegment)) {
      return failure(TOKEN_FAILURES.INVALID_SIGNATURE);
    }
    const nowSeconds = toUnixSeconds(opts.now) || Math.floor(Date.now() / 1000);
    const skew = toUnixSeconds(opts.clockSkewSeconds) || 0;
    const expiresAt = typeof payload.exp === 'number' && Number.isFinite(payload.exp) ? payload.exp : null;
    if (opts.requireExp === true && expiresAt === null) {
      return failure(TOKEN_FAILURES.MALFORMED);
    }
    if (expiresAt !== null && nowSeconds - skew >= expiresAt) {
      return failure(TOKEN_FAILURES.EXPIRED);
    }
    return { ok: true, payload, subject, expiresAt };
  } catch (error) {
    // Verification must never propagate an exception to the HTTP layer.
    return failure(TOKEN_FAILURES.MALFORMED);
  }
}

/** Boolean convenience wrapper around verifyToken(). */
function isValidToken(token, options) {
  return verifyToken(token, options).ok === true;
}

/**
 * Parse "Authorization: Bearer <token>". Returns the token or null; never throws
 * and never echoes the header value.
 */
function extractBearerToken(headerValue) {
  if (typeof headerValue !== 'string') {
    return null;
  }
  const match = /^\s*Bearer\s+(\S+)\s*$/.exec(headerValue);
  if (!match) {
    return null;
  }
  return match[1];
}

/** Short, non-reversible fingerprint for diagnostics; never the token itself. */
function tokenFingerprint(token) {
  if (typeof token !== 'string' || token.length === 0) {
    return null;
  }
  return crypto.createHash(DIGEST).update(token, 'utf8').digest('hex').slice(0, 12);
}

module.exports = {
  ALGORITHM,
  DIGEST,
  DELIMITER,
  MAX_TOKEN_LENGTH,
  MAX_SUBJECT_LENGTH,
  DEFAULT_TTL_SECONDS,
  TOKEN_FAILURES,
  ISSUE_FAILURES,
  base64urlEncode,
  base64urlDecode,
  base64urlDecodeCanonical,
  decodePayload,
  computeSignature,
  safeEqualBytes,
  buildPayload,
  sign,
  issueToken,
  verifyToken,
  isValidToken,
  getSubject,
  extractBearerToken,
  tokenFingerprint,
};
