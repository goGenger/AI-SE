'use strict';

/**
 * Config Loader (runtime configuration resolver).
 *
 * Reads process configuration exactly once at startup and exposes resolved,
 * immutable values to every other component:
 *   PORT         -> integer, default 3000 (missing OR invalid falls back to 3000)
 *   HOST         -> listen address, default '0.0.0.0' so container port mapping is reachable
 *   DATA_DIR     -> path, container default '/data', local default './data'
 *   TOKEN_SECRET -> optional string, null when unset
 *
 * Trust-boundary notes: PORT and DATA_DIR are untrusted input.
 *   - PORT is parsed strictly; anything that is not an integer in [0, 65535]
 *     falls back to the default 3000 instead of crashing the process.
 *   - DATA_DIR is created recursively and then write-probe verified so the
 *     process can always read and write its data directory. Every storage path
 *     is derived from DATA_DIR by the persistence layer, never hardcoded here.
 *
 * Side effect (intended): DATA_DIR is created and verified during load so the
 * process never crashes on a missing or nested data directory.
 */

const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_PORT = 3000;
const DEFAULT_HOST = '0.0.0.0';
const DEFAULT_DATA_DIR = './data';
const CONTAINER_DATA_DIR = '/data';
const DEFAULT_CONTAINER_DATA_DIR = CONTAINER_DATA_DIR;
const DEFAULT_LOG_LEVEL = 'info';
const DEFAULT_NODE_ENV = 'development';
const MIN_PORT = 0;
const MAX_PORT = 65535;
const LOG_LEVELS = Object.freeze(['debug', 'info', 'warn', 'error', 'fatal']);

class ConfigError extends Error {
  constructor(message, variable) {
    super(message);
    this.name = 'ConfigError';
    this.variable = variable;
  }
}

/**
 * Parse PORT from the environment. Missing, empty, non-numeric or out-of-range
 * values fall back to DEFAULT_PORT (3000) so a bad value can never crash the
 * process or bind a bogus port.
 */
function readPort(env) {
  const raw = env.PORT;
  if (raw === undefined || raw === null) {
    return DEFAULT_PORT;
  }
  const text = String(raw).trim();
  if (text === '') {
    return DEFAULT_PORT;
  }
  if (!/^[0-9]+$/.test(text)) {
    return DEFAULT_PORT;
  }
  const port = Number(text);
  if (!Number.isInteger(port) || port < MIN_PORT || port > MAX_PORT) {
    return DEFAULT_PORT;
  }
  return port;
}

/**
 * Detect whether the process is explicitly marked as running in a container.
 * Used only to pick the DATA_DIR default: '/data' when the marker is set,
 * './data' otherwise. An explicit DATA_DIR always wins.
 *
 * This is an explicit opt-in (TASKKBOARD_CONTAINER / CONTAINER) rather than an
 * implicit filesystem probe, so the unset default is deterministic and always
 * matches the documented './data' contract; a container deployment sets either
 * DATA_DIR=/data or CONTAINER=1 (the shipped Dockerfile sets DATA_DIR=/data).
 */
function isContainerRuntime(env) {
  if (env && typeof env.TASKKBOARD_CONTAINER === 'string' && env.TASKKBOARD_CONTAINER.trim() !== '') {
    return /^(1|true|yes|on)$/i.test(env.TASKKBOARD_CONTAINER.trim());
  }
  if (env && typeof env.CONTAINER === 'string' && env.CONTAINER.trim() !== '') {
    return true;
  }
  return false;
}

/**
 * Resolve DATA_DIR. An explicit, non-empty DATA_DIR wins; otherwise the default
 * is './data' (or '/data' when the container marker is set). The returned
 * `absolute` path is what every storage component derives its file paths from.
 */
function readDataDir(env) {
  const raw = env.DATA_DIR;
  const text = raw === undefined || raw === null ? '' : String(raw).trim();
  const setting = text === '' ? (isContainerRuntime(env) ? CONTAINER_DATA_DIR : DEFAULT_DATA_DIR) : text;
  return { setting, absolute: path.resolve(setting) };
}

function readTokenSecret(env) {
  const raw = env.TOKEN_SECRET;
  if (typeof raw !== 'string' || raw.length === 0) {
    return { value: null, source: 'unset' };
  }
  return { value: raw, source: 'environment' };
}

function readHost(env) {
  const raw = env.HOST;
  if (typeof raw !== 'string' || raw.trim() === '') {
    return undefined;
  }
  return raw.trim();
}

function readLogLevel(env) {
  const raw = env.LOG_LEVEL;
  if (typeof raw !== 'string') {
    return DEFAULT_LOG_LEVEL;
  }
  const level = raw.trim().toLowerCase();
  return LOG_LEVELS.includes(level) ? level : DEFAULT_LOG_LEVEL;
}

function readNodeEnv(env) {
  const raw = env.NODE_ENV;
  if (typeof raw !== 'string' || raw.trim() === '') {
    return DEFAULT_NODE_ENV;
  }
  return raw.trim();
}

/**
 * Create DATA_DIR recursively and prove the process can read and write it by
 * writing and removing a probe file. Throws ConfigError when the directory
 * cannot be created or is not writable.
 */
function ensureDataDirWritable(dataDir) {
  try {
    fs.mkdirSync(dataDir.absolute, { recursive: true });
  } catch (error) {
    throw new ConfigError('DATA_DIR could not be created: ' + dataDir.absolute, 'DATA_DIR');
  }
  const probe = path.join(dataDir.absolute, '.write-probe-' + process.pid + '-' + Date.now());
  try {
    fs.writeFileSync(probe, 'ok');
    fs.readFileSync(probe);
  } catch (error) {
    throw new ConfigError('DATA_DIR is not writable: ' + dataDir.absolute, 'DATA_DIR');
  } finally {
    try {
      fs.unlinkSync(probe);
    } catch (error) {
      /* best effort cleanup */
    }
  }
}

/**
 * Safe, secret-free projection of the configuration, suitable for logging.
 * Never includes the TOKEN_SECRET value.
 */
function describeConfig(config) {
  return {
    port: config.port,
    dataDir: config.dataDir,
    dataDirSetting: config.dataDirSetting,
    host: config.host === undefined ? null : config.host,
    hasTokenSecret: config.hasTokenSecret === true,
    tokenSecretSource: config.tokenSecretSource,
    logLevel: config.logLevel,
    nodeEnv: config.nodeEnv,
  };
}

/** Read configuration once, create DATA_DIR recursively and verify it is writable. */
function loadConfig(env = process.env) {
  const port = readPort(env);
  const dataDir = readDataDir(env);
  const secret = readTokenSecret(env);

  ensureDataDirWritable(dataDir);

  const config = {
    port,
    dataDir: dataDir.absolute,
    dataDirSetting: dataDir.setting,
    tokenSecret: secret.value,
    hasTokenSecret: secret.value !== null,
    tokenSecretSource: secret.source,
    host: readHost(env),
    logLevel: readLogLevel(env),
    nodeEnv: readNodeEnv(env),
  };

  // JSON.stringify(config) must never leak the signing key into logs or responses.
  Object.defineProperty(config, 'toJSON', {
    enumerable: false,
    configurable: false,
    writable: false,
    value: () => describeConfig(config),
  });

  return Object.freeze(config);
}

let cachedConfig = null;

/** Startup-time singleton: reads process.env exactly once per process. */
function getConfig() {
  if (cachedConfig === null) {
    cachedConfig = loadConfig(process.env);
  }
  return cachedConfig;
}

/** Test helper: forget the memoised configuration. */
function resetConfigCache() {
  cachedConfig = null;
}

module.exports = {
  DEFAULT_PORT,
  DEFAULT_HOST,
  DEFAULT_DATA_DIR,
  CONTAINER_DATA_DIR,
  DEFAULT_CONTAINER_DATA_DIR,
  DEFAULT_LOG_LEVEL,
  MIN_PORT,
  MAX_PORT,
  LOG_LEVELS,
  ConfigError,
  isContainerRuntime,
  ensureDataDirWritable,
  describeConfig,
  loadConfig,
  getConfig,
  resetConfigCache,
};
