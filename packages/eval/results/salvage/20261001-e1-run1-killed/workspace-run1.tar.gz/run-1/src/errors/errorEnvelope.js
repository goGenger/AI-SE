'use strict';

/**
 * Error Envelope / Error Handler.
 *
 * Single source of truth for failure responses:
 *   body = { "error": { "code": "<code>", "message": "<text>" } }
 *
 * Only the codes below ever appear in a client response. Anything unexpected
 * (including uncaught handler exceptions) collapses to INTERNAL_ERROR / 500
 * with a fixed message, so stack traces and internal detail never leak.
 */

const CODES = Object.freeze({
  VALIDATION_ERROR: { status: 400, message: 'Request validation failed' },
  TITLE_INVALID: { status: 400, message: 'Task title is invalid' },
  DATE_INVALID: { status: 400, message: 'Due date is invalid' },
  UNKNOWN_FIELD: { status: 400, message: 'Request body contains an unknown field' },
  UNAUTHORIZED: { status: 401, message: 'Authentication is required' },
  INVALID_CREDENTIALS: { status: 401, message: 'Invalid credentials' },
  NOT_FOUND: { status: 404, message: 'Resource not found' },
  USERNAME_TAKEN: { status: 409, message: 'Username is already taken' },
  INTERNAL_ERROR: { status: 500, message: 'Internal server error' },
});

/** Codes permitted by the PRD error-code set. */
const API_ERROR_CODES = Object.freeze([
  'VALIDATION_ERROR',
  'TITLE_INVALID',
  'DATE_INVALID',
  'UNKNOWN_FIELD',
  'UNAUTHORIZED',
  'INVALID_CREDENTIALS',
  'USERNAME_TAKEN',
  'NOT_FOUND',
]);

/** Name -> code string map so call sites never repeat an error-code literal. */
const ERROR_CODES = Object.freeze(
  Object.keys(CODES).reduce((acc, name) => {
    acc[name] = name;
    return acc;
  }, {})
);

const MAX_MESSAGE_LENGTH = 200;
const SAFE_TEXT = /^[^\u0000-\u001f<>]{1,200}$/;

function isErrorCode(code) {
  return typeof code === 'string' && Object.prototype.hasOwnProperty.call(CODES, code);
}

function safeMessage(code, message) {
  const fallback = isErrorCode(code) ? CODES[code].message : CODES.INTERNAL_ERROR.message;
  if (typeof message !== 'string') {
    return fallback;
  }
  const trimmed = message.trim();
  if (trimmed.length === 0 || trimmed.length > MAX_MESSAGE_LENGTH || !SAFE_TEXT.test(trimmed)) {
    return fallback;
  }
  return trimmed;
}

/** Expected, client-visible application error. */
class AppError extends Error {
  constructor(code, message, options) {
    const opts = options && typeof options === 'object' ? options : {};
    const resolved = isErrorCode(code) ? code : 'INTERNAL_ERROR';
    super(safeMessage(resolved, message));
    this.name = 'AppError';
    this.code = resolved;
    this.status = CODES[resolved].status;
    this.expose = true;
    if (opts.cause !== undefined) {
      this.cause = opts.cause;
    }
    this.details = undefined;
  }

  toEnvelope() {
    return { error: { code: this.code, message: this.message } };
  }

  static isAppError(value) {
    return value instanceof AppError;
  }
}

/**
 * Map any thrown value to { status, body }.
 * Unknown values never reveal their message or stack.
 */
function toErrorEnvelope(error) {
  if (AppError.isAppError(error)) {
    return { status: error.status, body: { error: { code: error.code, message: error.message } } };
  }
  const code = isErrorCode(error && error.code) && CODES[error.code].status < 500 ? error.code : 'INTERNAL_ERROR';
  if (code === 'INTERNAL_ERROR') {
    return {
      status: CODES.INTERNAL_ERROR.status,
      body: { error: { code: 'INTERNAL_ERROR', message: CODES.INTERNAL_ERROR.message } },
    };
  }
  return { status: CODES[code].status, body: { error: { code, message: CODES[code].message } } };
}

function buildErrorBody(code, message) {
  const resolved = isErrorCode(code) ? code : 'INTERNAL_ERROR';
  return { error: { code: resolved, message: safeMessage(resolved, message) } };
}

module.exports = {
  CODES,
  API_ERROR_CODES,
  ERROR_CODES,
  MAX_MESSAGE_LENGTH,
  isErrorCode,
  safeMessage,
  AppError,
  toErrorEnvelope,
  buildErrorBody,
};
