'use strict';

/**
 * Centralised error handling entry point.
 *
 * Re-exports the error-envelope primitives (the single source of truth for the
 * response shape, the allowed code set and the code->HTTP status map) and adds
 * `handleError`, the one function the HTTP layer calls to turn any thrown value
 * into a safe { status, body } pair.
 *
 * `handleError` never returns a stack trace, an unknown code or a message the
 * caller did not explicitly mark as client-safe:
 *   - AppError            -> its own status + { error: { code, message } }
 *   - known code < 500    -> mapped status + that code with a fixed message
 *   - anything else       -> 500 INTERNAL_ERROR with a fixed message
 */

const {
  CODES,
  API_ERROR_CODES,
  ERROR_CODES,
  AppError,
  toErrorEnvelope,
  buildErrorBody,
  isErrorCode,
  safeMessage,
} = require('./errorEnvelope.js');

/** Map any thrown value (Error, AppError, string, null, ...) to { status, body }. */
function handleError(error) {
  return toErrorEnvelope(error);
}

/**
 * Build an AppError for a known code, guaranteeing the code is inside the
 * declared set (anything else collapses to INTERNAL_ERROR).
 */
function errorFor(code, message) {
  return new AppError(code, message);
}

module.exports = {
  // Envelope primitives (single source of truth).
  CODES,
  API_ERROR_CODES,
  ERROR_CODES,
  ERROR_CODES,
  AppError,
  toErrorEnvelope,
  buildErrorBody,
  isErrorCode,
  safeMessage,
  // Centralised handling helpers.
  handleError,
  errorFor,
};
