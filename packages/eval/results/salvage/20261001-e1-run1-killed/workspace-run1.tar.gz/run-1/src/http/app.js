'use strict';

/**
 * Router / HTTP Adapter assembly + top-level request error trap.
 *
 * Health handlers are wired here because they are part of the service skeleton
 * and must run before any authentication logic. Business handlers for this
 * slice are attached by later tasks through addRoute()/addProtectedRoute() or
 * the exported router, without relocating wiring.
 */

const { createRouter } = require('./router.js');
const { sendJson, sendError, sendNoContent, isSent } = require('./respond.js');
const { parseUrl, parseQuery } = require('./request.js');
const { handleError, ERROR_CODES } = require('../errors/index.js');
const { logger: defaultLogger, describeError } = require('../logger.js');

const HEALTH_PATHS = Object.freeze(['/healthz', '/health', '/ready']);

// Auth guard module. Imported after the health paths on purpose: health
// routes are wired before any auth logic (AC-01 / TR-3).
const { authMiddleware: defaultAuthMiddleware, requiresAuth } = require('./authMiddleware.js');

/**
 * Pick the auth guard for an app instance: an explicit function injected through
 * options wins, an explicit null/false disables guarding, and otherwise the
 * default bearer middleware from authMiddleware.js protects the API surface.
 */
function resolveAuthGuard(options, fallback) {
  const opts = options && typeof options === 'object' ? options : {};
  if (typeof opts.authMiddleware === 'function') {
    return opts.authMiddleware;
  }
  if (opts.authMiddleware === null || opts.authMiddleware === false) {
    return null;
  }
  return typeof fallback === 'function' ? fallback : null;
}

function createApp(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const logger = opts.logger || defaultLogger;
  const config = opts.config || null;
  const router = opts.router || createRouter();
  const services = opts.services && typeof opts.services === 'object' ? opts.services : {};
  const onError = typeof opts.onError === 'function' ? opts.onError : null;
  // Bearer auth guard: an injected middleware wins, null/false disables it,
  // otherwise the default bearer middleware from authMiddleware.js is used.
  const authGuard = resolveAuthGuard(opts, defaultAuthMiddleware);
  // Explicit opt-in: guard every route, not only the /api surface.
  const authAllowPublic = opts.authAllowPublic === true;

  /** Route context handed to handlers; later tasks attach auth state here. */
  function createContext(req, res, match) {
    const url = parseUrl(req);
    return {
      req,
      res,
      config,
      services,
      router,
      logger,
      url,
      method: String(req.method || 'GET').toUpperCase(),
      pathname: match.pathname,
      params: match.params,
      query: {},
      state: {},
      auth: null,
      user: null,
    };
  }

  // Health endpoints: 200 {"status":"ok"}, no auth, no store access (AC-01).
  for (const path of HEALTH_PATHS) {
    router.addPublic('GET', path, (ctx) => {
      sendJson(ctx.res, 200, { status: 'ok' });
    });
  }

  function handlePreflight(req, res) {
    const method = String(req.method || '').toUpperCase();
    if (method !== 'OPTIONS') {
      return false;
    }
    res.setHeader('Allow', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    sendNoContent(res);
    return true;
  }

  async function runMiddleware(ctx, chain) {
    for (const step of chain) {
      // eslint-disable-next-line no-await-in-loop
      await step(ctx);
      if (isSent(ctx.res)) {
        return false;
      }
    }
    return true;
  }

  async function dispatch(req, res) {
    const method = String(req.method || 'GET').toUpperCase();
    const url = parseUrl(req);
    const match = router.resolve(method, url.pathname);

    const ctx = createContext(req, res, match);
    ctx.query = parseQuery(url.pathname + url.search);

    // Auth first, fail closed: every route outside the public set (and the whole
    // /api surface, so future task routes are covered) passes the guard before
    // any handler runs. A rejected request has its 401 written and never reaches
    // the handler below.
    const needsAuth = authAllowPublic === true || requiresAuth(url.pathname, match.route);
    const chain = [];
    if (needsAuth && typeof authGuard === 'function') {
      chain.push(authGuard);
    }
    if (match.route !== null) {
      for (const step of match.route.middleware) {
        chain.push(step);
      }
    }

    const proceed = await runMiddleware(ctx, chain);
    if (!proceed) {
      return;
    }
    if (match.route === null) {
      sendError(res, 404, ERROR_CODES.NOT_FOUND);
      return;
    }
    await match.route.handler(ctx);
  }

  /** Top-level trap: any thrown/rejected value becomes the 500 envelope. */
  function handleRequest(req, res) {
    res.on('error', () => {
      /* client socket errors must not bubble up */
    });
    let settled = false;
    const finish = (error) => {
      if (settled) {
        return;
      }
      settled = true;
      if (error === null) {
        return;
      }
      const detail = describeError(error);
      logger.error('request failed', {
        method: req && req.method,
        url: req && req.url,
        error: detail,
      });
      if (typeof onError === 'function') {
        try {
          onError(error, req, res);
        } catch (hookError) {
          /* the error hook must never rethrow into the trap */
        }
      }
      const mapped = handleError(error);
      if (isSent(res)) {
        if (typeof res.destroy === 'function') {
          res.destroy();
        }
        return;
      }
      try {
        sendJson(res, mapped.status, mapped.body);
      } catch (writeError) {
        if (typeof res.destroy === 'function') {
          res.destroy();
        }
      }
    };

    if (handlePreflight(req, res)) {
      finish(null);
      return;
    }

    Promise.resolve()
      .then(() => dispatch(req, res))
      .then(() => finish(null))
      .catch((error) => finish(error));
  }

  return {
    router,
    handleRequest,
    dispatch,
    healthPaths: HEALTH_PATHS,
    addRoute: (method, path, handler, routeOptions) => router.addPublic(method, path, handler, routeOptions),
    addProtectedRoute: (method, path, handler, routeOptions) => router.addProtected(method, path, handler, routeOptions),
    mount: (prefix, subRouter) => router.mount(prefix, subRouter),
    listRoutes: () => router.list(),
  };
}

module.exports = { HEALTH_PATHS, createApp };
