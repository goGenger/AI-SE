'use strict';

/**
 * Bearer Auth Middleware + protected route mount point.
 *
 * Role in the request pipeline (TR-9 / AC-11, AC-12, AC-13)
 *   - Runs before any protected handler. The Router / HTTP Adapter mounts it for
 *     every route whose path is outside the public set (`/`, `/healthz`,
 *     `/health`, `/ready`, `/api/register`, `/api/login`) and for the whole
 *     `/api/*` surface, so a task route added by a later slice is guarded by
 *     default.
 *   - Parses `Authorization: Bearer <token>` strictly: a missing header, a wrong
 *     scheme or scheme casing, an empty token or trailing junk all fail closed
 *     with 401 UNAUTHORIZED.
 *   - Verifies the token through the Token Service (HMAC-SHA256 recomputation
 *     plus crypto.timingSafeEqual inside verifyToken). A token whose signature
 *     does not match, including any single-character change, or a truncated
 *     token, is rejected with 401 UNAUTHORIZED.
 *   - On success it parses the user id from the payload, resolves the identity
 *     through the user repository and attaches it to the request context
 *     (`ctx.user`, `ctx.auth`, `ctx.userId`, `req.user`, `ctx.state.user`) for
 *     the downstream handler.
 *
 * Hard guarantee: this middleware never produces a 5xx. Every failure path -
 * malformed header, bad signature, unknown user, missing service, or an
 * unexpected internal exception - is answered by writing the standard error
 * envelope `{ "error": { "code": "UNAUTHORIZED", "message": "..." } }` with
 * HTTP 401, so attacker-shaped input cannot turn into a server error.
 *
 * Secrets: the raw token, the signing key and any hash material are never
 * logged. Only non-reversible reason codes are recorded, at debug level.
 */

const { buildErrorBody, ERROR_CODES } = require('../errors/errorEnvelope.js');
const { sendJson, isSent } = require('./respond.js');
const { headerValue } = require('./request.js');
const { normalizePathname } = require('./router.js');
const { extractBearerToken, verifyToken } = require('../auth/token.js');
const { getSecretStore } = require('../auth/secretStore.js');

const AUTH_SCHEME = 'Bearer';
const UNAUTHORIZED = ERROR_CODES.UNAUTHORIZED;
const UNAUTHORIZED_MESSAGE = 'Authentication is required';
const MAX_HEADER_LENGTH = 8192;

/** Paths that never pass through the auth middleware (PRD / TR-9). */
const PUBLIC_PATHS = Object.freeze([
  '/',
  '/healthz',
  '/health',
  '/ready',
  '/api/register',
  '/api/login',
]);

/** API surface prefix: guarded by default, so future task routes are protected. */
const API_PREFIX = '/api';

/** Repository property names accepted from ctx.services / factory options. */
const REPOSITORY_NAMES = Object.freeze(['userRepository', 'users', 'userRepo', 'usersRepository']);

/** Repository lookup methods accepted when resolving the caller identity. */
const LOOKUP_METHODS = Object.freeze(['findById', 'getById', 'findUserById']);

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/** Normalise a pathname for the public/API checks (trailing slash, empty). */
function canonicalPath(pathname) {
  return normalizePathname(typeof pathname === 'string' ? pathname : '');
}

/** True for the exact public paths that must stay unauthenticated. */
function isPublicPath(pathname) {
  return PUBLIC_PATHS.indexOf(canonicalPath(pathname)) !== -1;
}

/** True for the guarded `/api` surface (`/api` and `/api/...`). */
function isApiPath(pathname) {
  const value = canonicalPath(pathname);
  return value === API_PREFIX || value.indexOf(API_PREFIX + '/') === 0;
}

/**
 * Decide whether the auth middleware must run for a request.
 *
 *   public path                       -> never
 *   route explicitly flagged auth     -> always
 *   any other /api path               -> yes (deny by default)
 *   other explicitly public route     -> no
 *   unmatched non-API path            -> no (the router answers 404)
 *
 * @param {string} pathname request path
 * @param {{auth?: boolean}|null} [route] matched route, when any
 * @returns {boolean}
 */
function requiresAuth(pathname, route) {
  if (isPublicPath(pathname)) {
    return false;
  }
  if (route && route.auth === true) {
    return true;
  }
  if (isApiPath(pathname)) {
    return true;
  }
  if (route && route.auth === false) {
    return false;
  }
  return false;
}

/** A repository is usable when it can look a user up by id. */
function isUsableUserRepository(candidate) {
  if (!candidate) {
    return false;
  }
  return LOOKUP_METHODS.some((name) => typeof candidate[name] === 'function');
}

/** Pick the first usable repository from a services/options container. */
function pickUserRepository(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  for (const name of REPOSITORY_NAMES) {
    if (isUsableUserRepository(source[name])) {
      return source[name];
    }
  }
  return null;
}

/** Resolve the user repository from the request context first, then options. */
function resolveUserRepository(ctx, options) {
  const fromContext = pickUserRepository(ctx && ctx.services);
  if (fromContext !== null) {
    return fromContext;
  }
  if (options) {
    const fromOptionsServices = pickUserRepository(options.services);
    if (fromOptionsServices !== null) {
      return fromOptionsServices;
    }
    return pickUserRepository(options);
  }
  return null;
}

/** Resolve the signing-key store from the context/options, else the process one. */
function resolveSecretStore(ctx, options) {
  const services = ctx && ctx.services;
  if (isPlainObject(services) && services.secretStore && typeof services.secretStore.getKeyBuffer === 'function') {
    return services.secretStore;
  }
  if (options && options.secretStore && typeof options.secretStore.getKeyBuffer === 'function') {
    return options.secretStore;
  }
  return getSecretStore();
}

/** Look a user record up by id through the first available repository method. */
async function findUserById(repository, id) {
  for (const name of LOOKUP_METHODS) {
    if (typeof repository[name] === 'function') {
      const record = await repository[name](id);
      if (isPlainObject(record)) {
        return record;
      }
    }
  }
  return null;
}

/** Project the resolved record onto the identity attached to the request. */
function toIdentity(record, fallbackId) {
  const id = isNonEmptyString(record.id) ? record.id : fallbackId;
  const username = typeof record.username === 'string' ? record.username : null;
  return { id, username };
}

/** Record a non-reversible rejection reason; never throws, never logs secrets. */
function logRejection(ctx, reason) {
  const logger = ctx && ctx.logger;
  if (!logger || typeof logger.debug !== 'function') {
    return;
  }
  try {
    logger.debug('auth middleware rejected request', {
      reason,
      method: ctx && ctx.method,
      pathname: ctx && ctx.pathname,
    });
  } catch (error) {
    // Logging must never influence the response.
  }
}

/** Write the 401 UNAUTHORIZED envelope. Never throws; returns false. */
function respondUnauthorized(ctx, reason) {
  const res = ctx && ctx.res;
  logRejection(ctx, reason);
  if (!res || isSent(res)) {
    return false;
  }
  try {
    sendJson(res, 401, buildErrorBody(UNAUTHORIZED, UNAUTHORIZED_MESSAGE), {
      'WWW-Authenticate': AUTH_SCHEME,
    });
  } catch (error) {
    // A write failure must not escalate into a 5xx; drop the socket instead.
    if (typeof res.destroy === 'function') {
      try {
        res.destroy();
      } catch (destroyError) {
        // ignore
      }
    }
  }
  return false;
}

/** Attach the verified caller identity to the request context. */
function attachIdentity(ctx, identity, verified) {
  const auth = {
    userId: identity.id,
    username: identity.username,
    payload: verified.payload,
    expiresAt: verified.expiresAt === undefined ? null : verified.expiresAt,
  };
  const user = { id: identity.id, username: identity.username };
  ctx.user = user;
  ctx.auth = auth;
  ctx.userId = identity.id;
  if (isPlainObject(ctx.state)) {
    ctx.state.user = user;
    ctx.state.auth = auth;
  }
  if (ctx.req) {
    ctx.req.user = user;
    ctx.req.auth = auth;
  }
}

/**
 * Resolve the caller identity for a verified token.
 * Returns null when the token is valid but the subject cannot be trusted.
 */
async function resolveIdentity(ctx, options, verified) {
  const subject = isNonEmptyString(verified.subject) ? verified.subject : null;
  if (subject === null) {
    return null;
  }
  const repository = resolveUserRepository(ctx, options);
  if (repository === null) {
    // No user store is wired into this app instance. The token is still
    // HMAC-verified, so fall back to the signed identity rather than failing a
    // legitimate request; a repository, when present, stays authoritative.
    const payload = isPlainObject(verified.payload) ? verified.payload : {};
    let username = null;
    if (isNonEmptyString(payload.username)) {
      username = payload.username;
    } else if (isNonEmptyString(payload.name)) {
      username = payload.name;
    }
    return { id: subject, username };
  }
  const record = await findUserById(repository, subject);
  if (record === null) {
    // A valid signature for a user that no longer exists is not an identity.
    return null;
  }
  return toIdentity(record, subject);
}

/**
 * Build a bearer auth middleware bound to optional services.
 *
 * @param {object} [options]
 * @param {object} [options.services]       services container (userRepository/secretStore)
 * @param {object} [options.userRepository] repository override
 * @param {object} [options.secretStore]    secret store override
 * @returns {(ctx: object) => Promise<void>} middleware
 */
function createAuthMiddleware(options) {
  const opts = isPlainObject(options) ? options : {};
  return async function authMiddleware(ctx) {
    if (!ctx || !ctx.res) {
      return;
    }
    try {
      const header = headerValue(ctx.req, 'authorization');
      if (typeof header === 'string' && header.length > MAX_HEADER_LENGTH) {
        respondUnauthorized(ctx, 'header_too_long');
        return;
      }
      const token = extractBearerToken(header);
      if (token === null) {
        respondUnauthorized(ctx, 'bearer_missing_or_malformed');
        return;
      }
      const secretStore = resolveSecretStore(ctx, opts);
      const verified = verifyToken(token, { secretStore });
      if (!verified || verified.ok !== true) {
        respondUnauthorized(ctx, 'token_' + String((verified && verified.code) || 'invalid'));
        return;
      }
      const identity = await resolveIdentity(ctx, opts, verified);
      if (identity === null) {
        respondUnauthorized(ctx, 'unknown_identity');
        return;
      }
      attachIdentity(ctx, identity, verified);
    } catch (error) {
      // Security-critical: an unexpected fault stays a 401, never a 5xx.
      respondUnauthorized(ctx, 'internal_error');
    }
  };
}

/** Default middleware: resolves services per request from the context. */
const authMiddleware = createAuthMiddleware();

module.exports = {
  AUTH_SCHEME,
  UNAUTHORIZED,
  UNAUTHORIZED_MESSAGE,
  MAX_HEADER_LENGTH,
  PUBLIC_PATHS,
  API_PREFIX,
  REPOSITORY_NAMES,
  LOOKUP_METHODS,
  canonicalPath,
  isPublicPath,
  isApiPath,
  requiresAuth,
  isUsableUserRepository,
  pickUserRepository,
  resolveUserRepository,
  resolveSecretStore,
  findUserById,
  toIdentity,
  attachIdentity,
  resolveIdentity,
  respondUnauthorized,
  createAuthMiddleware,
  authMiddleware,
};
