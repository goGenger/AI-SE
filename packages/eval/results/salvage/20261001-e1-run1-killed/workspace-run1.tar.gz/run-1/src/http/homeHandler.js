'use strict';

/**
 * Home Page Renderer + route (FR-8.1 / TS-01 / AC-21).
 *
 * GET / returns HTTP 200 with a complete, statically server-rendered HTML
 * document (Content-Type: text/html; charset=utf-8). The four contract
 * elements required by the PRD are present in the FIRST response body:
 *
 *   data-testid="home-title"
 *   data-testid="task-list"
 *   data-testid="search-input"
 *   data-testid="new-task-button"
 *
 * Trust boundary: the page is assembled from a fixed, in-module template and
 * never interpolates request input (no path params, no query string, no
 * headers). Because nothing from the request is echoed, the response can never
 * be turned into an injection/XSS sink, and there is no client-side script
 * injection or asynchronous rendering involved - the HTML is complete on the
 * wire in the very first server response.
 *
 * The route is registered as a public route: GET / never passes through the
 * bearer guard (it is listed in the middleware public path set), so an
 * unauthenticated visitor still receives the shell page.
 */

const { sendHtml } = require('./respond.js');

const HOME_PATH = '/';
const HOME_METHOD = 'GET';
const HOME_CONTENT_TYPE = 'text/html; charset=utf-8';

/** The four data-testid values the PRD pins the home page to. */
const HOME_TESTIDS = Object.freeze({
  title: 'home-title',
  taskList: 'task-list',
  searchInput: 'search-input',
  newTaskButton: 'new-task-button',
});

/** The empty-state placeholder shown inside the task list container. */
const HOME_EMPTY_STATE = '\u6682\u65e0\u4efb\u52a1\uff0c\u70b9\u51fb\u300c\u65b0\u5efa\u4efb\u52a1\u300d\u5f00\u59cb\u3002';

/**
 * Render the home page document.
 *
 * The body is a constant template: fully deterministic, dependency-free and
 * safe to send from any request context.
 */
function renderHomePage() {
  return [
    '<!DOCTYPE html>',
    '<html lang="zh-CN">',
    '<head>',
    '  <meta charset="utf-8">',
    '  <meta name="viewport" content="width=device-width, initial-scale=1">',
    '  <title>TaskBoard</title>',
    '</head>',
    '<body>',
    '  <header class="app-header">',
    '    <h1 class="home-title" data-testid="home-title">TaskBoard</h1>',
    '    <p class="app-subtitle">Create, search, update and delete your tasks.</p>',
    '  </header>',
    '  <main class="app-main">',
    '    <section class="toolbar" aria-label="toolbar">',
    '      <form class="search-form" method="get" action="/" role="search">',
    '        <label class="search-label" for="search-input">Search tasks</label>',
    '        <input class="search-input" id="search-input" name="q" type="search"',
    '          data-testid="search-input" placeholder="Search by title" autocomplete="off" maxlength="100">',
    '      </form>',
    '      <button class="new-task-button" type="button" data-testid="new-task-button">New task</button>',
    '    </section>',
    '    <section class="task-list-section" data-testid="task-list" aria-label="task list">',
    '      <h2 class="task-list-title">Tasks</h2>',
    '      <ul class="task-list-items"></ul>',
    '      <p class="task-list-empty" data-testid="task-list-empty-state">' + HOME_EMPTY_STATE + '</p>',
    '    </section>',
    '  </main>',
    '</body>',
    '</html>',
    '',
  ].join('\n');
}

/** Handle GET /: write the server-rendered document (200 text/html). */
function handleHome(ctx) {
  if (!ctx || !ctx.res) {
    throw new Error('home handler requires an http request context');
  }
  const html = renderHomePage();
  sendHtml(ctx.res, 200, html);
  return { html };
}

/**
 * Register GET / on an app or router.
 * Prefers the public route surface (addPublic/addRoute) so the page is served
 * without authentication; falls back to a bare router's get().
 */
function homeRoutes(target) {
  if (!target || typeof target !== 'object') {
    throw new TypeError('homeRoutes requires an app or router');
  }
  if (typeof target.addPublic === 'function') {
    target.addPublic(HOME_METHOD, HOME_PATH, handleHome);
    return handleHome;
  }
  if (typeof target.addRoute === 'function') {
    target.addRoute(HOME_METHOD, HOME_PATH, handleHome);
    return handleHome;
  }
  if (typeof target.get === 'function') {
    target.get(HOME_PATH, handleHome);
    return handleHome;
  }
  throw new TypeError('homeRoutes target must expose addPublic, addRoute or get');
}

module.exports = {
  HOME_PATH,
  HOME_METHOD,
  HOME_CONTENT_TYPE,
  HOME_TESTIDS,
  HOME_EMPTY_STATE,
  renderHomePage,
  handleHome,
  homeRoutes,
};
