'use strict';

/**
 * Login Handler (POST /api/login).
 *
 * Implements FR-2 at the HTTP edge:
 *   - parse the request body and validate it at the trust boundary: only the
 *     fields username and password are accepted (any other field -> 400
 *     UNKNOWN_FIELD) while malformed JSON, a non-object payload or a missing /
 *     non-string username or password -> 400 VALIDATION_ERROR
 *   - look the user up through the case-insensitive normalised key
 *     (usernameLower) exposed by the user repository
 *   - verify the submitted password against the stored salted scrypt digest with
 *     crypto.timingSafeEqual inside verifyPassword, so comparison never short
 *     circuits on a secret-dependent byte
 *   - on success answer 200 with { "token", "user": { "id", "username" } } where
 *     the token is a self-contained HMAC-SHA256 signed string issued by the Token
 *     Service and the signing key comes from the persisted Secret Store (so a
 *     restarted process still mints verifiable tokens)
 *   - on failure answer 401 INVALID_CREDENTIALS for BOTH an unknown user and a
 *     wrong password, with an identical body, so the endpoint never reveals
 *     whether an account exists; when the user is unknown a dummy verification
 *     is still executed so the response time does not leak existence either
 *
 * The handler is deliberately transport-focused and storage-agnostic: the user
 * repository, the password verifier and the secret store are resolved from the
 * request context (ctx.services) or from the factory options, so tests can
 * inject fast doubles without touching global state. No password, hash or
 * signing key is ever echoed in a response or written to a log line.
 */

const crypto = require('node:crypto');

const { AppError, ERROR_CODES } = require('../errors/errorEnvelope.js');
const { MAX_BODY_BYTES } = require('./request.js');
const { sendJson } = require('./respond.js');
const {
  parseJsonBody,
  assertJsonObject,
  assertAllowedFields,
  ALLOWED_LOGIN_FIELDS,
} = require('../validate.js');
const { verifyPassword, hashPassword, toPasswordFields } = require('../auth/password.js');
const { issueToken } = require('../auth/token.js');
const { getSecretStore } = require('../auth/secretStore.js');

const LOGIN_PATH = '/api/login';
const LOGIN_METHOD = 'POST';
const INVALID_CREDENTIALS = ERROR_CODES.INVALID_CREDENTIALS;
const VALIDATION_ERROR = ERROR_CODES.VALIDATION_ERROR;
const INTERNAL_ERROR = ERROR_CODES.INTERNAL_ERROR;

const hasOwn = Object.prototype.hasOwnProperty;

/** Repository property names accepted from ctx.services / factory options. */
const REPOSITORY_NAMES = Object.freeze(['userRepository', 'users', 'userRepo', 'usersRepository']);

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

/** Read one own field, ignoring anything inherited from the prototype chain. */
function readOwnField(body, name) {
  return hasOwn.call(body, name) ? body[name] : undefined;
}

/** A repository usable for login must be able to resolve a stored user record. */
function isUsableAuthRepository(candidate) {
  return (
    Boolean(candidate) &&
    (typeof candidate.findRecordForAuth === 'function' || typeof candidate.findByUsername === 'function')
  );
}

/** Pick the first usable login repository from a services/options container. */
function pickRepository(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  for (const name of REPOSITORY_NAMES) {
    const candidate = source[name];
    if (isUsableAuthRepository(candidate)) {
      return candidate;
    }
  }
  return null;
}

/** Resolve the user repository from the request context first, then options. */
function resolveUserRepository(ctx, options) {
  const fromContext = pickRepository(ctx && ctx.services);
  if (fromContext !== null) {
    return fromContext;
  }
  return pickRepository(options);
}

/**
 * Validate a login body: strict field whitelist plus the presence of string
 * username and password fields. Shape problems are 400 VALIDATION_ERROR; the
 * credential rules themselves are intentionally NOT enforced here, so a
 * well-formed but wrong credential is always answered by the 401 path.
 */
function validateLoginCredentials(body) {
  const value = assertJsonObject(body);
  assertAllowedFields(value, ALLOWED_LOGIN_FIELDS);
  const username = readOwnField(value, 'username');
  const password = readOwnField(value, 'password');
  if (typeof username !== 'string' || typeof password !== 'string') {
    throw new AppError(VALIDATION_ERROR, 'Request body must contain username and password');
  }
  return { username, password };
}

/** Resolve how a candidate password is checked against a stored credential. */
function resolveVerifyPassword(options) {
  if (options && typeof options.verifyPassword === 'function') {
    return options.verifyPassword;
  }
  if (options && isPlainObject(options.hasher) && typeof options.hasher.verify === 'function') {
    const hasher = options.hasher;
    return (password, credential) => hasher.verify(password, credential);
  }
  return verifyPassword;
}

/**
 * Lazily built credential used only to spend the same scrypt work when the
 * username does not exist, so unknown users and wrong passwords stay
 * indistinguishable by timing. Cached for the process lifetime.
 */
let dummyCredentialPromise = null;

function getDummyCredential() {
  if (dummyCredentialPromise === null) {
    dummyCredentialPromise = hashPassword(crypto.randomBytes(24).toString('hex'))
      .then((credential) => toPasswordFields(credential))
      .catch(() => null);
  }
  return dummyCredentialPromise;
}

/** Run a verification and collapse any internal failure to a plain boolean. */
async function safeVerify(verify, password, credential) {
  try {
    return (await verify(password, credential)) === true;
  } catch (error) {
    return false;
  }
}

/** Resolve the persisted (or injected) signing-key store. */
function resolveSecretStore(ctx, options) {
  if (options && typeof options.secretStore === 'object' && options.secretStore !== null) {
    if (typeof options.secretStore.getKeyBuffer === 'function') {
      return options.secretStore;
    }
  }
  const services = ctx && ctx.services;
  if (isPlainObject(services) && typeof services.secretStore === 'object' && services.secretStore !== null) {
    if (typeof services.secretStore.getKeyBuffer === 'function') {
      return services.secretStore;
    }
  }
  return getSecretStore();
}

/** Issue the signed session token, honouring an injected signer when present. */
async function issueSessionToken(user, ctx, options) {
  if (options && typeof options.signToken === 'function') {
    const token = await options.signToken(user);
    if (typeof token === 'string' && token.length > 0) {
      return token;
    }
    throw new AppError(INTERNAL_ERROR);
  }
  const secretStore = resolveSecretStore(ctx, options);
  const issued = issueToken({ subject: user.id }, { secretStore });
  if (!issued || issued.ok !== true || typeof issued.token !== 'string' || issued.token.length === 0) {
    throw new AppError(INTERNAL_ERROR);
  }
  return issued.token;
}

/** Case-insensitive lookup returning the stored record (with credential fields). */
async function lookupUserRecord(repository, username) {
  const record =
    typeof repository.findRecordForAuth === 'function'
      ? await repository.findRecordForAuth(username)
      : await repository.findByUsername(username);
  return isPlainObject(record) ? record : null;
}

/**
 * Handle one login request. Writes the response itself (200 or an error
 * envelope thrown as an AppError) and returns { token, user } for tests.
 *
 * @param {object} ctx request context (req, res, services, ...)
 * @param {object} [options]
 * @returns {Promise<{token: string, user: {id: string, username: string}}>}
 */
async function handleLogin(ctx, options) {
  const opts = isPlainObject(options) ? options : {};
  if (!ctx || !ctx.req || !ctx.res) {
    throw new Error('login handler requires an http request context');
  }

  // Trust boundary first: parse and validate before any service lookup, so a
  // malformed body or unknown field is always a client 400 and never a 5xx.
  const body = await parseJsonBody(ctx.req, MAX_BODY_BYTES);
  const { username, password } = validateLoginCredentials(body);

  const repository = resolveUserRepository(ctx, opts);
  if (repository === null) {
    throw new Error('login handler requires a configured user repository');
  }

  const verify = resolveVerifyPassword(opts);
  const record = await lookupUserRecord(repository, username);

  let authentic = false;
  if (record !== null) {
    authentic = await safeVerify(verify, password, record);
  } else {
    const dummy = opts.dummyCredential !== undefined ? opts.dummyCredential : await getDummyCredential();
    if (isPlainObject(dummy)) {
      await safeVerify(verify, password, dummy);
    }
  }

  // Unknown user and wrong password share one identical failure response.
  if (!authentic) {
    throw new AppError(INVALID_CREDENTIALS);
  }

  const user = { id: record.id, username: record.username };
  if (typeof user.id !== 'string' || user.id.length === 0 || typeof user.username !== 'string') {
    throw new AppError(INTERNAL_ERROR);
  }

  const token = await issueSessionToken(user, ctx, opts);
  sendJson(ctx.res, 200, { token, user });
  return { token, user };
}

/** Build a bound login handler. */
function createLoginHandler(options) {
  const opts = isPlainObject(options) ? options : {};
  return function loginHandler(ctx) {
    return handleLogin(ctx, opts);
  };
}

/**
 * Register POST /api/login on an app or router.
 * Accepts the app surface (addPublic/addRoute) or a bare router (post).
 */
function loginRoutes(target, options) {
  if (!target || typeof target !== 'object') {
    throw new TypeError('loginRoutes requires an app or router');
  }
  const handler = createLoginHandler(options);
  if (typeof target.addPublic === 'function') {
    target.addPublic(LOGIN_METHOD, LOGIN_PATH, handler);
    return handler;
  }
  if (typeof target.addRoute === 'function') {
    target.addRoute(LOGIN_METHOD, LOGIN_PATH, handler);
    return handler;
  }
  if (typeof target.post === 'function') {
    target.post(LOGIN_PATH, handler);
    return handler;
  }
  throw new TypeError('loginRoutes target must expose addPublic, addRoute or post');
}

module.exports = {
  LOGIN_PATH,
  LOGIN_METHOD,
  INVALID_CREDENTIALS,
  VALIDATION_ERROR,
  INTERNAL_ERROR,
  REPOSITORY_NAMES,
  isUsableAuthRepository,
  pickRepository,
  resolveUserRepository,
  validateLoginCredentials,
  resolveVerifyPassword,
  getDummyCredential,
  resolveSecretStore,
  issueSessionToken,
  lookupUserRecord,
  handleLogin,
  createLoginHandler,
  loginRoutes,
};
