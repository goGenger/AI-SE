'use strict';

/**
 * Register Handler (POST /api/register).
 *
 * Implements FR-1 at the HTTP edge:
 *   - parse the request body and validate it at the trust boundary
 *     (only username and password; any other field -> 400 UNKNOWN_FIELD,
 *      malformed JSON, bad username or bad password -> 400 VALIDATION_ERROR)
 *   - derive the password credential with scrypt and a fresh random salt
 *     BEFORE the user is created (no plaintext ever leaves this module)
 *   - let the user repository perform the duplicate check and the insert inside
 *     its single mutex critical section, so concurrent registrations of the same
 *     username resolve to exactly one 201 and the rest 409 USERNAME_TAKEN with
 *     no 500 and no partial writes
 *   - answer 201 with { "user": { "id", "username" } } using the originally
 *     submitted username and never any password/hash material
 *
 * The handler is deliberately transport-focused and storage-agnostic: the user
 * repository is resolved from the request context (ctx.services) or from the
 * factory options, so tests can inject a fast stub without touching global state.
 */

const { AppError, ERROR_CODES } = require('../errors/errorEnvelope.js');
const { MAX_BODY_BYTES } = require('./request.js');
const { sendJson } = require('./respond.js');
const { parseJsonBody, validateRegisterInput } = require('../validate.js');
const { hashPassword, toPasswordFields } = require('../auth/password.js');

const REGISTER_PATH = '/api/register';
const REGISTER_METHOD = 'POST';
const USERNAME_TAKEN = ERROR_CODES.USERNAME_TAKEN;
const VALIDATION_ERROR = ERROR_CODES.VALIDATION_ERROR;

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isUsableRepository(candidate) {
  return Boolean(candidate) && typeof candidate.createUser === 'function';
}

/** Pick the first usable repository from a services/options container. */
function pickRepository(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  const candidates = [source.userRepository, source.users, source.userRepo, source.usersRepository];
  for (const candidate of candidates) {
    if (isUsableRepository(candidate)) {
      return candidate;
    }
  }
  return null;
}

/** Resolve the user repository from the request context first, then options. */
function resolveUserRepository(ctx, options) {
  const fromContext = pickRepository(ctx && ctx.services);
  if (fromContext !== null) {
    return fromContext;
  }
  return pickRepository(options);
}

/** Default credential derivation: scrypt with a fresh per-user random salt. */
async function defaultDeriveCredential(password) {
  const credential = await hashPassword(password);
  return toPasswordFields(credential);
}

/** Resolve how a plaintext password becomes stored credential fields. */
function resolveDeriveCredential(options) {
  if (options && typeof options.deriveCredential === 'function') {
    return options.deriveCredential;
  }
  if (options && options.hasher && typeof options.hasher.hash === 'function') {
    const hasher = options.hasher;
    return async (password) => toPasswordFields(await hasher.hash(password));
  }
  return defaultDeriveCredential;
}

/**
 * Handle one registration request. Writes the response itself (201 or an error
 * envelope thrown as an AppError) and returns the repository result for tests.
 *
 * @param {object} ctx request context (req, res, services, ...)
 * @param {object} [options]
 * @returns {Promise<object>}
 */
async function handleRegister(ctx, options) {
  const opts = isPlainObject(options) ? options : {};
  if (!ctx || !ctx.req || !ctx.res) {
    throw new Error('register handler requires an http request context');
  }
  // Trust boundary first: parse and validate before any service lookup, so a
  // malformed body or unknown field is always a client 400 and never a 5xx.
  const body = await parseJsonBody(ctx.req, MAX_BODY_BYTES);
  const { username, password } = validateRegisterInput(body);

  const repository = resolveUserRepository(ctx, opts);
  if (repository === null) {
    throw new Error('register handler requires a configured user repository');
  }

  // Advisory fast path: refuse an already-taken name without paying for scrypt.
  // The authoritative check still happens inside the repository critical section.
  if (typeof repository.existsByUsername === 'function' && repository.existsByUsername(username)) {
    throw new AppError(USERNAME_TAKEN);
  }

  const deriveCredential = resolveDeriveCredential(opts);
  let credential;
  try {
    credential = await deriveCredential(password);
  } catch (error) {
    // Hashing failures are internal faults; never echo hashing detail.
    throw new AppError(ERROR_CODES.INTERNAL_ERROR);
  }

  // Duplicate check + insert + atomic persist happen inside one mutex section.
  const result = await repository.createUser({ username, credential });

  if (result && result.ok === true && result.user && typeof result.user.id === 'string') {
    const resolvedUsername = typeof result.user.username === 'string' ? result.user.username : username;
    sendJson(ctx.res, 201, { user: { id: result.user.id, username: resolvedUsername } });
    return result;
  }

  if (result && result.code === USERNAME_TAKEN) {
    throw new AppError(USERNAME_TAKEN);
  }
  throw new AppError(VALIDATION_ERROR);
}

/** Build a bound register handler. */
function createRegisterHandler(options) {
  const opts = isPlainObject(options) ? options : {};
  return function registerHandler(ctx) {
    return handleRegister(ctx, opts);
  };
}

/**
 * Register POST /api/register on an app or router.
 * Accepts the app surface (addPublic/addRoute) or a bare router (post).
 */
function registerRoutes(target, options) {
  if (!target || typeof target !== 'object') {
    throw new TypeError('registerRoutes requires an app or router');
  }
  const handler = createRegisterHandler(options);
  if (typeof target.addPublic === 'function') {
    target.addPublic(REGISTER_METHOD, REGISTER_PATH, handler);
    return handler;
  }
  if (typeof target.addRoute === 'function') {
    target.addRoute(REGISTER_METHOD, REGISTER_PATH, handler);
    return handler;
  }
  if (typeof target.post === 'function') {
    target.post(REGISTER_PATH, handler);
    return handler;
  }
  throw new TypeError('registerRoutes target must expose addPublic, addRoute or post');
}

module.exports = {
  REGISTER_PATH,
  REGISTER_METHOD,
  USERNAME_TAKEN,
  VALIDATION_ERROR,
  isUsableRepository,
  pickRepository,
  resolveUserRepository,
  resolveDeriveCredential,
  defaultDeriveCredential,
  handleRegister,
  createRegisterHandler,
  registerRoutes,
};
