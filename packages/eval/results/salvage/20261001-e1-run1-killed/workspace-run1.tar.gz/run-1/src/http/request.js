'use strict';

/**
 * Request helpers: safe, bounded reading of the raw body and tolerant parsing
 * of JSON payloads and query strings.
 *
 * Invalid JSON, an oversized body or an unreadable stream all surface as
 * client-visible AppErrors, never as an uncaught exception.
 */

const { AppError, ERROR_CODES } = require('../errors/errorEnvelope.js');

const MAX_BODY_BYTES = 1024 * 1024;

function readBody(req, limit) {
  const maxBytes = typeof limit === 'number' && limit > 0 ? limit : MAX_BODY_BYTES;
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let settled = false;

    function cleanup() {
      req.removeListener('data', onData);
      req.removeListener('end', onEnd);
      req.removeListener('error', onError);
      req.removeListener('aborted', onError);
    }

    function onData(chunk) {
      if (settled) {
        return;
      }
      size += chunk.length;
      if (size > maxBytes) {
        settled = true;
        cleanup();
        reject(new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body is too large'));
        req.resume();
        return;
      }
      chunks.push(chunk);
    }

    function onEnd() {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      resolve(Buffer.concat(chunks, size).toString('utf8'));
    }

    function onError(error) {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      reject(new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body could not be read'));
    }

    req.on('data', onData);
    req.on('end', onEnd);
    req.on('error', onError);
  });
}

/**
 * Read and parse a JSON request body.
 * An absent/empty body resolves to {} so field validation reports the real
 * problem (missing fields) instead of a transport error.
 */
async function readJsonBody(req, limit) {
  const raw = await readBody(req, limit);
  const text = raw.trim();
  if (text.length === 0) {
    return {};
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (error) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body must be valid JSON');
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body must be a JSON object');
  }
  return parsed;
}

/** Parse the request URL defensively; a malformed URL never throws to the caller. */
function parseUrl(req) {
  try {
    const url = new URL(req.url || '/', 'http://localhost');
    return url;
  } catch (error) {
    return new URL('/', 'http://localhost');
  }
}

/** Query string as a plain object (last value wins, never a multi-value array). */
function parseQuery(rawUrl) {
  const out = {};
  let params;
  try {
    params = new URL(rawUrl || '/', 'http://localhost').searchParams;
  } catch (error) {
    return out;
  }
  for (const [key, value] of params.entries()) {
    out[key] = value;
  }
  return out;
}

function headerValue(req, name) {
  const value = req.headers ? req.headers[String(name).toLowerCase()] : undefined;
  if (Array.isArray(value)) {
    return value.length > 0 ? value[0] : undefined;
  }
  return typeof value === 'string' ? value : undefined;
}

module.exports = {
  MAX_BODY_BYTES,
  readBody,
  readJsonBody,
  parseUrl,
  parseQuery,
  headerValue,
};
