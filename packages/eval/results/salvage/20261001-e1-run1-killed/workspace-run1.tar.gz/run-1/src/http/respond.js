'use strict';

/**
 * Response helpers. Every JSON response goes through here so that the
 * Content-Type, no-store caching and security headers stay consistent, and so
 * that error payloads always use the shared envelope.
 */

const { buildErrorBody, toErrorEnvelope, ERROR_CODES } = require('../errors/errorEnvelope.js');

const JSON_TYPE = 'application/json; charset=utf-8';
const HTML_TYPE = 'text/html; charset=utf-8';
const TEXT_TYPE = 'text/plain; charset=utf-8';
const MAX_BODY_BYTES = 1024 * 1024;

const BASE_HEADERS = Object.freeze({
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
});

function applyHeaders(res, headers) {
  const merged = Object.assign({}, BASE_HEADERS, headers || {});
  for (const name of Object.keys(merged)) {
    const value = merged[name];
    if (value !== undefined && value !== null) {
      res.setHeader(name, value);
    }
  }
}

function isSent(res) {
  return res.writableEnded === true || res.headersSent === true;
}

function bufferToHex(buffer) {
  return Buffer.from(buffer).toString('hex');
}

/** JSON response. Body is serialised defensively; serialisation failure is handled upstream. */
function sendJson(res, status, body, headers) {
  if (isSent(res)) {
    return;
  }
  let payload;
  try {
    payload = Buffer.from(JSON.stringify(body === undefined ? null : body), 'utf8');
  } catch (error) {
    payload = Buffer.from(JSON.stringify(buildErrorBody(ERROR_CODES.INTERNAL_ERROR)), 'utf8');
    status = 500;
  }
  if (payload.length > MAX_BODY_BYTES) {
    payload = Buffer.from(JSON.stringify(buildErrorBody(ERROR_CODES.INTERNAL_ERROR)), 'utf8');
    status = 500;
  }
  applyHeaders(res, Object.assign({ 'Content-Type': JSON_TYPE, 'Content-Length': String(payload.length) }, headers));
  res.writeHead(status);
  res.end(payload);
}

function sendHtml(res, status, html, headers) {
  if (isSent(res)) {
    return;
  }
  const payload = Buffer.from(String(html), 'utf8');
  applyHeaders(res, Object.assign({ 'Content-Type': HTML_TYPE, 'Content-Length': String(payload.length) }, headers));
  res.writeHead(status);
  res.end(payload);
}

function sendText(res, status, text, headers) {
  if (isSent(res)) {
    return;
  }
  const payload = Buffer.from(String(text), 'utf8');
  applyHeaders(res, Object.assign({ 'Content-Type': TEXT_TYPE, 'Content-Length': String(payload.length) }, headers));
  res.writeHead(status);
  res.end(payload);
}

/** 204 with no body. */
function sendNoContent(res) {
  if (isSent(res)) {
    return;
  }
  applyHeaders(res, {});
  res.writeHead(204);
  res.end();
}

/** Error response built from the shared envelope. */
function sendError(res, statusOrError, code, message) {
  if (typeof statusOrError === 'number') {
    sendJson(res, statusOrError, buildErrorBody(code, message));
    return;
  }
  const mapped = toErrorEnvelope(statusOrError);
  sendJson(res, mapped.status, mapped.body);
}

module.exports = {
  JSON_TYPE,
  HTML_TYPE,
  TEXT_TYPE,
  MAX_BODY_BYTES,
  BASE_HEADERS,
  applyHeaders,
  isSent,
  bufferToHex,
  sendJson,
  sendHtml,
  sendText,
  sendNoContent,
  sendError,
};
