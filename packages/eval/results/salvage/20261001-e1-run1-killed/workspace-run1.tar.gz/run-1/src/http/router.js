'use strict';

/**
 * Router / HTTP Adapter.
 *
 * Thin node:http layer: match method+path, extract path params and the parsed
 * URL, then dispatch to a registered handler. Business handlers are attached by
 * later tasks through add()/get()/post()/patch()/delete() or a router mount.
 */

const { AppError, ERROR_CODES } = require('../errors/errorEnvelope.js');

const HTTP_METHODS = Object.freeze(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);
const MAX_PATH_LENGTH = 2048;
const PARAM_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;

function splitPath(path) {
  return path
    .split('/')
    .filter((segment) => segment.length > 0)
    .map((segment) => {
      try {
        return decodeURIComponent(segment);
      } catch (error) {
        return segment;
      }
    });
}

function compile(path) {
  if (typeof path !== 'string' || path.length === 0 || !path.startsWith('/')) {
    throw new Error('Route path must be an absolute path string');
  }
  const segments = splitPath(path);
  const params = [];
  const matcher = segments.map((segment) => {
    if (segment.startsWith(':')) {
      const name = segment.slice(1);
      if (!PARAM_NAME.test(name) || segment.length > 64) {
        throw new Error('Invalid route parameter name: ' + segment);
      }
      params.push(name);
      return { kind: 'param', name };
    }
    if (segment === '*') {
      return { kind: 'wildcard' };
    }
    return { kind: 'literal', value: segment };
  });
  return { matcher, params, path };
}

function matchRoute(route, segments) {
  if (route.matcher.length > segments.length) {
    return null;
  }
  const params = {};
  for (let index = 0; index < route.matcher.length; index += 1) {
    const part = route.matcher[index];
    if (part.kind === 'wildcard') {
      return params;
    }
    const actual = segments[index];
    if (part.kind === 'param') {
      params[part.name] = actual;
      continue;
    }
    if (part.value !== actual) {
      return null;
    }
  }
  return route.matcher.length === segments.length ? params : null;
}

function normalizePathname(pathname) {
  if (typeof pathname !== 'string' || pathname.length === 0) {
    return '/';
  }
  let value = pathname.length > MAX_PATH_LENGTH ? pathname.slice(0, MAX_PATH_LENGTH) : pathname;
  if (!value.startsWith('/')) {
    value = '/' + value;
  }
  if (value.length > 1 && value.endsWith('/')) {
    value = value.replace(/\/+$/, '') || '/';
  }
  return value;
}

function createRouter(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const routes = [];
  const mounts = [];

  function add(method, path, handler, routeOptions) {
    const optionsValue = routeOptions && typeof routeOptions === 'object' ? routeOptions : {};
    const normalizedMethod = String(method).toUpperCase();
    if (!HTTP_METHODS.includes(normalizedMethod)) {
      throw new Error('Unsupported HTTP method: ' + method);
    }
    if (typeof handler !== 'function') {
      throw new TypeError('Route handler must be a function');
    }
    const compiled = compile(path);
    const route = {
      method: normalizedMethod,
      path: compiled.path,
      matcher: compiled.matcher,
      params: compiled.params,
      auth: optionsValue.auth === true,
      middleware: Array.isArray(optionsValue.middleware) ? optionsValue.middleware.slice() : [],
      handler,
    };
    routes.push(route);
    return route;
  }

  /** Public (unauthenticated) route. */
  function addPublic(method, path, handler, routeOptions) {
    return add(method, path, handler, Object.assign({}, routeOptions, { auth: false }));
  }

  /** Protected route: the auth middleware is injected when it is available. */
  function addProtected(method, path, handler, routeOptions) {
    return add(method, path, handler, Object.assign({}, routeOptions, { auth: true }));
  }

  function mount(prefix, router) {
    if (typeof prefix !== 'string' || !prefix.startsWith('/')) {
      throw new Error('Mount prefix must be an absolute path');
    }
    if (!router || typeof router.list !== 'function') {
      throw new Error('Mount target must be a router');
    }
    mounts.push({ prefix: prefix.replace(/\/+$/, ''), router });
  }

  /** Resolve a request to a route without executing it. */
  function resolve(method, pathname) {
    const target = normalizePathname(pathname);
    const segments = splitPath(target);
    const wanted = String(method || 'GET').toUpperCase();
    for (const route of routes) {
      if (route.method !== wanted) {
        continue;
      }
      const params = matchRoute(route, segments);
      if (params !== null) {
        return { route, params, pathname: target, segments };
      }
    }
    for (const mountEntry of mounts) {
      const prefixSegments = splitPath(mountEntry.prefix);
      if (segments.length < prefixSegments.length) {
        continue;
      }
      const matches = prefixSegments.every((segment, index) => segment === segments[index]);
      if (!matches) {
        continue;
      }
      const rest = '/' + segments.slice(prefixSegments.length).join('/');
      const inner = mountEntry.router.resolve(wanted, rest);
      if (inner.route !== null) {
        return { route: inner.route, params: inner.params, pathname: target, segments, mount: mountEntry.prefix };
      }
    }
    return { route: null, params: {}, pathname: target, segments };
  }

  function list() {
    return routes.slice();
  }

  function methodNotAllowed(method, pathname) {
    const target = normalizePathname(pathname);
    const segments = splitPath(target);
    return routes.some((route) => route.method !== String(method).toUpperCase() && matchRoute(route, segments) !== null);
  }

  return {
    add,
    addPublic,
    addProtected,
    mount,
    match: resolve,
    resolve,
    list,
    methodNotAllowed,
    get: (path, handler, routeOptions) => addPublic('GET', path, handler, routeOptions),
    post: (path, handler, routeOptions) => addPublic('POST', path, handler, routeOptions),
    patch: (path, handler, routeOptions) => addPublic('PATCH', path, handler, routeOptions),
    delete: (path, handler, routeOptions) => addPublic('DELETE', path, handler, routeOptions),
    put: (path, handler, routeOptions) => addPublic('PUT', path, handler, routeOptions),
  };
}

/** Build a NOT_FOUND AppError for an unmatched request. */
function notFoundError() {
  return new AppError(ERROR_CODES.NOT_FOUND);
}

module.exports = {
  HTTP_METHODS,
  MAX_PATH_LENGTH,
  splitPath,
  compile,
  matchRoute,
  normalizePathname,
  createRouter,
  notFoundError,
};
