'use strict';

/**
 * Task Route Handlers (FR-3 / FR-4 / FR-5 / FR-6).
 *
 * Registers the five task routes on the existing zero-dependency Node http
 * router and implements their business logic:
 *
 *   POST   /api/tasks       create   -> 201 { "task" }
 *   GET    /api/tasks       list     -> 200 { "items" }   (optional ?q=)
 *   GET    /api/tasks/:id   read     -> 200 { "task" }
 *   PATCH  /api/tasks/:id   update   -> 200 { "task" }
 *   DELETE /api/tasks/:id   delete   -> 204 (no body)
 *
 * Routing (TR-01)
 *   - Every route is registered through app.addProtectedRoute(), so the shared
 *     Bearer auth guard runs BEFORE the handler and the :id segment is extracted
 *     by the router into ctx.params.id (percent-decoded). Matching is exact
 *     per-segment, so there is no collision with GET /, /healthz, /health,
 *     /ready, POST /api/register or POST /api/login.
 *
 * Auth guard (TR-02)
 *   - The guard is the single gate: it verifies the signed token and injects the
 *     resolved userId into the request context (ctx.userId / ctx.user.id). A
 *     missing, tampered or truncated token is answered with 401 UNAUTHORIZED
 *     before any handler runs.
 *   - Each handler re-checks ctx.userId and refuses to touch the store when it is
 *     absent, so no task logic or storage access can execute unauthenticated.
 *
 * Trust boundary (TR-04 / TR-05 / TR-06)
 *   - Bodies are parsed and validated before any store access: strict field
 *     whitelists (POST {title, dueDate}; PATCH {title, dueDate, done}), title
 *     trimmed then measured in Unicode code points (1-100), dueDate a real
 *     YYYY-MM-DD calendar date, PATCH done a boolean. Malformed JSON is 400
 *     VALIDATION_ERROR; unknown fields are 400 UNKNOWN_FIELD and never ignored.
 *
 * Isolation (TR-10)
 *   - Every lookup goes through owner-scoped repository queries, so a cross-user
 *     GET/PATCH/DELETE is byte-identical to a nonexistent id (404 NOT_FOUND) and
 *     never reads, modifies or deletes another user's task.
 *
 * The repository is resolved from the request context (ctx.services) or from the
 * factory options, so tests can inject a fast double without global state.
 */

const { AppError, ERROR_CODES } = require('../errors/errorEnvelope.js');
const { MAX_BODY_BYTES } = require('./request.js');
const { sendJson, sendNoContent } = require('./respond.js');
const {
  parseJsonBody,
  validateCreateTaskInput,
  validateUpdateTaskInput,
} = require('../validate.js');

const TASKS_PATH = '/api/tasks';
const TASK_ID_PATH = '/api/tasks/:id';
const CREATE_METHOD = 'POST';
const LIST_METHOD = 'GET';
const READ_METHOD = 'GET';
const UPDATE_METHOD = 'PATCH';
const DELETE_METHOD = 'DELETE';

const NOT_FOUND = ERROR_CODES.NOT_FOUND;
const UNAUTHORIZED = ERROR_CODES.UNAUTHORIZED;
const VALIDATION_ERROR = ERROR_CODES.VALIDATION_ERROR;

/** Repository property names accepted from ctx.services / factory options. */
const REPOSITORY_NAMES = Object.freeze(['taskRepository', 'tasks', 'taskRepo', 'tasksRepository']);

/** Repository methods required by the handlers. */
const REQUIRED_METHODS = Object.freeze([
  'createTask',
  'listTasksByOwner',
  'findTaskByIdAndOwner',
  'updateTaskByIdAndOwner',
  'deleteTaskByIdAndOwner',
]);

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/** A repository is usable when it exposes every owner-scoped operation. */
function isUsableTaskRepository(candidate) {
  if (!candidate) {
    return false;
  }
  return REQUIRED_METHODS.every((name) => typeof candidate[name] === 'function');
}

/** Pick the first usable task repository from a services/options container. */
function pickTaskRepository(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  for (const name of REPOSITORY_NAMES) {
    if (isUsableTaskRepository(source[name])) {
      return source[name];
    }
  }
  return null;
}

/** Resolve the task repository from the request context first, then options. */
function resolveTaskRepository(ctx, options) {
  const fromContext = pickTaskRepository(ctx && ctx.services);
  if (fromContext !== null) {
    return fromContext;
  }
  if (isPlainObject(options)) {
    const fromOptionsServices = pickTaskRepository(options.services);
    if (fromOptionsServices !== null) {
      return fromOptionsServices;
    }
    return pickTaskRepository(options);
  }
  return null;
}

/**
 * Read the authenticated user id from the request context.
 * Returns null when the guard did not resolve an identity, which makes every
 * handler fail closed instead of touching the store.
 */
function resolveUserId(ctx) {
  if (!ctx) {
    return null;
  }
  if (isNonEmptyString(ctx.userId)) {
    return ctx.userId;
  }
  if (isPlainObject(ctx.user) && isNonEmptyString(ctx.user.id)) {
    return ctx.user.id;
  }
  if (isPlainObject(ctx.auth) && isNonEmptyString(ctx.auth.userId)) {
    return ctx.auth.userId;
  }
  return null;
}

/** Fail closed: no resolved identity means no handler logic and no store access. */
function requireUserId(ctx) {
  const userId = resolveUserId(ctx);
  if (userId === null) {
    throw new AppError(UNAUTHORIZED);
  }
  return userId;
}

/** Resolve the repository or fail with a safe internal error (never a crash). */
function requireRepository(ctx, options) {
  const repository = resolveTaskRepository(ctx, options);
  if (repository === null) {
    throw new AppError(ERROR_CODES.INTERNAL_ERROR);
  }
  return repository;
}

/** Extract the :id path segment, percent-decoded by the router. */
function readTaskId(ctx) {
  const params = ctx && ctx.params;
  if (isPlainObject(params) && isNonEmptyString(params.id)) {
    return params.id;
  }
  return null;
}

/**
 * Trust-boundary normalisation of the optional `q` query value.
 * Only a genuine string is accepted, so a crafted query value that arrives as an
 * array/object (for example a duplicated or nested parameter) can never be
 * coerced into a pattern or a shell fragment. The value is already URL-decoded by
 * the query parser and is returned verbatim so it can only ever act as a literal
 * substring.
 */
function normalizeQueryParam(value) {
  return typeof value === 'string' ? value : undefined;
}

/**
 * Case-insensitive plain substring filter over the caller's own records.
 * `q` is matched with String#includes on lowercased title text: it is never
 * compiled into a RegExp, never concatenated into a query language and never
 * executed as a shell fragment, so arbitrary characters (quotes, semicolons, SQL
 * fragments, regex metacharacters, malformed percent escapes) cannot throw and
 * can never produce a 5xx.
 */
function filterByQuery(records, query) {
  const needle = normalizeQueryParam(query);
  if (needle === undefined || needle.length === 0) {
    return records;
  }
  const lowerNeedle = needle.toLowerCase();
  return records.filter((record) => {
    const title = record && typeof record.title === 'string' ? record.title : '';
    return title.toLowerCase().includes(lowerNeedle);
  });
}

/** Project a stored record onto the fixed client-visible task shape. */
function toPublicTask(record) {
  if (!isPlainObject(record)) {
    return null;
  }
  return {
    id: record.id,
    title: record.title,
    dueDate: record.dueDate === undefined ? null : record.dueDate,
    done: record.done === true,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
  };
}

/** POST /api/tasks: create a task owned by the authenticated user. */
async function handleCreateTask(ctx, options) {
  const userId = requireUserId(ctx);
  const repository = requireRepository(ctx, options);
  const body = await parseJsonBody(ctx.req, MAX_BODY_BYTES);
  const input = validateCreateTaskInput(body);
  const result = await repository.createTask({
    ownerId: userId,
    title: input.title,
    dueDate: input.dueDate,
  });
  if (!result || result.ok !== true) {
    throw new AppError((result && result.code) || VALIDATION_ERROR);
  }
  const task = toPublicTask(result.record) || result.task;
  sendJson(ctx.res, 201, { task });
  return { task };
}

/** GET /api/tasks: list the caller's tasks, optionally filtered by ?q=. */
async function handleListTasks(ctx, options) {
  const userId = requireUserId(ctx);
  const repository = requireRepository(ctx, options);
  const query = isPlainObject(ctx.query) ? ctx.query.q : undefined;
  const owned = repository.listTasksByOwner(userId);
  const records = Array.isArray(owned) ? owned : [];
  const items = filterByQuery(records, query).map((record) => toPublicTask(record));
  sendJson(ctx.res, 200, { items });
  return { items };
}

/** GET /api/tasks/:id: read one owner-scoped task. */
async function handleGetTask(ctx, options) {
  const userId = requireUserId(ctx);
  const repository = requireRepository(ctx, options);
  const id = readTaskId(ctx);
  const record = id === null ? null : repository.findTaskByIdAndOwner(id, userId);
  if (!isPlainObject(record)) {
    throw new AppError(NOT_FOUND);
  }
  const task = toPublicTask(record);
  sendJson(ctx.res, 200, { task });
  return { task };
}

/** PATCH /api/tasks/:id: apply whitelisted fields to an owner-scoped task. */
async function handleUpdateTask(ctx, options) {
  const userId = requireUserId(ctx);
  const repository = requireRepository(ctx, options);
  const id = readTaskId(ctx);
  const body = await parseJsonBody(ctx.req, MAX_BODY_BYTES);
  const patch = validateUpdateTaskInput(body);
  if (id === null) {
    throw new AppError(NOT_FOUND);
  }
  const result = await repository.updateTaskByIdAndOwner(id, userId, patch);
  if (!result || result.ok !== true) {
    throw new AppError((result && result.code) || NOT_FOUND);
  }
  const task = toPublicTask(result.record) || result.task;
  sendJson(ctx.res, 200, { task });
  return { task };
}

/** DELETE /api/tasks/:id: remove an owner-scoped task, 204 with no body. */
async function handleDeleteTask(ctx, options) {
  const userId = requireUserId(ctx);
  const repository = requireRepository(ctx, options);
  const id = readTaskId(ctx);
  if (id === null) {
    throw new AppError(NOT_FOUND);
  }
  const result = await repository.deleteTaskByIdAndOwner(id, userId);
  if (!result || result.ok !== true) {
    throw new AppError((result && result.code) || NOT_FOUND);
  }
  sendNoContent(ctx.res);
  return { deleted: true };
}

/** Build the five bound task handlers. */
function createTaskHandlers(options) {
  const opts = isPlainObject(options) ? options : {};
  return {
    create: (ctx) => handleCreateTask(ctx, opts),
    list: (ctx) => handleListTasks(ctx, opts),
    get: (ctx) => handleGetTask(ctx, opts),
    update: (ctx) => handleUpdateTask(ctx, opts),
    remove: (ctx) => handleDeleteTask(ctx, opts),
  };
}

/**
 * Register the five task routes on an app or router.
 *
 * The app surface (addProtectedRoute) is preferred so the shared Bearer guard
 * runs before every handler; a bare router falls back to addProtected().
 */
function taskRoutes(target, options) {
  if (!target || typeof target !== 'object') {
    throw new TypeError('taskRoutes requires an app or router');
  }
  const handlers = createTaskHandlers(options);
  const register = (method, path, handler) => {
    if (typeof target.addProtectedRoute === 'function') {
      target.addProtectedRoute(method, path, handler);
      return;
    }
    if (typeof target.addProtected === 'function') {
      target.addProtected(method, path, handler);
      return;
    }
    throw new TypeError('taskRoutes target must expose addProtectedRoute or addProtected');
  };
  register(CREATE_METHOD, TASKS_PATH, handlers.create);
  register(LIST_METHOD, TASKS_PATH, handlers.list);
  register(READ_METHOD, TASK_ID_PATH, handlers.get);
  register(UPDATE_METHOD, TASK_ID_PATH, handlers.update);
  register(DELETE_METHOD, TASK_ID_PATH, handlers.remove);
  return handlers;
}

module.exports = {
  TASKS_PATH,
  TASK_ID_PATH,
  CREATE_METHOD,
  LIST_METHOD,
  READ_METHOD,
  UPDATE_METHOD,
  DELETE_METHOD,
  REPOSITORY_NAMES,
  REQUIRED_METHODS,
  isUsableTaskRepository,
  pickTaskRepository,
  resolveTaskRepository,
  resolveUserId,
  requireUserId,
  readTaskId,
  filterByQuery,
  toPublicTask,
  handleCreateTask,
  handleListTasks,
  handleGetTask,
  handleUpdateTask,
  handleDeleteTask,
  createTaskHandlers,
  taskRoutes,
};
