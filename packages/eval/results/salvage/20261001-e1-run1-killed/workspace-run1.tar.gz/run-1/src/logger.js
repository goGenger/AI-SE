'use strict';

/**
 * Logger.
 *
 * Guarantees:
 *   - Logs are written to stdout only (the default stream is process.stdout);
 *     nothing is ever redirected to a file.
 *   - Plaintext passwords, password hashes/digests/salts and token signing
 *     secrets are redacted from both field values and free-form messages.
 */

const LEVELS = Object.freeze({ debug: 10, info: 20, warn: 30, error: 40, fatal: 50 });

const REDACTED = '[REDACTED]';
const MAX_DEPTH = 4;
const MAX_ARRAY_ITEMS = 50;
const MAX_STRING_LENGTH = 1000;

/** Field names whose values must never be emitted. */
const SENSITIVE_KEY = /(pass(word|wd)?|pwd|secret|token|hash|digest|salt|authorization|api[-_]?key|credential|cookie|session)/i;

/** "Bearer <token>" / "Basic <token>" style credentials inside strings. */
const CREDENTIAL_HEADER = /\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]+/gi;

/** "password=..." / "token: ..." style key/value pairs inside strings. */
const KEY_VALUE_SECRET = /\b(password|passwd|pwd|secret|token|hash|digest|salt|authorization)\b\s*[:=]\s*("[^"]*"|'[^']*'|[^\s,;}]+)/gi;

/** Long hex/base64 runs: scrypt/PBKDF2 digests and HMAC keys. */
const SECRET_LIKE_BLOB = /[A-Fa-f0-9]{32,}|[A-Za-z0-9+/]{48,}={0,2}/g;


function isRegExp(value) {
  return value !== null && typeof value === 'object' && value instanceof RegExp;
}

/** Public helper: scrub a single string value. */
function redactString(input) {
  let text = String(input);
  if (text.length > MAX_STRING_LENGTH) {
    text = text.slice(0, MAX_STRING_LENGTH) + '...[truncated]';
  }
  return text
    .replace(CREDENTIAL_HEADER, (match, scheme) => scheme + ' ' + REDACTED)
    .replace(KEY_VALUE_SECRET, (match, key) => key + '=' + REDACTED)
    .replace(SECRET_LIKE_BLOB, REDACTED);
}

function sanitizeError(error, depth, seen) {
  const out = {
    name: typeof error.name === 'string' ? error.name : 'Error',
    message: redactString(typeof error.message === 'string' ? error.message : String(error)),
  };
  if (typeof error.code === 'string') {
    out.code = error.code;
  }
  if (typeof error.status === 'number') {
    out.status = error.status;
  }
  if (typeof error.stack === 'string' && depth < MAX_DEPTH) {
    out.stack = redactString(error.stack);
  }
  seen.add(error);
  return out;
}

/**
 * Recursively copy a value into a log-safe structure. SENSITIVE keys are
 * replaced by [REDACTED]; strings are scrubbed of credential patterns.
 */
function sanitize(value, depth, seen) {
  const level = typeof depth === 'number' ? depth : 0;
  const visited = seen instanceof WeakSet ? seen : new WeakSet();

  if (value === null || value === undefined) {
    return value;
  }
  const type = typeof value;
  if (type === 'string') {
    return redactString(value);
  }
  if (type === 'number' || type === 'boolean' || type === 'bigint') {
    return value;
  }
  if (type === 'function') {
    return '[Function]';
  }
  if (type === 'symbol') {
    return String(value);
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (value instanceof Error) {
    return sanitizeError(value, level, visited);
  }
  if (isRegExp(value)) {
    return '[RegExp]';
  }
  if (Buffer.isBuffer(value) || ArrayBuffer.isView(value)) {
    return '[Binary ' + value.length + ' bytes]';
  }
  if (level >= MAX_DEPTH) {
    return '[MaxDepth]';
  }
  if (visited.has(value)) {
    return '[Circular]';
  }
  visited.add(value);

  if (Array.isArray(value)) {
    return value.slice(0, MAX_ARRAY_ITEMS).map((item) => sanitize(item, level + 1, visited));
  }

  const out = {};
  for (const key of Object.keys(value)) {
    let item;
    try {
      item = value[key];
    } catch (error) {
      item = '[Unreadable]';
    }
    // Booleans carry no secret, so keep flags such as hasTokenSecret readable.
    const isSecretField = SENSITIVE_KEY.test(key) && typeof item !== 'boolean';
    out[key] = isSecretField ? REDACTED : sanitize(item, level + 1, visited);
  }
  return out;
}

/** Convert a thrown value into something safe for a log message. */
function describeError(error) {
  if (error instanceof Error) {
    return sanitizeError(error, 0, new WeakSet());
  }
  return sanitize({ message: error }, 0, new WeakSet());
}

function createLogger(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const stream = opts.stream || process.stdout;
  const requested = typeof opts.level === 'string' ? opts.level.toLowerCase() : 'info';
  const threshold = LEVELS[requested] === undefined ? LEVELS.info : LEVELS[requested];
  const baseContext = opts.context && typeof opts.context === 'object' ? opts.context : {};
  const baseKeys = Object.keys(baseContext);

  function write(level, message, fields) {
    if (LEVELS[level] < threshold) {
      return;
    }
    let record;
    try {
      record = {
        ts: new Date().toISOString(),
        level,
        msg: typeof message === 'string' ? redactString(message) : '[NonStringMessage]',
      };
      if (baseKeys.length > 0) {
        record.context = sanitize(baseContext, 0, new WeakSet());
      }
      if (fields !== undefined && fields !== null) {
        record.fields = sanitize(fields, 0, new WeakSet());
      }
    } catch (error) {
      record = { ts: new Date().toISOString(), level, msg: 'logger.serialization.failed' };
    }
    let line;
    try {
      line = JSON.stringify(record) + '\n';
    } catch (error) {
      line = JSON.stringify({ ts: record.ts, level, msg: 'logger.serialization.failed' }) + '\n';
    }
    try {
      stream.write(line);
    } catch (error) {
      // A closed stdout (EPIPE) must never crash the application.
    }
  }

  return {
    level: typeof opts.level === 'string' ? opts.level : 'info',
    stream,
    debug: (message, fields) => write('debug', message, fields),
    info: (message, fields) => write('info', message, fields),
    warn: (message, fields) => write('warn', message, fields),
    error: (message, fields) => write('error', message, fields),
    fatal: (message, fields) => write('fatal', message, fields),
    child(extraContext) {
      return createLogger({
        stream,
        level: opts.level,
        context: Object.assign({}, baseContext, extraContext || {}),
      });
    },
  };
}

/** Default logger: stdout, level 'info', no secrets. */
const logger = createLogger();

module.exports = {
  LEVELS,
  REDACTED,
  SENSITIVE_KEY,
  redactString,
  sanitize,
  describeError,
  createLogger,
  logger,
};
