'use strict';

/**
 * `pnpm build` self-check: the deliverable is plain Node, so "build" verifies
 * that every module compiles, loads cleanly and honours the manifest contract.
 */

const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { ROOT, listFiles, relative, read } = require('./scan.js');
const { checkProjectContracts } = require('./contract.js');

const problems = [];
const files = listFiles('src').filter((file) => file.endsWith('.js'));

function report(message) {
  problems.push(message);
}

// 1. Parse every module (no code runs): the CommonJS equivalent of `node --check`.
for (const file of files) {
  try {
    // eslint-disable-next-line no-new
    new vm.Script(read(file), { filename: file });
  } catch (error) {
    report(relative(file) + ': syntax check failed -> ' + String((error && error.message) || error));
  }
}

// 2. Load every module (the entry point only self-starts under require.main).
for (const file of files) {
  const rel = relative(file);
  if (rel.startsWith('src/scripts/')) {
    continue;
  }
  try {
    // eslint-disable-next-line global-require, import/no-dynamic-require
    require(file);
  } catch (error) {
    report(rel + ': module failed to load -> ' + String((error && error.message) || error));
  }
}

// 3. Manifest contract.
const pkgPath = path.join(ROOT, 'package.json');
let pkg = null;
try {
  pkg = JSON.parse(read(pkgPath));
} catch (error) {
  report('package.json is not valid JSON');
}
if (pkg) {
  if (!pkg.dependencies || Object.keys(pkg.dependencies).length !== 0) {
    report('package.json dependencies must be empty (zero runtime dependencies)');
  }
  const scripts = pkg.scripts || {};
  const expectedScripts = ['start', 'test', 'lint', 'typecheck', 'build'];
  for (const name of expectedScripts) {
    if (typeof scripts[name] !== 'string' || scripts[name].trim() === '') {
      report('package.json is missing the ' + name + ' script');
    }
  }
  if (!String(scripts.start || '').includes('node ')) {
    report('package.json start script must launch node');
  }
  if (String(scripts.test || '') !== 'node --test') {
    report('package.json test script must be exactly "node --test"');
  }
}

// 4. Required runtime surface.
const REQUIRED_FILES = ['src/server.js', 'src/config.js', 'src/logger.js'];
for (const rel of REQUIRED_FILES) {
  if (!fs.existsSync(path.join(ROOT, rel))) {
    report('required file is missing: ' + rel);
  }
}

// Project-contract checks: empty dependencies, stdout-only logging,
// single-source error codes and a pinned pnpm-lock.yaml.
problems.push(...checkProjectContracts());

if (problems.length > 0) {
  process.stdout.write('build: FAILED (' + problems.length + ' problem(s))\n');
  for (const problem of problems) {
    process.stdout.write('  - ' + problem + '\n');
  }
  process.exitCode = 1;
} else {
  process.stdout.write('build: OK (' + files.length + ' modules compiled and loaded)\n');
}
