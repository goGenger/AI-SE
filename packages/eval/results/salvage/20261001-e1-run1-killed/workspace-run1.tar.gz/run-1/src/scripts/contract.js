'use strict';

/**
 * Shared project-contract static checks.
 *
 * Zero-dependency checks used by the lightweight `lint`, `typecheck` and
 * `build` self-check scripts (each exits 0 on a healthy tree). Every function
 * returns an array of human-readable problem strings and never throws.
 *
 * Covered constraints:
 *   - package.json parses and `dependencies` is the empty object (zero deps).
 *   - package.json declares the five required scripts.
 *   - The test directory exists and its files match `node --test` discovery.
 *   - Dockerfile exists and declares a node base, non-root USER and VOLUME /data.
 *   - Application logs may only go to process.stdout: no file-log writer.
 *   - The error-code set is declared once in src/errors/errorEnvelope.js.
 *   - pnpm-lock.yaml exists, is non-empty and pins lockfileVersion '9.0'.
 */

const fs = require('node:fs');
const path = require('node:path');

const { ROOT, listFiles, relative, read } = require('./scan.js');

/** Error codes the application may ever return (single source of truth). */
const API_ERROR_CODE_NAMES = Object.freeze([
  'VALIDATION_ERROR',
  'TITLE_INVALID',
  'DATE_INVALID',
  'UNKNOWN_FIELD',
  'UNAUTHORIZED',
  'INVALID_CREDENTIALS',
  'USERNAME_TAKEN',
  'NOT_FOUND',
]);

/** The one module allowed to declare those string literals. */
const CODE_SOURCE_REL = 'src/errors/errorEnvelope.js';

/** Module that reads and writes DATA_DIR files (not application logs). */
const STORE_MODULE_REL = 'src/store/jsonStore.js';

/** Required npm scripts the package manifest must expose. */
const REQUIRED_SCRIPTS = Object.freeze(['start', 'test', 'lint', 'typecheck', 'build']);

/** Relative location of the Node built-in test runner suite. */
const TEST_DIR_REL = 'test';

/** Default `node --test` discovery patterns, applied to repo-relative paths. */
const NODE_TEST_PATTERNS = Object.freeze([
  /(^|\/)[^/]*\.test\.(js|cjs|mjs)$/,
  /(^|\/)test\.(js|cjs|mjs)$/,
  /(^|\/)test-[^/]*\.(js|cjs|mjs)$/,
  /(^|\/)[^/]*-test\.(js|cjs|mjs)$/,
  /(^|\/)[^/]*_test\.(js|cjs|mjs)$/,
]);

/** Relative location of the container definition. */
const DOCKERFILE_REL = 'Dockerfile';

/** File-log writer APIs that must never appear in the runtime sources. */
const FILE_LOG_PATTERNS = Object.freeze([
  { re: /createWriteStream/, label: 'createWriteStream' },
  { re: /appendFile/, label: 'appendFile' },
  { re: /['"][^'"]*\.log['"]/, label: 'a .log file path' },
  { re: /process\.stdout\s*=/, label: 'process.stdout reassignment' },
  { re: /process\.stderr\s*=/, label: 'process.stderr reassignment' },
]);

/** Application (non-script) JavaScript modules. */
function runtimeFiles() {
  return listFiles('src').filter((file) => {
    const rel = relative(file);
    return rel.endsWith('.js') && !rel.startsWith('src/scripts/');
  });
}

/** Read and parse package.json, returning null when it is missing or invalid. */
function readPackage() {
  try {
    return JSON.parse(read(path.join(ROOT, 'package.json')));
  } catch (error) {
    return null;
  }
}

/** package.json must declare zero runtime dependencies and the required scripts. */
function checkDependencies() {
  const problems = [];
  const pkgPath = path.join(ROOT, 'package.json');
  const pkg = readPackage();
  if (!pkg) {
    return ['package.json is missing or is not valid JSON'];
  }
  if (pkg.dependencies === null || typeof pkg.dependencies !== 'object' || Array.isArray(pkg.dependencies)) {
    problems.push('package.json dependencies must be an object');
  } else if (Object.keys(pkg.dependencies).length !== 0) {
    problems.push('package.json dependencies must be empty (zero runtime dependencies)');
  }
  const scripts = pkg.scripts && typeof pkg.scripts === 'object' ? pkg.scripts : {};
  for (const name of REQUIRED_SCRIPTS) {
    if (typeof scripts[name] !== 'string' || scripts[name].trim() === '') {
      problems.push('package.json is missing the ' + name + ' script');
    }
  }
  void pkgPath;
  return problems;
}

/** The test suite must exist and be discoverable by `node --test`. */
function checkTestDiscovery() {
  const problems = [];
  const pkg = readPackage();
  const testScript = pkg && pkg.scripts ? pkg.scripts.test : undefined;
  if (typeof testScript !== 'string' || !/^node\s+--test(\s|$)/.test(testScript.trim())) {
    problems.push('package.json test script must invoke "node --test" so the suite is discovered');
  }
  const testDir = path.join(ROOT, TEST_DIR_REL);
  if (!fs.existsSync(testDir) || !fs.statSync(testDir).isDirectory()) {
    problems.push('the test directory (' + TEST_DIR_REL + '/) is missing');
    return problems;
  }
  const candidates = listFiles(TEST_DIR_REL).map((file) => relative(file));
  const discoverable = candidates.filter((rel) => NODE_TEST_PATTERNS.some((re) => re.test(rel)));
  if (discoverable.length === 0) {
    problems.push('no file under ' + TEST_DIR_REL + '/ matches node --test discovery patterns (e.g. *.test.js)');
  }
  return problems;
}

/** Dockerfile must exist and keep the non-root / persisted-volume contract. */
function checkDockerfile() {
  const problems = [];
  const dockerPath = path.join(ROOT, DOCKERFILE_REL);
  if (!fs.existsSync(dockerPath) || !fs.statSync(dockerPath).isFile()) {
    return ['Dockerfile is missing and must be committed at the repo root'];
  }
  const text = read(dockerPath);
  if (text.trim().length === 0) {
    return ['Dockerfile is empty'];
  }
  if (!/^\s*FROM\s+node/m.test(text)) {
    problems.push('Dockerfile must declare a FROM node base image');
  }
  const userLines = text
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /^USER\s+/i.test(line));
  if (userLines.length === 0) {
    problems.push('Dockerfile must set a non-root USER');
  } else if (userLines.some((line) => /^USER\s+root\b/i.test(line))) {
    problems.push('Dockerfile must not run as root');
  }
  if (!/^\s*VOLUME\s+\[?"?\/data/m.test(text)) {
    problems.push('Dockerfile must declare VOLUME /data for data persistence');
  }
  if (!/^\s*(CMD|ENTRYPOINT)\s/m.test(text)) {
    problems.push('Dockerfile must define CMD or ENTRYPOINT');
  }
  return problems;
}

/** Application logs must go to process.stdout only, never to a file. */
function checkNoFileLogging() {
  const problems = [];
  for (const file of runtimeFiles()) {
    const rel = relative(file);
    const lines = read(file).split('\n');
    lines.forEach((line, index) => {
      for (const pattern of FILE_LOG_PATTERNS) {
        if (pattern.re.test(line)) {
          problems.push(rel + ':' + (index + 1) + ' file logging is forbidden (' + pattern.label + ')');
        }
      }
      const isFileWrite = /writeFileSync|writeFile\(/.test(line);
      const mentionsLog = /log/i.test(line);
      if (isFileWrite && mentionsLog && rel !== STORE_MODULE_REL) {
        problems.push(rel + ':' + (index + 1) + ' log data must not be written to a file');
      }
    });
  }
  return problems;
}

/** Error codes must be imported from the single source, never re-declared. */
function checkErrorCodesSingleSource() {
  const problems = [];
  const codePattern = new RegExp("'(" + API_ERROR_CODE_NAMES.join('|') + ")'", 'g');
  for (const file of runtimeFiles()) {
    const rel = relative(file);
    if (rel === CODE_SOURCE_REL) {
      continue;
    }
    const lines = read(file).split('\n');
    lines.forEach((line, index) => {
      if (/^\s*(\/\/|\*|\/\*)/.test(line)) {
        return;
      }
      codePattern.lastIndex = 0;
      const found = line.match(codePattern);
      if (found) {
        problems.push(
          rel + ':' + (index + 1) + ' error code literal ' + found[0] + ' must come from ' + CODE_SOURCE_REL
        );
      }
    });
  }
  return problems;
}

/** pnpm-lock.yaml must be present, non-empty and pin lockfileVersion '9.0'. */
function checkLockfile() {
  const problems = [];
  const lockPath = path.join(ROOT, 'pnpm-lock.yaml');
  if (!fs.existsSync(lockPath)) {
    return ['pnpm-lock.yaml is missing and must be committed'];
  }
  const text = read(lockPath);
  if (text.trim().length === 0) {
    return ['pnpm-lock.yaml is empty'];
  }
  if (!/lockfileVersion:\s*'?9\.0'?/.test(text)) {
    problems.push("pnpm-lock.yaml must pin lockfileVersion '9.0'");
  }
  if (!/(^|\n)importers:/.test(text)) {
    problems.push('pnpm-lock.yaml must contain an importers section');
  }
  return problems;
}

/** Run every project-contract check and return the merged problem list. */
function checkProjectContracts() {
  return []
    .concat(checkDependencies())
    .concat(checkTestDiscovery())
    .concat(checkDockerfile())
    .concat(checkNoFileLogging())
    .concat(checkErrorCodesSingleSource())
    .concat(checkLockfile());
}

module.exports = {
  API_ERROR_CODE_NAMES,
  CODE_SOURCE_REL,
  STORE_MODULE_REL,
  REQUIRED_SCRIPTS,
  TEST_DIR_REL,
  NODE_TEST_PATTERNS,
  DOCKERFILE_REL,
  FILE_LOG_PATTERNS,
  runtimeFiles,
  readPackage,
  checkDependencies,
  checkTestDiscovery,
  checkDockerfile,
  checkNoFileLogging,
  checkErrorCodesSingleSource,
  checkLockfile,
  checkProjectContracts,
};
