'use strict';

/**
 * `pnpm lint` self-check: no ESLint, just objective, zero-dependency rules over
 * the JavaScript sources so the script exits 0 on a healthy tree.
 */

const path = require('node:path');
const { ROOT, listFiles, relative, read } = require('./scan.js');
const { checkProjectContracts } = require('./contract.js');

const problems = [];
const TARGETS = ['src', 'test'];
const JS_FILE = /\.(js|mjs|cjs)$/;
const BANNED_MODULES = ['child_process', 'node:child_process', 'worker_threads', 'node:worker_threads'];
const hasOwn = Object.prototype.hasOwnProperty;

function report(file, message) {
  problems.push(relative(file) + ': ' + message);
}

const files = listFiles(...TARGETS).filter((file) => JS_FILE.test(file));

for (const file of files) {
  const source = read(file);
  const lines = source.split('\n');
  const rel = relative(file);

  if (source.includes('\t')) {
    report(file, 'tab character found; use spaces');
  }
  if (!source.endsWith('\n')) {
    report(file, 'file must end with a newline');
  }
  if (source.includes('\r')) {
    report(file, 'CRLF line endings found; use LF');
  }
  lines.forEach((line, index) => {
    if (/[ \t]+$/.test(line)) {
      report(file, 'trailing whitespace on line ' + (index + 1));
    }
    if (line.length > 160) {
      report(file, 'line ' + (index + 1) + ' exceeds 160 characters');
    }
  });

  const isRuntimeSource = rel.startsWith('src/') && !rel.startsWith('src/scripts/');
  if (rel.startsWith('src/')) {
    if (!/^'use strict';\n/.test(source)) {
      report(file, 'missing top-level \'use strict\'; directive');
    }
    const banned = isRuntimeSource
      ? BANNED_MODULES.find(
          (name) => source.includes("require('" + name + "')") || source.includes('require("' + name + '")')
        )
      : undefined;
    if (banned) {
      report(file, 'forbidden module import: ' + banned);
    }
    const isEntryPoint = rel === 'src/server.js';
    if (isRuntimeSource && !isEntryPoint && source.includes('process.exit(')) {
      report(file, 'runtime source must not call process.exit directly outside the entry point');
    }
  }
}

// package.json contract checks.
const pkgPath = path.join(ROOT, 'package.json');
let pkg = null;
try {
  pkg = JSON.parse(read(pkgPath));
} catch (error) {
  report(pkgPath, 'package.json is not valid JSON');
}

if (pkg) {
  if (!pkg.dependencies || typeof pkg.dependencies !== 'object' || Object.keys(pkg.dependencies).length !== 0) {
    report(pkgPath, 'package.json dependencies must be an empty object');
  }
  const scripts = pkg.scripts && typeof pkg.scripts === 'object' ? pkg.scripts : {};
  for (const name of ['start', 'test', 'lint', 'typecheck', 'build']) {
    if (!hasOwn.call(scripts, name) || typeof scripts[name] !== 'string' || scripts[name].trim() === '') {
      report(pkgPath, 'missing script: ' + name);
    }
  }
}

// Project-contract checks: empty dependencies, stdout-only logging,
// single-source error codes and a pinned pnpm-lock.yaml.
problems.push(...checkProjectContracts());

if (problems.length > 0) {
  process.stdout.write('lint: FAILED (' + problems.length + ' problem(s))\n');
  for (const problem of problems) {
    process.stdout.write('  - ' + problem + '\n');
  }
  process.exitCode = 1;
} else {
  process.stdout.write('lint: OK (' + files.length + ' files checked)\n');
}
