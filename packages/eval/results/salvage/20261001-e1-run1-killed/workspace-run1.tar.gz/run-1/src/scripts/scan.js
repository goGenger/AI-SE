'use strict';

/**
 * Shared file-walking helper for the zero-dependency lint / typecheck / build
 * self-check scripts. Only Node built-ins are used.
 */

const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..', '..');
const SKIP_DIRS = new Set(['node_modules', '.git', 'data', 'coverage', 'dist']);

function walk(dir, out) {
  const results = out || [];
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (error) {
    return results;
  }
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) {
        continue;
      }
      walk(full, results);
      continue;
    }
    if (entry.isFile()) {
      results.push(full);
    }
  }
  return results;
}

function listFiles(...relativeRoots) {
  const roots = relativeRoots.length > 0 ? relativeRoots : ['src'];
  const files = [];
  for (const relative of roots) {
    const target = path.join(ROOT, relative);
    if (!fs.existsSync(target)) {
      continue;
    }
    const stat = fs.statSync(target);
    if (stat.isDirectory()) {
      walk(target, files);
    } else {
      files.push(target);
    }
  }
  return files;
}

function relative(file) {
  return path.relative(ROOT, file).split(path.sep).join('/');
}

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

module.exports = { ROOT, SKIP_DIRS, walk, listFiles, relative, read };
