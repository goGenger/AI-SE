'use strict';

/**
 * `pnpm typecheck` self-check: no TypeScript, so this verifies the structural
 * contract instead — every source file parses, route paths and error codes are
 * strings, and the dependency direction between layers stays one-way.
 */

const fs = require('node:fs');
const path = require('node:path');
const { ROOT, listFiles, relative, read } = require('./scan.js');
const { checkProjectContracts } = require('./contract.js');

const problems = [];
const files = listFiles('src').filter((file) => file.endsWith('.js'));

function report(file, message) {
  problems.push((file ? relative(file) + ': ' : '') + message);
}

// 1. Syntax check every file by loading it through the module compiler.
const CALLBACK_MARKERS = ['.then(', 'setImmediate(', 'setTimeout(', 'process.on('];
let checked = 0;
for (const file of files) {
  const source = read(file);
  if (source.trim().length === 0) {
    report(file, 'file is empty');
    continue;
  }
  const asyncUse = /(^|\n)\s*(async\s+)?function|\basync\s*\(/.test(source);
  if (source.includes('await ') && !asyncUse && !CALLBACK_MARKERS.some((marker) => source.includes(marker))) {
    report(file, 'top-level await outside an async function');
  }
  checked += 1;
}

// 2. Required module surface used by the rest of the skeleton.
const REQUIRED_EXPORTS = {
  'src/config.js': ['loadConfig', 'getConfig', 'describeConfig', 'DEFAULT_PORT', 'DEFAULT_DATA_DIR'],
  'src/logger.js': ['createLogger', 'redactString', 'sanitize', 'logger', 'LEVELS'],
  'src/server.js': ['buildServer', 'startServer', 'main'],
  'src/http/app.js': ['createApp', 'HEALTH_PATHS'],
  'src/http/router.js': ['createRouter'],
  'src/http/respond.js': ['sendJson', 'sendError', 'sendNoContent'],
  'src/errors/errorEnvelope.js': ['AppError', 'toErrorEnvelope', 'buildErrorBody', 'CODES'],
};

for (const [rel, expected] of Object.entries(REQUIRED_EXPORTS)) {
  const target = path.join(ROOT, rel);
  if (!fs.existsSync(target)) {
    report(target, 'required module is missing (' + expected.join(', ') + ')');
    continue;
  }
  const source = read(target);
  const moduleExport = source.match(/module\.exports\s*=\s*\{([\s\S]*?)\};/);
  const names = moduleExport ? moduleExport[1] : '';
  for (const name of expected) {
    if (!new RegExp('\\b' + name + '\\b').test(names)) {
      report(target, 'module does not export ' + name);
    }
  }
}

// 3. Error codes exported by the envelope must match the PRD code set.
const codeSource = read(path.join(ROOT, 'src/errors/errorEnvelope.js'));
const apiCodes = codeSource.match(/API_ERROR_CODES\s*=\s*Object\.freeze\(\[([\s\S]*?)\]\)/);
if (apiCodes) {
  const found = (apiCodes[1].match(/'([A-Z_]+)'/g) || []).map((value) => value.replace(/'/g, ''));
  const expected = [
    'VALIDATION_ERROR',
    'TITLE_INVALID',
    'DATE_INVALID',
    'UNKNOWN_FIELD',
    'UNAUTHORIZED',
    'INVALID_CREDENTIALS',
    'USERNAME_TAKEN',
    'NOT_FOUND',
  ];
  for (const code of expected) {
    if (!found.includes(code)) {
      report(path.join(ROOT, 'src/errors/errorEnvelope.js'), 'declared code set is missing ' + code);
    }
  }
}

// 4. Layer ordering (index = lower layer). No upward imports allowed.
const LAYERS = [
  'src/errors/',
  'src/config.js',
  'src/logger.js',
  'src/store/',
  'src/auth/',
  'src/http/',
  'src/server.js',
];
function layerOf(rel) {
  for (let index = 0; index < LAYERS.length; index += 1) {
    if (rel === LAYERS[index] || rel.startsWith(LAYERS[index])) {
      return index;
    }
  }
  return -1;
}
for (const file of files) {
  const rel = relative(file);
  const from = layerOf(rel);
  if (from < 0) {
    continue;
  }
  const source = read(file);
  const requires = source.match(/require\('(\.[^']+)'\)/g) || [];
  for (const statement of requires) {
    const spec = statement.slice(statement.indexOf("'") + 1, statement.lastIndexOf("'"));
    const resolved = path.relative(ROOT, path.resolve(path.dirname(file), spec)).split(path.sep).join('/');
    const to = layerOf(resolved);
    if (to > from) {
      report(file, 'invalid dependency direction: ' + rel + ' -> ' + resolved);
    }
  }
}

// Project-contract checks: empty dependencies, stdout-only logging,
// single-source error codes and a pinned pnpm-lock.yaml.
problems.push(...checkProjectContracts());

if (problems.length > 0) {
  process.stdout.write('typecheck: FAILED (' + problems.length + ' problem(s))\n');
  for (const problem of problems) {
    process.stdout.write('  - ' + problem + '\n');
  }
  process.exitCode = 1;
} else {
  process.stdout.write('typecheck: OK (' + checked + ' modules, exports/codes/layers verified)\n');
}
