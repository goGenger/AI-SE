'use strict';

/**
 * App Bootstrap / service entry point.
 *
 * Responsibilities:
 *   - read configuration exactly once at startup (Config Loader)
 *   - create the node:http server
 *   - wire the router, health handlers and the auth middleware mount point
 *   - install top-level traps so start-up failures and uncaught runtime errors
 *     become the 500 error envelope / a clean exit instead of a crash dump
 *   - listen on PORT (default 3000) and log lifecycle events to stdout
 *
 * Business handlers for this slice are attached by later tasks through
 * app.addRoute()/app.addProtectedRoute() or app.mount().
 */

const http = require('node:http');

const { loadConfig, describeConfig } = require('./config.js');
const { logger: defaultLogger, createLogger, describeError } = require('./logger.js');
const { createApp } = require('./http/app.js');
const { registerRoutes } = require('./http/registerHandler.js');
const { loginRoutes } = require('./http/loginHandler.js');
const { createUserRepository } = require('./store/userRepo.js');
const { createTaskRepository } = require('./store/taskRepo.js');
const { taskRoutes } = require('./http/taskHandler.js');
const { setSecretStore, createSecretStore } = require('./auth/secretStore.js');
const { authMiddleware } = require('./http/authMiddleware.js');
const { homeRoutes } = require('./http/homeHandler.js');

const DEFAULT_HOST = '0.0.0.0';
const SHUTDOWN_TIMEOUT_MS = 10000;
const DEFAULT_MAX_CONNECTIONS = 1024;
const DEFAULT_HEADERS_TIMEOUT_MS = 20000;
const DEFAULT_REQUEST_TIMEOUT_MS = 30000;
const DEFAULT_KEEP_ALIVE_TIMEOUT_MS = 5000;

/** Field name of the optional signing secret in the resolved configuration. */
const SIGNING_SECRET_FIELD = 'tokenSecret';

/**
 * Read the optional TOKEN_SECRET out of the resolved configuration. Kept in a
 * named helper so the secret never has to be interpolated at a call site (and so
 * startup logging can only ever see describeConfig()).
 */
function readSigningSecret(config) {
  const value = config && typeof config === 'object' ? config[SIGNING_SECRET_FIELD] : undefined;
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

/**
 * Build the shared per-process services once: the user repository over DATA_DIR
 * and the token signing-key store. Supplying the same services to the register
 * handler, the login handler and the auth middleware keeps a single source of
 * truth for user identities and token verification.
 */
function resolveServices(config, provided) {
  const base = provided && typeof provided === 'object' ? provided : {};
  const services = Object.assign({}, base);
  if (!services.userRepository && !services.users && !services.userRepo && !services.usersRepository) {
    services.userRepository = createUserRepository({ dataDir: config.dataDir });
  }
  if (!services.taskRepository && !services.tasks && !services.taskRepo && !services.tasksRepository) {
    services.taskRepository = createTaskRepository({ dataDir: config.dataDir });
  }
  if (!services.secretStore) {
    const signingSecret = readSigningSecret(config);
    services.secretStore = createSecretStore({ dataDir: config.dataDir, tokenSecret: signingSecret });
    if (typeof setSecretStore === 'function') {
      setSecretStore(services.secretStore);
    }
  }
  return services;
}

function buildServer(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const config = opts.config || loadConfig();
  const logger = opts.logger || defaultLogger;
  const services = resolveServices(config, opts.services);
  const appOptions = Object.assign({}, opts.appOptions);

  // Auth guard: the bearer middleware resolves the user repository and the
  // signing key from the services above, so protected routes reject missing,
  // malformed, tampered or truncated tokens with 401 UNAUTHORIZED (TR-9).
  const guard =
    typeof appOptions.authMiddleware === 'function' || appOptions.authMiddleware === null || appOptions.authMiddleware === false
      ? appOptions.authMiddleware
      : authMiddleware;

  const app = createApp(
    Object.assign({}, appOptions, {
      config,
      logger,
      authMiddleware: guard,
      services: Object.assign({}, services, appOptions.services || {}),
    })
  );

  // Public route wiring for this slice: GET / (FR-8.1 / AC-21).
  // The home page is server-rendered from a fixed template and sits in the
  // auth middleware public-path set, so it is served without a token.
  homeRoutes(app);

  // Business route wiring for this slice: POST /api/register (FR-1).
  // The user repository is resolved per request from ctx.services, so a
  // missing repository surfaces as a safe 500 envelope instead of a crash.
  registerRoutes(app);

  // Business route wiring for this slice: POST /api/login (FR-2).
  // Same resolution model: the user repository, password verifier and secret
  // store come from ctx.services per request, and failures stay envelopes.
  loginRoutes(app);

  // Business route wiring for this slice: the five task routes (FR-3/FR-4/FR-5).
  // Every route is registered as protected, so the shared bearer guard runs
  // before the handler, resolves the caller userId into the request context and
  // answers 401 UNAUTHORIZED for a missing, tampered or truncated token before
  // any task logic or store access can run.
  taskRoutes(app);

  // Protected mount point: the router treats every path outside the public set
  // (and the whole /api surface) as auth-guarded, so any further route attached
  // via app.addProtectedRoute()/app.addRoute() is covered as well.

  const handler = app.handleRequest;
  const server = http.createServer((req, res) => handler(req, res));

  server.maxConnections = typeof opts.maxConnections === 'number' ? opts.maxConnections : DEFAULT_MAX_CONNECTIONS;
  server.headersTimeout = DEFAULT_HEADERS_TIMEOUT_MS;
  server.requestTimeout = DEFAULT_REQUEST_TIMEOUT_MS;
  server.keepAliveTimeout = DEFAULT_KEEP_ALIVE_TIMEOUT_MS;
  server.on('clientError', (error, socket) => {
    if (socket && !socket.destroyed) {
      if (socket.writable) {
        socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
      } else {
        socket.destroy();
      }
    }
  });

  return { server, app, config, logger };
}

/**
 * Start the HTTP server. Resolves with { server, app, config, logger, url }
 * once the listening event fires.
 */
function startServer(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const built = buildServer(opts);
  const { server, app, config } = built;
  const logger = built.logger || defaultLogger;

  logger.info('configuration loaded', describeConfig(config));

  return new Promise((resolve, reject) => {
    let settled = false;
    server.once('error', (error) => {
      if (settled) {
        return;
      }
      settled = true;
      reject(error);
    });
    const onListening = () => {
      if (settled) {
        return;
      }
      settled = true;
      const address = server.address();
      const port = address && typeof address === 'object' ? address.port : config.port;
      logger.info('server listening', { port, dataDir: config.dataDir });
      resolve({ server, app, config, logger, url: 'http://127.0.0.1:' + port });
    };
    // Bind 0.0.0.0 by default so a container port mapping is reachable from
    // outside; an explicit opts.host or HOST env value still wins.
    const host = opts.host !== undefined ? opts.host : config.host !== undefined ? config.host : DEFAULT_HOST;
    server.listen(config.port, host, onListening);
  });
}

/**
 * Install process-wide traps. Uncaught runtime faults are logged (redacted) and
 * the process is shut down after draining the HTTP server; no stack trace or
 * secret is ever written to a client response.
 */
function installProcessErrorTraps(server, logger) {
  const activeLogger = logger || defaultLogger;
  let shuttingDown = false;

  const stop = () => {
    activeLogger.fatal('shutting down after unrecoverable error');
    const timer = setTimeout(() => process.exit(1), SHUTDOWN_TIMEOUT_MS);
    if (typeof timer.unref === 'function') {
      timer.unref();
    }
    if (server && typeof server.close === 'function') {
      try {
        server.close(() => process.exit(1));
      } catch (error) {
        process.exit(1);
      }
    } else {
      process.exit(1);
    }
  };

  process.on('uncaughtException', (error) => {
    activeLogger.error('uncaught exception', { error: describeError(error) });
    if (!shuttingDown) {
      shuttingDown = true;
      stop();
    }
  });

  process.on('unhandledRejection', (reason) => {
    activeLogger.error('unhandled rejection', { error: describeError(reason) });
  });
}

function installShutdownHandlers(server, logger) {
  const activeLogger = logger || defaultLogger;
  let closing = false;

  const shutdown = (signal) => {
    if (closing) {
      return;
    }
    closing = true;
    activeLogger.info('shutdown signal received', { signal });
    const timer = setTimeout(() => process.exit(0), SHUTDOWN_TIMEOUT_MS);
    if (typeof timer.unref === 'function') {
      timer.unref();
    }
    server.close(() => {
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

/** Full start-up path used by the `start` script and by tests. */
async function main() {
  let config;
  try {
    config = loadConfig();
  } catch (error) {
    const logger = createLogger();
    logger.fatal('failed to load configuration', { error: describeError(error) });
    process.exitCode = 1;
    return { ok: false, error };
  }

  const logger = createLogger({ level: config.logLevel });
  let started;
  try {
    started = await startServer({ config, logger });
  } catch (error) {
    const isAddressInUse = Boolean(error && error.code === 'EADDRINUSE');
    logger.fatal('server failed to start', {
      error: describeError(error),
      port: config.port,
    });
    process.exitCode = isAddressInUse ? 1 : 1;
    return { ok: false, error };
  }

  installProcessErrorTraps(started.server, logger);
  installShutdownHandlers(started.server, logger);

  return Object.assign({ ok: true }, started);
}

if (require.main === module) {
  main().catch((error) => {
    process.stdout.write(
      JSON.stringify({ level: 'fatal', msg: 'startup failed', error: describeError(error) }) + '\n'
    );
    process.exitCode = 1;
  });
}

module.exports = {
  SHUTDOWN_TIMEOUT_MS,
  DEFAULT_MAX_CONNECTIONS,
  buildServer,
  startServer,
  installProcessErrorTraps,
  installShutdownHandlers,
  main,
};
