'use strict';

/**
 * JSON Store.
 *
 * File-backed persistence primitive over a single JSON data file inside
 * DATA_DIR. It is deliberately business-agnostic: it reads and writes an opaque
 * collection (any JSON value) and protects concurrent access; it never inspects,
 * logs or interprets record fields.
 *
 * Guarantees
 *   - Startup load: a missing data file initialises the in-memory collection to
 *     an empty collection without throwing. An unreadable or corrupt file is
 *     preserved as a sidecar backup and the store starts from the empty
 *     collection instead of crashing the process.
 *   - Atomic replacement: save() serialises in memory first, writes to a temp
 *     file in the same directory, fsyncs it, then fs.renameSync()s it over the
 *     target path. A crash or concurrent reader never observes a half-written
 *     file, because rename() is atomic on POSIX filesystems.
 *   - In-process serialisation: every write goes through a promise mutex
 *     (runExclusive), so overlapping read-modify-write sequences are applied one
 *     after another and the final file is always valid JSON.
 *   - Secret hygiene: no method logs anything and toJSON() exposes only counts
 *     and file metadata, never record contents.
 *
 * Trust-boundary validation: the constructor validates DATA_DIR and the file
 * name (no separators, no traversal, no NUL) so a caller-supplied name can never
 * escape the data directory.
 */

const fs = require('node:fs');
const path = require('node:path');

const { createMutex } = require('./mutex.js');

const DEFAULT_FILE_NAME = 'data.json';
const DEFAULT_ENCODING = 'utf8';
const DEFAULT_MAX_BYTES = 64 * 1024 * 1024;
const TEMP_SUFFIX = '.tmp';
const CORRUPT_SUFFIX = '.corrupt';
const SAFE_FILE_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const UNSAFE_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

/** Error thrown for storage-layer failures (never a business error). */
class JsonStoreError extends Error {
  constructor(message, options) {
    const opts = options && typeof options === 'object' ? options : {};
    super(message);
    this.name = 'JsonStoreError';
    this.code = typeof opts.code === 'string' ? opts.code : 'STORE_ERROR';
    if (opts.cause !== undefined) {
      this.cause = opts.cause;
    }
  }
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/** Validate a file name so it cannot traverse outside the data directory. */
function sanitizeFileName(fileName, fallback) {
  const candidate = fileName === undefined || fileName === null ? fallback : fileName;
  if (typeof candidate !== 'string') {
    throw new JsonStoreError('Store file name must be a string', { code: 'INVALID_FILE_NAME' });
  }
  if (candidate !== candidate.trim() || candidate.length === 0) {
    throw new JsonStoreError('Store file name must not have surrounding whitespace', {
      code: 'INVALID_FILE_NAME',
    });
  }
  if (!SAFE_FILE_NAME.test(candidate) || candidate === '.' || candidate === '..') {
    throw new JsonStoreError('Store file name must be a plain file name without path separators', {
      code: 'INVALID_FILE_NAME',
    });
  }
  return candidate;
}

/** Resolve (and validate) the data directory; it is never a file. */
function resolveDataDir(dataDir) {
  if (!isNonEmptyString(dataDir)) {
    throw new JsonStoreError('DATA_DIR must be a non-empty path string', { code: 'INVALID_DATA_DIR' });
  }
  const absolute = path.resolve(dataDir);
  if (absolute.length === 0 || absolute.includes('\u0000')) {
    throw new JsonStoreError('DATA_DIR contains an invalid character', { code: 'INVALID_DATA_DIR' });
  }
  return absolute;
}

/** Deep copy that never shares structure with the caller (cycle-safe via JSON). */
function cloneValue(value) {
  if (value === undefined) {
    return undefined;
  }
  if (typeof structuredClone === 'function') {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}

/**
 * Drop own properties named __proto__/constructor/prototype so data read from a
 * tampered file cannot be used to pollute prototypes upstream.
 */
function stripUnsafeKeys(value, depth) {
  const level = typeof depth === 'number' ? depth : 0;
  if (level > 64 || value === null || typeof value !== 'object') {
    return value;
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      stripUnsafeKeys(item, level + 1);
    }
    return value;
  }
  for (const key of Object.keys(value)) {
    if (UNSAFE_KEYS.has(key)) {
      delete value[key];
      continue;
    }
    stripUnsafeKeys(value[key], level + 1);
  }
  return value;
}

/** Serialise a collection to pretty JSON text with a trailing newline. */
function serializeCollection(value, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const pretty = opts.pretty !== false;
  let text;
  try {
    text = JSON.stringify(value, null, pretty ? 2 : 0);
  } catch (error) {
    throw new JsonStoreError('Collection is not JSON-serialisable', {
      code: 'SERIALIZE_FAILED',
      cause: error,
    });
  }
  if (text === undefined) {
    throw new JsonStoreError('Collection is not JSON-serialisable', { code: 'SERIALIZE_FAILED' });
  }
  return pretty ? text + '\n' : text;
}

/** Parse collection text, rejecting non-JSON and prototype-polluting keys. */
function deserializeCollection(text) {
  const raw = typeof text === 'string' ? text.trim() : '';
  if (raw.length === 0) {
    return null;
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new JsonStoreError('Store file does not contain valid JSON', {
      code: 'PARSE_FAILED',
      cause: error,
    });
  }
  return stripUnsafeKeys(parsed, 0);
}

/** Best-effort directory fsync so a rename survives a power loss on POSIX. */
function fsyncDirectorySync(directory) {
  let fd = null;
  try {
    fd = fs.openSync(directory, 'r');
    fs.fsyncSync(fd);
  } catch (error) {
    // Directory fsync is not supported everywhere; durability is best effort.
  } finally {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch (error) {
        // ignore
      }
    }
  }
}

/**
 * Atomically replace targetPath: write a temp file in the same directory,
 * flush it, then rename it over the target.
 */
function atomicWriteFileSync(targetPath, contents, options) {
  const opts = options && typeof options === 'object' ? options : {};
  if (!isNonEmptyString(targetPath)) {
    throw new JsonStoreError('Target path must be a non-empty string', { code: 'INVALID_TARGET' });
  }
  if (typeof contents !== 'string') {
    throw new JsonStoreError('File contents must be a string', { code: 'INVALID_CONTENTS' });
  }
  const directory = path.dirname(targetPath);
  const base = path.basename(targetPath);
  const tempPath = path.join(
    directory,
    '.' + base + '.' + process.pid + '.' + Date.now().toString(36) + '.' + Math.random().toString(36).slice(2) + TEMP_SUFFIX
  );

  let fd = null;
  try {
    fs.mkdirSync(directory, { recursive: true });
    fd = fs.openSync(tempPath, 'wx', 0o600);
    fs.writeFileSync(fd, contents, { encoding: DEFAULT_ENCODING });
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;
    fs.renameSync(tempPath, targetPath);
  } catch (error) {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch (closeError) {
        // ignore
      }
    }
    try {
      fs.unlinkSync(tempPath);
    } catch (unlinkError) {
      // The temp file was never created or the rename already moved it.
    }
    if (error instanceof JsonStoreError) {
      throw error;
    }
    throw new JsonStoreError('Failed to write store file atomically: ' + error.code, {
      code: 'WRITE_FAILED',
      cause: error,
    });
  }
  if (opts.fsyncDir !== false) {
    fsyncDirectorySync(directory);
  }
  return targetPath;
}

/** Count records for metadata without exposing any field value. */
function countRecords(value) {
  if (Array.isArray(value)) {
    return value.length;
  }
  if (isPlainObject(value)) {
    return Object.keys(value).length;
  }
  return value === null || value === undefined ? 0 : 1;
}

class JsonStore {
  /**
   * @param {object} options
   * @param {string} options.dataDir   absolute or relative DATA_DIR
   * @param {string} [options.fileName='data.json'] plain file name inside DATA_DIR
   * @param {any} [options.initialValue=null] value used when the file is absent
   * @param {{createEmpty?: () => any}} [options.createEmpty] empty-collection factory
   * @param {import('./mutex.js').Mutex} [options.mutex] shared mutex instance
   * @param {number} [options.maxBytes] refuse to load files larger than this
   * @param {boolean} [options.autoLoad=true] load immediately on construction
   */
  constructor(options) {
    const opts = options && typeof options === 'object' ? options : {};
    this.dataDir = resolveDataDir(opts.dataDir);
    this.fileName = sanitizeFileName(opts.fileName, DEFAULT_FILE_NAME);
    this.filePath = path.join(this.dataDir, this.fileName);
    this.maxBytes = Number.isInteger(opts.maxBytes) && opts.maxBytes > 0 ? opts.maxBytes : DEFAULT_MAX_BYTES;
    this.createEmpty =
      typeof opts.createEmpty === 'function'
        ? opts.createEmpty
        : () => (opts.initialValue === undefined ? null : cloneValue(opts.initialValue));
    this.mutex = opts.mutex && typeof opts.mutex.runExclusive === 'function' ? opts.mutex : createMutex({ name: this.fileName });
    this._collection = this.createEmpty();
    this._loaded = false;
    this._fileExists = false;
    this._corrupt = false;
    this._corruptBackupPath = null;
    this._lastSavedAt = null;
    if (opts.autoLoad !== false) {
      this.load();
    }
  }

  /** Load the collection from disk (missing file => empty collection, no throw). */
  load() {
    return this.reload();
  }

  /**
   * Re-read the data file from disk into memory. Returns the loaded collection.
   * A corrupt file is backed up and replaced in memory by an empty collection.
   */
  reload() {
    let text = null;
    try {
      const stat = fs.statSync(this.filePath);
      this._fileExists = true;
      if (stat.isDirectory()) {
        throw new JsonStoreError('Store path points at a directory', { code: 'INVALID_TARGET' });
      }
      if (stat.size > this.maxBytes) {
        throw new JsonStoreError('Store file exceeds the configured size limit', { code: 'FILE_TOO_LARGE' });
      }
      text = fs.readFileSync(this.filePath, DEFAULT_ENCODING);
    } catch (error) {
      if (error && error.code === 'ENOENT') {
        this._fileExists = false;
        this._corrupt = false;
        this._corruptBackupPath = null;
        this._collection = this.createEmpty();
        this._loaded = true;
        return this._collection;
      }
      if (error instanceof JsonStoreError) {
        throw error;
      }
      throw new JsonStoreError('Failed to read store file: ' + (error && error.code), {
        code: 'READ_FAILED',
        cause: error,
      });
    }

    try {
      const parsed = deserializeCollection(text);
      this._collection = parsed === null ? this.createEmpty() : parsed;
      this._corrupt = false;
      this._corruptBackupPath = null;
    } catch (error) {
      if (!(error instanceof JsonStoreError) || error.code !== 'PARSE_FAILED') {
        throw error;
      }
      this._corrupt = true;
      this._corruptBackupPath = this._backupCorruptFile();
      this._collection = this.createEmpty();
    }
    this._loaded = true;
    this._lastSavedAt = null;
    return this._collection;
  }

  /** Move a corrupt file aside so the original bytes are never silently lost. */
  _backupCorruptFile() {
    const backupPath = this.filePath + '.' + Date.now() + CORRUPT_SUFFIX;
    try {
      fs.renameSync(this.filePath, backupPath);
      return backupPath;
    } catch (error) {
      return null;
    }
  }

  /** Current collection as a deep copy (safe to mutate in the caller). */
  get() {
    return this.snapshot();
  }

  /** Current collection as a deep copy. */
  snapshot() {
    return cloneValue(this._collection);
  }

  /** Serialised JSON text of the current (or supplied) collection. */
  serialize(value) {
    return serializeCollection(arguments.length > 0 ? value : this._collection);
  }

  /** Parse collection JSON text (returns the value, throws JsonStoreError). */
  deserialize(text) {
    return deserializeCollection(text);
  }

  /** Replace the in-memory collection without writing to disk. */
  set(value) {
    this._collection = value === undefined ? this.createEmpty() : cloneValue(value);
    return this._collection;
  }

  /** True when the store holds no records. */
  isEmpty() {
    return countRecords(this._collection) === 0;
  }

  /** Serialise and atomically persist the collection; resolves after the rename. */
  save(value) {
    if (arguments.length > 0) {
      this.set(value);
    }
    return this.mutex.runExclusive(() => this.saveSync());
  }

  /** Synchronous persist path; callers already holding the mutex may use it. */
  saveSync(value) {
    if (arguments.length > 0) {
      this.set(value);
    }
    const text = serializeCollection(this._collection);
    atomicWriteFileSync(this.filePath, text);
    this._fileExists = true;
    this._corrupt = false;
    this._lastSavedAt = new Date().toISOString();
    this._loaded = true;
    return this.filePath;
  }

  /**
   * Queued read-modify-write: deep-copies the collection, runs the mutator,
   * replaces the collection with its result (or the mutated draft) and persists
   * atomically. All calls are serialised, so concurrent updates never interleave.
   */
  update(mutator, options) {
    const opts = options && typeof options === 'object' ? options : {};
    if (typeof mutator !== 'function') {
      return Promise.reject(new TypeError('update requires a mutator function'));
    }
    return this.mutex.runExclusive(async () => {
      const draft = this.snapshot();
      const result = await mutator(draft);
      this._collection = result === undefined ? draft : cloneValue(result);
      if (opts.persist !== false) {
        this.saveSync();
      }
      return this.snapshot();
    });
  }

  /** Run fn inside the in-process critical section (delegates to the mutex). */
  runExclusive(fn) {
    return this.mutex.runExclusive(fn);
  }

  /** Resolves when every queued operation has settled. */
  idle() {
    return this.mutex.idle();
  }

  /** Resolves when every queued operation has settled. */
  async drain() {
    await this.mutex.idle();
  }

  /** Safe, secret-free metadata describing the store (record values excluded). */
  stats() {
    let size = null;
    let mtime = null;
    try {
      const stat = fs.statSync(this.filePath);
      size = stat.size;
      mtime = stat.mtime.toISOString();
    } catch (error) {
      size = null;
      mtime = null;
    }
    return {
      file: this.fileName,
      dataDir: this.dataDir,
      exists: this._fileExists,
      loaded: this._loaded,
      corrupt: this._corrupt,
      corruptBackup: this._corruptBackupPath === null ? null : path.basename(this._corruptBackupPath),
      records: countRecords(this._collection),
      size,
      mtime,
      lastSavedAt: this._lastSavedAt,
    };
  }

  /** JSON.stringify(store) yields metadata only, never record contents. */
  toJSON() {
    return this.stats();
  }
}

/** Factory: create a JSON store for one data file inside DATA_DIR. */
function createJsonStore(options) {
  return new JsonStore(options);
}

module.exports = {
  JsonStore,
  JsonStoreError,
  createJsonStore,
  atomicWriteFileSync,
  serializeCollection,
  deserializeCollection,
  sanitizeFileName,
  resolveDataDir,
  cloneValue,
  countRecords,
  DEFAULT_FILE_NAME,
  DEFAULT_MAX_BYTES,
  TEMP_SUFFIX,
};
