'use strict';

/**
 * Store Mutex / Write Queue.
 *
 * In-process promise mutex that serialises asynchronous critical sections inside
 * a single Node process. runExclusive(fn) appends fn to a FIFO queue and starts
 * it only after every previously enqueued task has settled, so check-then-act
 * sequences (uniqueness check + insert + persist) cannot interleave.
 *
 * Robustness properties:
 *   - A rejected task never breaks the queue: the rejection reaches the caller
 *     of that task while the next waiter still runs.
 *   - The queue itself never rejects, so an unawaited task cannot surface as an
 *     unhandled rejection caused by the queue.
 *   - The primitive carries no business knowledge; it only orders callbacks.
 *
 * Note: the mutex is NOT reentrant. Calling runExclusive() from inside a task
 * queued on the same instance would deadlock; code that already holds the lock
 * must use the synchronous persist path (JsonStore#saveSync) instead of
 * scheduling another queued task on the same instance.
 */

const noop = () => {};

class Mutex {
  constructor(options) {
    const opts = options && typeof options === 'object' ? options : {};
    this.name = typeof opts.name === 'string' && opts.name.length > 0 ? opts.name : 'mutex';
    this._tail = Promise.resolve();
    this._waiting = 0;
    this._running = false;
    this._completed = 0;
    this._rejected = 0;
  }

  /** Number of tasks queued but not started yet. */
  get waiting() {
    return this._waiting;
  }

  /** Alias for waiting, useful when the mutex is described as a write queue. */
  get queueLength() {
    return this._waiting;
  }

  /** True while a task currently owns the lock. */
  get running() {
    return this._running;
  }

  /** Alias for running. */
  get locked() {
    return this._running;
  }

  /** Number of tasks that finished successfully. */
  get completed() {
    return this._completed;
  }

  /** Number of tasks that threw. */
  get failed() {
    return this._rejected;
  }

  /** True when nothing is running and nothing is queued. */
  isIdle() {
    return this._running === false && this._waiting === 0;
  }

  /**
   * Queue fn and run it once every earlier task has settled. Resolves with the
   * value returned by fn and rejects if fn throws or rejects.
   *
   * @param {() => any | Promise<any>} fn
   * @returns {Promise<any>}
   */
  runExclusive(fn) {
    if (typeof fn !== 'function') {
      return Promise.reject(new TypeError('runExclusive requires a function to execute'));
    }
    this._waiting += 1;
    const task = this._tail.then(() => {
      this._waiting -= 1;
      this._running = true;
      return Promise.resolve()
        .then(() => fn())
        .then(
          (value) => {
            this._completed += 1;
            return value;
          },
          (error) => {
            this._rejected += 1;
            throw error;
          }
        )
        .finally(() => {
          this._running = false;
        });
    });
    // Keep the chain resolved so one failure cannot stall the queue, while the
    // caller still observes the original rejection through task.
    this._tail = task.then(noop, noop);
    return task;
  }

  /** Resolves once every enqueued task has settled. Never rejects. */
  idle() {
    return this._tail.then(noop, noop);
  }

  /** Awaitable alias for idle(). */
  async drain() {
    await this.idle();
  }
}

/** Create an isolated mutex (one per store file or per protected resource). */
function createMutex(options) {
  return new Mutex(options);
}

/** Shared process-wide queue used by helpers that do not own a mutex. */
const sharedMutex = new Mutex({ name: 'store' });

/** Convenience wrapper around the shared process-wide mutex. */
function runExclusive(fn) {
  return sharedMutex.runExclusive(fn);
}

module.exports = {
  Mutex,
  createMutex,
  sharedMutex,
  runExclusive,
};
