'use strict';

/**
 * Task Repository.
 *
 * Owns the task record model on top of the JSON Store and the Store Mutex:
 *   - id         UUID string generated with crypto.randomUUID()
 *   - ownerId    UUID of the owning user (attribution for FR-6 isolation)
 *   - title      trimmed string, 1-100 Unicode code points
 *   - dueDate    'YYYY-MM-DD' real calendar date, or null when omitted
 *   - done       boolean
 *   - createdAt  ISO 8601 string
 *   - updatedAt  ISO 8601 string (equal to createdAt on creation)
 *
 * Guarantees
 *   - Every read, update and delete is scoped by ownerId: no lookup can ever
 *     return another user's task, so cross-user access is indistinguishable from
 *     a nonexistent id.
 *   - Each write happens inside ONE mutex critical section: the record is built,
 *     the collection is replaced in memory and the file is persisted atomically
 *     (store.set + store.saveSync), so concurrent requests cannot interleave a
 *     partial write. The mutex is not reentrant, hence saveSync is used inside
 *     the lock instead of scheduling another queued task.
 *   - Records handed to callers are deep copies; the internal collection is
 *     never shared, so a caller cannot mutate repository state by accident.
 *   - Trust-boundary validation is repeated here (defence in depth) so a
 *     malformed call reports a semantic result object ({ ok: false, code })
 *     rather than writing anything or throwing a storage error.
 */

const crypto = require('node:crypto');

const { ERROR_CODES } = require('../errors/errorEnvelope.js');
const { createJsonStore } = require('./jsonStore.js');
const { createMutex } = require('./mutex.js');

const TASKS_FILE_NAME = 'tasks.json';
const TITLE_MIN_CODEPOINTS = 1;
const TITLE_MAX_CODEPOINTS = 100;
const DUE_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
const MIN_DUE_DATE_YEAR = 1;
const MAX_DUE_DATE_YEAR = 9999;

const NOT_FOUND = ERROR_CODES.NOT_FOUND;
const VALIDATION_ERROR = ERROR_CODES.VALIDATION_ERROR;
const TITLE_INVALID = ERROR_CODES.TITLE_INVALID;
const DATE_INVALID = ERROR_CODES.DATE_INVALID;

/** Fields that may appear in a client-visible task object (no ownerId). */
const PUBLIC_TASK_FIELDS = Object.freeze(['id', 'title', 'dueDate', 'done', 'createdAt', 'updatedAt']);

/** Fields a PATCH may update. */
const UPDATABLE_FIELDS = Object.freeze(['title', 'dueDate', 'done']);

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/** Count Unicode code points so astral characters (emoji) count as one. */
function countCodePoints(value) {
  return typeof value === 'string' ? [...value].length : 0;
}

/** True when the integers form a real calendar day (rejects 2026-02-30, ...). */
function isRealCalendarDay(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return false;
  }
  const probe = new Date(Date.UTC(2000, month - 1, day));
  probe.setUTCFullYear(year);
  return (
    probe.getUTCFullYear() === year && probe.getUTCMonth() === month - 1 && probe.getUTCDate() === day
  );
}

/** True for a syntactically valid YYYY-MM-DD string that is a real calendar date. */
function isValidDueDate(value) {
  if (typeof value !== 'string') {
    return false;
  }
  const match = DUE_DATE_PATTERN.exec(value);
  if (match === null) {
    return false;
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (!Number.isInteger(year) || year < MIN_DUE_DATE_YEAR || year > MAX_DUE_DATE_YEAR) {
    return false;
  }
  return isRealCalendarDay(year, month, day);
}

/** Deep copy so callers can never mutate repository state. */
function clone(value) {
  if (value === undefined) {
    return undefined;
  }
  return typeof structuredClone === 'function' ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}

/** Public projection of a record: the fixed task shape, never the ownerId. */
function toPublicTask(record) {
  if (!isPlainObject(record)) {
    return null;
  }
  const task = {};
  task.id = record.id;
  task.title = record.title;
  task.dueDate = record.dueDate === undefined ? null : record.dueDate;
  task.done = record.done === true;
  task.createdAt = record.createdAt;
  task.updatedAt = record.updatedAt;
  return task;
}

/** Normalise a title: trim, then enforce 1-100 code points. */
function prepareTitle(value) {
  if (typeof value !== 'string') {
    return { ok: false, code: TITLE_INVALID };
  }
  const trimmed = value.trim();
  const length = countCodePoints(trimmed);
  if (length < TITLE_MIN_CODEPOINTS || length > TITLE_MAX_CODEPOINTS) {
    return { ok: false, code: TITLE_INVALID };
  }
  return { ok: true, title: trimmed };
}

/** Normalise a due date: undefined/null -> null, otherwise a real YYYY-MM-DD. */
function prepareDueDate(value) {
  if (value === undefined || value === null) {
    return { ok: true, dueDate: null };
  }
  if (!isValidDueDate(value)) {
    return { ok: false, code: DATE_INVALID };
  }
  return { ok: true, dueDate: value };
}

class TaskRepository {
  /**
   * @param {object} options
   * @param {string} [options.dataDir]  DATA_DIR used to build a JSON store
   * @param {import('./jsonStore.js').JsonStore} [options.store] existing store
   * @param {string} [options.fileName='tasks.json']
   * @param {import('./mutex.js').Mutex} [options.mutex] shared mutex
   * @param {boolean} [options.autoLoad=true]
   */
  constructor(options) {
    const opts = options && typeof options === 'object' ? options : {};
    if (opts.store && typeof opts.store.runExclusive === 'function') {
      this.store = opts.store;
    } else {
      this.store = createJsonStore({
        dataDir: opts.dataDir,
        fileName: isNonEmptyString(opts.fileName) ? opts.fileName : TASKS_FILE_NAME,
        createEmpty: () => [],
      });
    }
    this.mutex =
      opts.mutex && typeof opts.mutex.runExclusive === 'function'
        ? opts.mutex
        : this.store.mutex && typeof this.store.mutex.runExclusive === 'function'
          ? this.store.mutex
          : createMutex({ name: 'tasks' });
    this._tasks = [];
    if (opts.autoLoad !== false) {
      this.load();
    }
  }

  /** (Re)load the task collection from disk. */
  load() {
    const loaded = this.store.get();
    this._tasks = Array.isArray(loaded)
      ? loaded.filter((record) => isPlainObject(record)).map((record) => clone(record))
      : [];
    return this._tasks.length;
  }

  reload() {
    return this.load();
  }

  /** Number of stored tasks across every owner. */
  size() {
    return this._tasks.length;
  }

  /** Every task owned by ownerId, as deep copies (insertion order). */
  listTasksByOwner(ownerId) {
    if (!isNonEmptyString(ownerId)) {
      return [];
    }
    const out = [];
    for (const record of this._tasks) {
      if (record.ownerId === ownerId) {
        out.push(clone(record));
      }
    }
    return out;
  }

  /** Alias used by the route handlers. */
  listByOwner(ownerId) {
    return this.listTasksByOwner(ownerId);
  }

  /**
   * Owner-scoped lookup: returns the record only when both the id AND the
   * ownerId match, so a cross-user read behaves exactly like a missing id.
   */
  findTaskByIdAndOwner(id, ownerId) {
    if (!isNonEmptyString(id) || !isNonEmptyString(ownerId)) {
      return null;
    }
    for (const record of this._tasks) {
      if (record.id === id && record.ownerId === ownerId) {
        return clone(record);
      }
    }
    return null;
  }

  /** Alias with the (ownerId, id) argument order. */
  findTaskByOwnerAndId(ownerId, id) {
    return this.findTaskByIdAndOwner(id, ownerId);
  }

  /** Alias used by the route handlers. */
  findByOwner(ownerId, id) {
    return this.findTaskByIdAndOwner(id, ownerId);
  }

  /** Build a validated task draft; returns a semantic result on bad input. */
  _buildRecord(ownerId, title, dueDate) {
    if (!isNonEmptyString(ownerId)) {
      return { ok: false, code: VALIDATION_ERROR };
    }
    const titleResult = prepareTitle(title);
    if (titleResult.ok !== true) {
      return titleResult;
    }
    const dateResult = prepareDueDate(dueDate);
    if (dateResult.ok !== true) {
      return dateResult;
    }
    const now = new Date().toISOString();
    return {
      ok: true,
      record: {
        id: crypto.randomUUID(),
        ownerId,
        title: titleResult.title,
        dueDate: dateResult.dueDate,
        done: false,
        createdAt: now,
        updatedAt: now,
      },
    };
  }

  /**
   * Insert a task for an owner inside one mutex critical section.
   *
   * @param {{ownerId?: string, title?: string, dueDate?: string|null}} input
   * @returns {Promise<{ok: true, task: object, record: object}|{ok: false, code: string}>}
   */
  createTask(input) {
    const value = isPlainObject(input) ? input : {};
    const ownerId = value.ownerId;
    const title = value.title;
    const dueDate = value.dueDate;
    return this.mutex.runExclusive(async () => {
      const draft = this._buildRecord(ownerId, title, dueDate);
      if (draft.ok !== true) {
        return draft;
      }
      const next = this._tasks.slice();
      next.push(draft.record);
      this._tasks = next;
      this.store.set(next);
      this.store.saveSync();
      return { ok: true, task: toPublicTask(draft.record), record: clone(draft.record) };
    });
  }

  /** Alias matching the architecture naming. */
  insertTask(input) {
    return this.createTask(input);
  }

  /**
   * Owner-scoped update inside one mutex critical section. Only the provided
   * whitelisted fields are applied; updatedAt is always refreshed.
   *
   * @returns {Promise<{ok: true, task: object}|{ok: false, code: string}>}
   */
  updateTaskByIdAndOwner(id, ownerId, patch) {
    const changes = isPlainObject(patch) ? patch : {};
    return this.mutex.runExclusive(async () => {
      if (!isNonEmptyString(id) || !isNonEmptyString(ownerId)) {
        return { ok: false, code: NOT_FOUND };
      }
      const index = this._tasks.findIndex((record) => record.id === id && record.ownerId === ownerId);
      if (index === -1) {
        return { ok: false, code: NOT_FOUND };
      }
      const current = this._tasks[index];
      const updated = clone(current);
      for (const field of UPDATABLE_FIELDS) {
        if (!Object.prototype.hasOwnProperty.call(changes, field)) {
          continue;
        }
        if (field === 'title') {
          const titleResult = prepareTitle(changes.title);
          if (titleResult.ok !== true) {
            return titleResult;
          }
          updated.title = titleResult.title;
          continue;
        }
        if (field === 'dueDate') {
          const dateResult = prepareDueDate(changes.dueDate);
          if (dateResult.ok !== true) {
            return dateResult;
          }
          updated.dueDate = dateResult.dueDate;
          continue;
        }
        if (typeof changes.done !== 'boolean') {
          return { ok: false, code: VALIDATION_ERROR };
        }
        updated.done = changes.done;
      }
      updated.updatedAt = new Date().toISOString();
      const next = this._tasks.slice();
      next[index] = updated;
      this._tasks = next;
      this.store.set(next);
      this.store.saveSync();
      return { ok: true, task: toPublicTask(updated), record: clone(updated) };
    });
  }

  /** Alias with the (ownerId, id, patch) argument order. */
  updateTaskByOwnerAndId(ownerId, id, patch) {
    return this.updateTaskByIdAndOwner(id, ownerId, patch);
  }

  /**
   * Owner-scoped delete inside one mutex critical section. A miss (unknown id or
   * another owner's task) reports NOT_FOUND and changes nothing.
   *
   * @returns {Promise<{ok: true, task: object}|{ok: false, code: string}>}
   */
  deleteTaskByIdAndOwner(id, ownerId) {
    return this.mutex.runExclusive(async () => {
      if (!isNonEmptyString(id) || !isNonEmptyString(ownerId)) {
        return { ok: false, code: NOT_FOUND };
      }
      const index = this._tasks.findIndex((record) => record.id === id && record.ownerId === ownerId);
      if (index === -1) {
        return { ok: false, code: NOT_FOUND };
      }
      const removed = this._tasks[index];
      const next = this._tasks.slice();
      next.splice(index, 1);
      this._tasks = next;
      this.store.set(next);
      this.store.saveSync();
      return { ok: true, task: toPublicTask(removed), record: clone(removed) };
    });
  }

  /** Alias with the (ownerId, id) argument order. */
  deleteTaskByOwnerAndId(ownerId, id) {
    return this.deleteTaskByIdAndOwner(id, ownerId);
  }

  /** True when the mutex queue is empty. */
  isIdle() {
    return this.mutex.isIdle ? this.mutex.isIdle() : this.mutex.waiting === 0;
  }

  /** Resolves once every queued write has settled. */
  waitForIdle() {
    return typeof this.mutex.idle === 'function' ? this.mutex.idle() : Promise.resolve();
  }

  /** Secret-free metadata: counts and file info only, never task contents. */
  stats() {
    return {
      file: this.store.fileName,
      tasks: this._tasks.length,
      store: typeof this.store.stats === 'function' ? this.store.stats() : null,
    };
  }

  /** JSON.stringify(repository) must never expose record contents. */
  toJSON() {
    return this.stats();
  }
}

/** Factory: build a task repository over DATA_DIR (or an injected store). */
function createTaskRepository(options) {
  return new TaskRepository(options);
}

module.exports = {
  TASKS_FILE_NAME,
  TITLE_MIN_CODEPOINTS,
  TITLE_MAX_CODEPOINTS,
  PUBLIC_TASK_FIELDS,
  UPDATABLE_FIELDS,
  NOT_FOUND,
  VALIDATION_ERROR,
  TITLE_INVALID,
  DATE_INVALID,
  TaskRepository,
  createTaskRepository,
  toPublicTask,
  prepareTitle,
  prepareDueDate,
  countCodePoints,
  isValidDueDate,
};
