'use strict';

/**
 * Tasks Schema Migration (DATABASE slice S2-T03).
 *
 * Forward-only, idempotent migration of the `tasks` collection inside DATA_DIR
 * (tasks.json) up to the version declared by src/store/tasksSchema.js.
 *
 * Because the store is a JSON document rather than a SQL engine, a "migration"
 * is a normalisation pass over the collection:
 *
 *   version 1  create the collection shape: the payload must be an array of task
 *              objects; every row gains the required owner_id scope plus the
 *              id/title/done/created_at/updated_at fields of the model.
 *   version 2  owner retrieval path: rows are canonicalised so the owner index
 *              (idx_tasks_owner_id) and the created_at/updated_at ISO columns are
 *              consistent, and a row whose created_at equals updated_at is left
 *              untouched while a missing updated_at is set to created_at.
 *
 * Guarantees
 *   - Owner scope is never widened: a row without a usable ownerId is left out of
 *     the migrated collection and reported as rejected, so no owner-less task can
 *     become visible through any retrieval path.
 *   - The pass is idempotent: running it twice yields the same collection and
 *     reports no further changes.
 *   - The rewrite goes through the jsonStore atomic write (temp file + rename) so
 *     a crash never leaves a half-written data file, and a fresh file is only
 *     written when the pass actually changed something.
 *   - Nothing here throws for malformed rows: problems are collected and reported.
 */

const { createJsonStore } = require('./jsonStore.js');
const { createMutex } = require('./mutex.js');

const {
  SCHEMA_VERSION,
  TASKS_FILE_NAME,
  OWNER_COLUMN,
  COLUMN_TO_FIELD,
  FIELD_TO_COLUMN,
  normalizeTaskRecord,
} = require('./tasksSchema.js');

/** Map a legacy snake_case row onto the canonical camelCase projection. */
function toCanonicalInput(row) {
  if (row === null || typeof row !== 'object' || Array.isArray(row)) {
    return null;
  }
  const input = {};
  for (const field of Object.keys(FIELD_TO_COLUMN)) {
    const column = FIELD_TO_COLUMN[field];
    const source = Object.prototype.hasOwnProperty.call(row, field) ? row[field] : row[column];
    input[field] = source === undefined ? null : source;
  }
  if (input.ownerId === null && row[OWNER_COLUMN] !== undefined) {
    input.ownerId = row[OWNER_COLUMN];
  }
  return input;
}

/** Migration 1: initial tasks collection shape, owner-scoped. */
function migrationInitialShape(collection, context) {
  const changed = [];
  const rejected = [];
  const rows = [];
  const source = Array.isArray(collection) ? collection : [];
  for (let index = 0; index < source.length; index += 1) {
    const candidate = toCanonicalInput(source[index]);
    const simpleOwner = candidate && typeof candidate.ownerId === 'string' && candidate.ownerId.length > 0;
    if (!simpleOwner) {
      rejected.push({ index, reason: 'ownerId is required on every task record' });
      continue;
    }
    const normalized = normalizeTaskRecord(candidate, { now: context.now });
    if (normalized.ok !== true) {
      rejected.push({ index, reason: normalized.problems.join('; ') });
      continue;
    }
    rows.push(normalized.record);
    if (Array.isArray(collection) === false || source.length !== rows.length) {
      changed.push(index);
    }
  }
  if (Array.isArray(collection) === false) {
    changed.push('collection');
  }
  return { collection: rows, changed, rejected };
}

/** Migration 2: consistent owner-scoped columns and ISO timestamps. */
function migrationOwnerIndexAndTimestamps(collection, context) {
  const changed = [];
  const rejected = [];
  const rows = [];
  const source = Array.isArray(collection) ? collection : [];
  for (let index = 0; index < source.length; index += 1) {
    const row = source[index];
    const input = toCanonicalInput(row);
    if (input === null || typeof input.ownerId !== 'string' || input.ownerId.length === 0) {
      rejected.push({ index, reason: 'ownerId is required on every task record' });
      continue;
    }
    const normalized = normalizeTaskRecord(input, { strict: true, now: context.now });
    if (normalized.ok !== true) {
      rejected.push({ index, reason: normalized.problems.join('; ') });
      continue;
    }
    rows.push(normalized.record);
    if (row.updatedAt === undefined || row.updatedAt === null) {
      changed.push(index);
    }
  }
  return { collection: rows, changed, rejected };
}

/** Ordered migration list; `version` is the schema version reached. */
const TASKS_MIGRATIONS = Object.freeze([
  Object.freeze({
    version: 1,
    name: 'tasks-initial-shape',
    description: 'Create the owner-scoped tasks collection with id, owner_id, title, due_date, done, created_at and updated_at.',
    up: migrationInitialShape,
  }),
  Object.freeze({
    version: 2,
    name: 'tasks-owner-index-timestamps',
    description: 'Canonicalise rows for the owner_id index and keep created_at/updated_at ISO and consistent.',
    up: migrationOwnerIndexAndTimestamps,
  }),
]);

/**
 * Run every migration in order over an in-memory collection.
 *
 * @param {any[]|any} collection candidate tasks.json payload
 * @param {{ now?: string, fromVersion?: number }} [options]
 * @returns {{ collection: object[], applied: object[], changed: boolean, rejected: object[], version: number }}
 */
function runTasksMigrations(collection, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const context = { now: opts.now };
  const fromVersion = Number.isInteger(opts.fromVersion) ? opts.fromVersion : 0;
  let current = collection;
  const applied = [];
  const rejected = [];
  for (const migration of TASKS_MIGRATIONS) {
    if (migration.version <= fromVersion) {
      continue;
    }
    const result = migration.up(current, context);
    current = result.collection;
    for (const entry of result.rejected) {
      rejected.push({ version: migration.version, index: entry.index, reason: entry.reason });
    }
    applied.push({
      version: migration.version,
      name: migration.name,
      description: migration.description,
      changedRows: result.changed.length,
    });
  }
  return {
    collection: Array.isArray(current) ? current : [],
    applied,
    changed: applied.some((entry) => entry.changedRows > 0),
    rejected,
    version: SCHEMA_VERSION,
  };
}

/** Load, migrate and (when needed) atomically rewrite DATA_DIR/tasks.json. */
function migrateTasksStore(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const store =
    opts.store && typeof opts.store.runExclusive === 'function'
      ? opts.store
      : createJsonStore({
          dataDir: opts.dataDir,
          fileName: TASKS_FILE_NAME,
          createEmpty: () => [],
        });
  const mutex =
    opts.mutex && typeof opts.mutex.runExclusive === 'function'
      ? opts.mutex
      : store.mutex && typeof store.mutex.runExclusive === 'function'
        ? store.mutex
        : createMutex({ name: 'tasks-migration' });
  const fromVersion = Number.isInteger(opts.fromVersion) ? opts.fromVersion : 0;
  const persist = opts.persist !== false;

  return mutex.runExclusive(async () => {
    const loaded = store.get();
    const result = runTasksMigrations(loaded, { now: opts.now, fromVersion });
    const alreadyMigrated = fromVersion >= SCHEMA_VERSION;
    if (persist && alreadyMigrated === false) {
      store.set(result.collection);
      store.saveSync();
    }
    return {
      file: store.fileName,
      version: result.version,
      fromVersion,
      applied: result.applied,
      changed: result.changed,
      rejected: result.rejected,
      rows: result.collection.length,
      persisted: persist && alreadyMigrated === false,
    };
  });
}

/** True when the collection already satisfies the declared schema. */
function isMigrated(collection) {
  const result = runTasksMigrations(collection, { fromVersion: 0 });
  return result.applied.every((entry) => entry.changedRows === 0) && result.rejected.length === 0;
}

module.exports = {
  SCHEMA_VERSION,
  TASKS_MIGRATIONS,
  toCanonicalInput,
  runTasksMigrations,
  migrateTasksStore,
  isMigrated,
  COLUMN_TO_FIELD,
};
