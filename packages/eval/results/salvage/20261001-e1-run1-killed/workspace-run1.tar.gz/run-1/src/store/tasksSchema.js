'use strict';

/**
 * Tasks Schema (DATABASE slice S2-T03).
 *
 * Declarative description of the `tasks` collection persisted inside DATA_DIR
 * (data file tasks.json), plus the normalisation helper used at the storage
 * boundary so every persisted record matches the model:
 *
 *   id         PRIMARY KEY  UUID string (crypto.randomUUID)
 *   owner_id   NOT NULL     UUID of the owning user, indexed by idx_tasks_owner_id
 *   title      NOT NULL     trimmed, 1-100 Unicode code points
 *   due_date   NULL         YYYY-MM-DD real calendar date, or null when omitted
 *   done       NOT NULL     boolean, default false
 *   created_at NOT NULL     ISO 8601 string
 *   updated_at NOT NULL     ISO 8601 string; equals created_at on insert and is
 *                           refreshed by every owner-scoped update
 *
 * Owner scope
 *   The only retrieval path is keyed by owner_id: collection reads filter rows by
 *   owner_id and single-row reads match (id AND owner_id). Every operation in
 *   OWNER_SCOPED_OPERATIONS takes an ownerId argument, and no owner-less query
 *   form (lookup by id alone, list all, search all) is declared in this module,
 *   so the repository surface cannot express a request that ignores ownership.
 *
 * Persisted shape
 *   Records are stored in the camelCase projection (id, ownerId, title, dueDate,
 *   done, createdAt, updatedAt) that the HTTP layer returns. toColumnView() maps
 *   that projection onto the declared snake_case columns and fromColumnView()
 *   maps it back, keeping both spellings consistent.
 */

const crypto = require('node:crypto');

const TASKS_TABLE = 'tasks';
const TASKS_FILE_NAME = 'tasks.json';
const SCHEMA_VERSION = 2;
const PRIMARY_KEY_COLUMN = 'id';
const PRIMARY_KEY_INDEX_NAME = 'pk_tasks_id';
const OWNER_COLUMN = 'owner_id';
const OWNER_INDEX_NAME = 'idx_tasks_owner_id';
const TITLE_MIN_CODEPOINTS = 1;
const TITLE_MAX_CODEPOINTS = 100;
const DUE_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
const MIN_DUE_DATE_YEAR = 1;
const MAX_DUE_DATE_YEAR = 9999;
const ISO_TIMESTAMP_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

const COLUMNS = Object.freeze([
  Object.freeze({
    name: PRIMARY_KEY_COLUMN,
    type: 'uuid',
    nullable: false,
    primaryKey: true,
    defaultValue: null,
    note: 'UUIDv4 generated with crypto.randomUUID()',
  }),
  Object.freeze({
    name: OWNER_COLUMN,
    type: 'uuid',
    nullable: false,
    primaryKey: false,
    defaultValue: null,
    index: OWNER_INDEX_NAME,
    references: 'users.id',
    note: 'Owning user; required on every read and every write',
  }),
  Object.freeze({
    name: 'title',
    type: 'text',
    nullable: false,
    primaryKey: false,
    defaultValue: null,
    note: 'Trimmed, 1-100 Unicode code points',
  }),
  Object.freeze({
    name: 'due_date',
    type: 'text',
    nullable: true,
    primaryKey: false,
    defaultValue: null,
    note: 'YYYY-MM-DD real calendar date, null when omitted',
  }),
  Object.freeze({
    name: 'done',
    type: 'boolean',
    nullable: false,
    primaryKey: false,
    defaultValue: false,
    note: 'Completion flag, false on insert',
  }),
  Object.freeze({
    name: 'created_at',
    type: 'text',
    nullable: false,
    primaryKey: false,
    defaultValue: 'insert time',
    note: 'ISO 8601 string',
  }),
  Object.freeze({
    name: 'updated_at',
    type: 'text',
    nullable: false,
    primaryKey: false,
    defaultValue: 'insert time',
    note: 'ISO 8601 string; equals created_at on insert, refreshed on update',
  }),
]);

const INDEXES = Object.freeze([
  Object.freeze({
    name: PRIMARY_KEY_INDEX_NAME,
    columns: Object.freeze([PRIMARY_KEY_COLUMN]),
    unique: true,
    kind: 'primary-key',
    purpose: 'Uniqueness of the task id (UUID) and the point-lookup key.',
  }),
  Object.freeze({
    name: OWNER_INDEX_NAME,
    columns: Object.freeze([OWNER_COLUMN]),
    unique: false,
    kind: 'secondary',
    purpose: 'Owner retrieval path: list by owner_id and lookups by (id AND owner_id) both start from owner_id.',
  }),
]);

const OWNER_SCOPED_OPERATIONS = Object.freeze([
  Object.freeze({
    name: 'insertTask',
    scope: 'write',
    signature: 'insertTask({ ownerId, title, dueDate })',
    ownerArgument: 'ownerId',
    ownerRequired: true,
    result: 'ok true with task, or ok false with an error code',
  }),
  Object.freeze({
    name: 'listTasksByOwner',
    scope: 'read-many',
    signature: 'listTasksByOwner(ownerId)',
    ownerArgument: 'ownerId',
    ownerRequired: true,
    result: 'array of that owner rows only; the optional q filter is applied to these rows',
  }),
  Object.freeze({
    name: 'findTaskByIdAndOwner',
    scope: 'read-one',
    signature: 'findTaskByIdAndOwner(id, ownerId)',
    ownerArgument: 'ownerId',
    ownerRequired: true,
    result: 'the row when id AND owner_id match, otherwise null',
  }),
  Object.freeze({
    name: 'updateTaskByIdAndOwner',
    scope: 'write-one',
    signature: 'updateTaskByIdAndOwner(id, ownerId, patch)',
    ownerArgument: 'ownerId',
    ownerRequired: true,
    result: 'ok true with task, or ok false with an error code; updated_at is refreshed',
  }),
  Object.freeze({
    name: 'deleteTaskByIdAndOwner',
    scope: 'delete-one',
    signature: 'deleteTaskByIdAndOwner(id, ownerId)',
    ownerArgument: 'ownerId',
    ownerRequired: true,
    result: 'ok true with task, or ok false with an error code; a miss changes nothing',
  }),
]);

const RETRIEVAL_PATH = Object.freeze({
  key: OWNER_COLUMN,
  index: OWNER_INDEX_NAME,
  scope: 'owner',
  ownerlessQueriesAllowed: false,
  description: 'All task access is keyed by owner_id; there is no read or write path that omits it.',
  operations: Object.freeze(OWNER_SCOPED_OPERATIONS.map((operation) => operation.name)),
});

/** Query shapes that must never exist because they would ignore ownership. */
const FORBIDDEN_QUERY_FORMS = Object.freeze([
  'findById(id)',
  'findTaskById(id)',
  'listTasks()',
  'searchTasks(q)',
  'updateTaskById(id, patch)',
  'deleteTaskById(id)',
  'deleteAllTasks()',
]);

/** Persisted JSON field name for each logical column. */
const COLUMN_TO_FIELD = Object.freeze({
  id: 'id',
  owner_id: 'ownerId',
  title: 'title',
  due_date: 'dueDate',
  done: 'done',
  created_at: 'createdAt',
  updated_at: 'updatedAt',
});

const FIELD_TO_COLUMN = Object.freeze(
  Object.keys(COLUMN_TO_FIELD).reduce((acc, column) => {
    acc[COLUMN_TO_FIELD[column]] = column;
    return acc;
  }, {})
);

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.length > 0;
}

/** Count Unicode code points so an astral character (emoji) counts as one. */
function countCodePoints(value) {
  if (typeof value !== 'string') {
    return 0;
  }
  let count = 0;
  for (const point of value) {
    void point;
    count += 1;
  }
  return count;
}

/** True when the integers form a real calendar day (rejects 2026-02-30, and so on). */
function isRealCalendarDay(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return false;
  }
  const probe = new Date(Date.UTC(2000, month - 1, day));
  probe.setUTCFullYear(year);
  return (
    probe.getUTCFullYear() === year && probe.getUTCMonth() === month - 1 && probe.getUTCDate() === day
  );
}

/** True for a syntactically valid YYYY-MM-DD string that is a real calendar date. */
function isValidDueDateString(value) {
  if (typeof value !== 'string') {
    return false;
  }
  const match = DUE_DATE_PATTERN.exec(value);
  if (match === null) {
    return false;
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (!Number.isInteger(year) || year < MIN_DUE_DATE_YEAR || year > MAX_DUE_DATE_YEAR) {
    return false;
  }
  return isRealCalendarDay(year, month, day);
}

/** True for an ISO 8601 timestamp string with milliseconds and a Z suffix. */
function isIsoTimestamp(value) {
  if (typeof value !== 'string' || !ISO_TIMESTAMP_PATTERN.test(value)) {
    return false;
  }
  return Number.isNaN(Date.parse(value)) === false;
}

function readTitle(value, problems) {
  if (typeof value !== 'string') {
    problems.push('title must be a string of 1-100 Unicode code points');
    return null;
  }
  const trimmed = value.trim();
  const length = countCodePoints(trimmed);
  if (length < TITLE_MIN_CODEPOINTS || length > TITLE_MAX_CODEPOINTS) {
    problems.push('title must be 1-100 Unicode code points after trimming');
    return null;
  }
  return trimmed;
}

function readDueDate(value, problems) {
  if (value === undefined || value === null) {
    return null;
  }
  if (!isValidDueDateString(value)) {
    problems.push('dueDate must be a real YYYY-MM-DD calendar date or null');
    return null;
  }
  return value;
}

/**
 * Build a canonical persisted task record from a candidate value.
 *
 * With options.strict the record must already be complete (a missing id, done,
 * createdAt or updatedAt is reported as a problem). Otherwise the missing pieces
 * are backfilled: id via crypto.randomUUID(), done=false, dueDate=null and the
 * ISO createdAt/updatedAt pair, with the backfilled names listed in `repaired`.
 * A record without a usable ownerId is always rejected, because no owner-less
 * task may enter the store.
 *
 * @returns {{ ok: boolean, record: object|null, problems: string[], repaired: string[] }}
 */
function normalizeTaskRecord(input, options) {
  const opts = isPlainObject(options) ? options : {};
  const strict = opts.strict === true;
  const now = isIsoTimestamp(opts.now) ? opts.now : new Date().toISOString();
  if (!isPlainObject(input)) {
    return { ok: false, record: null, problems: ['task record must be a plain object'], repaired: [] };
  }
  const problems = [];
  const repaired = [];

  let id = isNonEmptyString(input.id) ? input.id : null;
  if (id === null) {
    if (strict) {
      problems.push('id is required');
    } else {
      id = crypto.randomUUID();
      repaired.push('id');
    }
  }

  const ownerId = isNonEmptyString(input.ownerId) ? input.ownerId : null;
  if (ownerId === null) {
    problems.push('ownerId is required on every task record');
  }

  const title = readTitle(input.title, problems);
  const dueDate = readDueDate(input.dueDate, problems);

  let done = typeof input.done === 'boolean' ? input.done : null;
  if (done === null) {
    if (strict) {
      problems.push('done must be a boolean');
    } else {
      done = false;
      repaired.push('done');
    }
  }

  let createdAt = isIsoTimestamp(input.createdAt) ? input.createdAt : null;
  if (createdAt === null) {
    if (strict) {
      problems.push('createdAt must be an ISO 8601 string');
    } else {
      repaired.push('createdAt');
    }
  }

  let updatedAt = isIsoTimestamp(input.updatedAt) ? input.updatedAt : null;
  if (updatedAt === null) {
    if (strict) {
      problems.push('updatedAt must be an ISO 8601 string');
    } else {
      repaired.push('updatedAt');
    }
  }

  const created = createdAt === null ? now : createdAt;
  const updated = updatedAt === null ? created : updatedAt;

  if (problems.length > 0) {
    return { ok: false, record: null, problems, repaired };
  }
  return {
    ok: true,
    record: { id, ownerId, title, dueDate, done, createdAt: created, updatedAt: updated },
    problems: [],
    repaired,
  };
}

/** Strict validation of an already persisted record (no backfilling). */
function validateTaskRecord(record) {
  const result = normalizeTaskRecord(record, { strict: true });
  return { ok: result.ok, problems: result.problems, record: result.ok ? result.record : null };
}

/** Map a persisted record onto the declared snake_case column view. */
function toColumnView(record) {
  if (!isPlainObject(record)) {
    return null;
  }
  const view = {};
  for (const column of Object.keys(COLUMN_TO_FIELD)) {
    const field = COLUMN_TO_FIELD[column];
    view[column] = record[field] === undefined ? null : record[field];
  }
  return view;
}

/** Map a snake_case column view back onto a canonical persisted record. */
function fromColumnView(view) {
  if (!isPlainObject(view)) {
    return { ok: false, record: null, problems: ['view must be a plain object'], repaired: [] };
  }
  return normalizeTaskRecord(
    {
      id: view.id,
      ownerId: view.owner_id,
      title: view.title,
      dueDate: view.due_date,
      done: view.done,
      createdAt: view.created_at,
      updatedAt: view.updated_at,
    },
    { strict: true }
  );
}

/** Column names in declaration order. */
function columnNames() {
  return COLUMNS.map((column) => column.name);
}

/** Look up one column declaration by name (a copy, or null). */
function columnDefinition(name) {
  for (const column of COLUMNS) {
    if (column.name === name) {
      return Object.assign({}, column);
    }
  }
  return null;
}

/** JSON-safe description of the whole schema (columns, indexes, owner path). */
function describeSchema() {
  return {
    table: TASKS_TABLE,
    file: TASKS_FILE_NAME,
    version: SCHEMA_VERSION,
    primaryKey: PRIMARY_KEY_COLUMN,
    ownerColumn: OWNER_COLUMN,
    columns: COLUMNS.map((column) => ({
      name: column.name,
      type: column.type,
      nullable: column.nullable,
      primaryKey: column.primaryKey === true,
      defaultValue: column.defaultValue,
    })),
    indexes: INDEXES.map((index) => ({
      name: index.name,
      columns: index.columns.slice(),
      unique: index.unique,
      kind: index.kind,
    })),
    retrievalPath: {
      key: RETRIEVAL_PATH.key,
      index: RETRIEVAL_PATH.index,
      scope: RETRIEVAL_PATH.scope,
      ownerlessQueriesAllowed: RETRIEVAL_PATH.ownerlessQueriesAllowed,
      description: RETRIEVAL_PATH.description,
      operations: RETRIEVAL_PATH.operations.slice(),
    },
    operations: OWNER_SCOPED_OPERATIONS.map((operation) => ({
      name: operation.name,
      scope: operation.scope,
      signature: operation.signature,
      ownerArgument: operation.ownerArgument,
      ownerRequired: operation.ownerRequired === true,
    })),
    forbiddenQueryForms: FORBIDDEN_QUERY_FORMS.slice(),
    columnToField: Object.assign({}, COLUMN_TO_FIELD),
    fieldToColumn: Object.assign({}, FIELD_TO_COLUMN),
  };
}

module.exports = {
  TASKS_TABLE,
  TASKS_FILE_NAME,
  SCHEMA_VERSION,
  PRIMARY_KEY_COLUMN,
  PRIMARY_KEY_INDEX_NAME,
  OWNER_COLUMN,
  OWNER_INDEX_NAME,
  TITLE_MIN_CODEPOINTS,
  TITLE_MAX_CODEPOINTS,
  COLUMNS,
  INDEXES,
  OWNER_SCOPED_OPERATIONS,
  RETRIEVAL_PATH,
  FORBIDDEN_QUERY_FORMS,
  COLUMN_TO_FIELD,
  FIELD_TO_COLUMN,
  countCodePoints,
  isValidDueDateString,
  isIsoTimestamp,
  normalizeTaskRecord,
  validateTaskRecord,
  toColumnView,
  fromColumnView,
  columnNames,
  columnDefinition,
  describeSchema,
};
