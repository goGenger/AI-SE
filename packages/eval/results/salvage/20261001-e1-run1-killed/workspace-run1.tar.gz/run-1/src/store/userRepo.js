'use strict';

/**
 * User Repository.
 *
 * Owns the user record model on top of the JSON Store and the Store Mutex:
 *   - id           UUID string generated with crypto.randomUUID()
 *   - username     the originally submitted string (case preserved)
 *   - usernameLower the lowercase-normalised uniqueness key
 *   - password_algo / password_salt / password_params / password_hash
 *   - createdAt    ISO 8601 string
 *
 * Guarantees
 *   - createUser() performs the duplicate check, the insert and the disk write
 *     inside ONE mutex critical section, so concurrent registrations of the same
 *     username resolve to exactly one success and the rest report USERNAME_TAKEN
 *     with no exception and no 500.
 *   - Duplicates are detected case-insensitively through usernameLower, so an
 *     existing 'Alice' rejects a submitted 'alice'.
 *   - Duplicate or invalid input is reported as a semantic result object
 *     ({ ok: false, code }) rather than a thrown storage error.
 *   - The plaintext password never enters the record, the file or a log line:
 *     only derived credential fields are accepted (optionally via an injected
 *     hasher), and any stray password-like key is dropped before persisting.
 *   - Trust-boundary validation rejects malformed usernames and incomplete
 *     credentials before anything is queued or written.
 *
 * This module lives in the storage layer and therefore does not import the auth
 * layer. Hashing is injected (options.hasher) or supplied as an already-derived
 * credential, keeping the dependency direction one-way.
 */

const crypto = require('node:crypto');

const { ERROR_CODES } = require('../errors/errorEnvelope.js');
const { createJsonStore } = require('./jsonStore.js');
const { createMutex } = require('./mutex.js');

const USERS_FILE_NAME = 'users.json';
const USERNAME_PATTERN = /^[A-Za-z0-9_]{3,32}$/;
const USERNAME_MIN_LENGTH = 3;
const USERNAME_MAX_LENGTH = 32;
const USERNAME_TAKEN = ERROR_CODES.USERNAME_TAKEN;
const VALIDATION_ERROR = ERROR_CODES.VALIDATION_ERROR;
const CREDENTIAL_FIELDS = Object.freeze(['password_algo', 'password_salt', 'password_params', 'password_hash']);
const FORBIDDEN_RECORD_FIELDS = Object.freeze(['password', 'passwordPlain', 'plainPassword', 'plaintext']);
const CREDENTIAL_ALIASES = Object.freeze({
  password_algo: ['password_algo', 'algo'],
  password_salt: ['password_salt', 'salt'],
  password_params: ['password_params', 'params'],
  password_hash: ['password_hash', 'hash', 'digest'],
});

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

/** Lowercase normalisation used as the case-insensitive uniqueness key. */
function normalizeUsername(username) {
  return typeof username === 'string' ? username.toLowerCase() : '';
}

function isValidUsername(value) {
  return typeof value === 'string' && USERNAME_PATTERN.test(value);
}

/** Deep copy through JSON so callers can never mutate repository state. */
function clone(value) {
  if (value === undefined) {
    return undefined;
  }
  return typeof structuredClone === 'function' ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}

/** Public projection of a record: identity only, never hash material. */
function toPublicUser(record) {
  if (!isPlainObject(record)) {
    return null;
  }
  return {
    id: record.id,
    username: record.username,
    createdAt: record.createdAt,
  };
}

/** Read one credential field, accepting both the stored and short names. */
function readCredentialField(source, field) {
  for (const name of CREDENTIAL_ALIASES[field]) {
    const value = source[name];
    if (typeof value === 'string' && value.trim().length > 0) {
      return value.trim();
    }
  }
  return null;
}

/**
 * Extract the four credential fields from a candidate object.
 * Returns null when the shape is incomplete so callers can reject cleanly.
 */
function extractCredential(source) {
  if (!isPlainObject(source)) {
    return null;
  }
  const out = {};
  for (const field of CREDENTIAL_FIELDS) {
    const value = readCredentialField(source, field);
    if (value === null) {
      return null;
    }
    out[field] = value;
  }
  return out;
}

class UserRepository {
  /**
   * @param {object} options
   * @param {string} [options.dataDir]  DATA_DIR used to build a JSON store
   * @param {import('./jsonStore.js').JsonStore} [options.store] existing store
   * @param {string} [options.fileName='users.json']
   * @param {import('./mutex.js').Mutex} [options.mutex] shared mutex
   * @param {{hash?: (password: string) => Promise<object>}} [options.hasher]
   * @param {boolean} [options.autoLoad=true]
   */
  constructor(options) {
    const opts = options && typeof options === 'object' ? options : {};
    if (opts.store && typeof opts.store.runExclusive === 'function') {
      this.store = opts.store;
    } else {
      this.store = createJsonStore({
        dataDir: opts.dataDir,
        fileName: isNonEmptyString(opts.fileName) ? opts.fileName : USERS_FILE_NAME,
        createEmpty: () => [],
      });
    }
    this.mutex =
      opts.mutex && typeof opts.mutex.runExclusive === 'function'
        ? opts.mutex
        : this.store.mutex && typeof this.store.mutex.runExclusive === 'function'
          ? this.store.mutex
          : createMutex({ name: 'users' });
    this.hasher = opts.hasher && typeof opts.hasher.hash === 'function' ? opts.hasher : null;
    this._users = [];
    this._index = new Map();
    if (opts.autoLoad !== false) {
      this.load();
    }
  }

  /** (Re)load the user collection from disk and rebuild the uniqueness index. */
  load() {
    const loaded = this.store.get();
    this._users = Array.isArray(loaded) ? loaded.map((record) => clone(record)) : [];
    this._reindex();
    return this._users.length;
  }

  reload() {
    return this.load();
  }

  _reindex() {
    this._index = new Map();
    for (let position = 0; position < this._users.length; position += 1) {
      const record = this._users[position];
      if (!isPlainObject(record)) {
        continue;
      }
      const key = isNonEmptyString(record.usernameLower)
        ? record.usernameLower
        : normalizeUsername(record.username);
      if (key.length > 0 && !this._index.has(key)) {
        this._index.set(key, position);
      }
    }
    return this._index.size;
  }

  /** Number of stored users. */
  size() {
    return this._users.length;
  }

  /** Case-insensitive lookup returning a deep copy, or null. */
  findByUsername(username) {
    if (typeof username !== 'string' || username.length === 0) {
      return null;
    }
    const position = this._index.get(normalizeUsername(username));
    if (position === undefined) {
      return null;
    }
    return clone(this._users[position]);
  }

  /** Case-insensitive existence check. */
  existsByUsername(username) {
    if (typeof username !== 'string' || username.length === 0) {
      return false;
    }
    return this._index.has(normalizeUsername(username));
  }

  /** Lookup by UUID; returns a deep copy or null. */
  findById(id) {
    if (typeof id !== 'string' || id.length === 0) {
      return null;
    }
    for (const record of this._users) {
      if (isPlainObject(record) && record.id === id) {
        return clone(record);
      }
    }
    return null;
  }

  /**
   * Full record (including credential fields) for the login path.
   * Explicitly named so callers cannot accidentally serialise hash material into
   * a response; the returned object is a copy and the caller must not log it.
   */
  findRecordForAuth(username) {
    return this.findByUsername(username);
  }

  /** All users as public projections (never credential material). */
  listPublicUsers() {
    return this._users.map((record) => toPublicUser(record));
  }

  /** Build a validated record draft; throws nothing, returns null on bad input. */
  _buildRecord(username, credential) {
    if (typeof username !== 'string' || !isValidUsername(username)) {
      return null;
    }
    const passwordFields = extractCredential(credential);
    if (passwordFields === null) {
      return null;
    }
    return Object.assign(
      {
        id: crypto.randomUUID(),
        username,
        usernameLower: normalizeUsername(username),
        createdAt: new Date().toISOString(),
      },
      passwordFields
    );
  }

  /** Strip any plaintext-looking key that must never reach the data file. */
  static _sanitizeRecord(record) {
    const clean = {};
    for (const key of Object.keys(record)) {
      if (FORBIDDEN_RECORD_FIELDS.includes(key)) {
        continue;
      }
      clean[key] = record[key];
    }
    return clean;
  }

  /**
   * Create a user inside one mutex critical section: duplicate check, insert and
   * atomic disk write happen together, so concurrent calls for the same username
   * yield exactly one success.
   *
   * @param {{username?: string, password?: string, credential?: object}} input
   * @returns {Promise<{ok: true, user: object, record: object}|{ok: false, code: string}>}
   */
  createUser(input) {
    const value = isPlainObject(input) ? input : {};
    return this.mutex.runExclusive(async () => {
      const username = value.username;
      if (typeof username !== 'string' || !isValidUsername(username)) {
        return { ok: false, code: VALIDATION_ERROR };
      }
      const key = normalizeUsername(username);
      if (this._index.has(key)) {
        return { ok: false, code: USERNAME_TAKEN };
      }
      let credential = isPlainObject(value.credential) ? value.credential : value;
      if (extractCredential(credential) === null && this.hasher !== null) {
        if (typeof value.password !== 'string' || value.password.length === 0) {
          return { ok: false, code: VALIDATION_ERROR };
        }
        credential = await this.hasher.hash(value.password);
      }
      const draft = this._buildRecord(username, credential);
      if (draft === null) {
        return { ok: false, code: VALIDATION_ERROR };
      }
      const record = UserRepository._sanitizeRecord(draft);
      const next = this._users.slice();
      next.push(record);
      this._users = next;
      this.store.set(next);
      this.store.saveSync();
      this._reindex();
      return { ok: true, user: toPublicUser(record), record: clone(record) };
    });
  }

  /** Convenience wrapper: create or return the USERNAME_TAKEN result. */
  async createUserOrConflict(input) {
    return this.createUser(input);
  }

  /** True when the mutex queue is empty (all writes have settled). */
  isIdle() {
    return this.mutex.isIdle ? this.mutex.isIdle() : this.mutex.waiting === 0;
  }

  /** Resolves once every queued write has settled. */
  waitForIdle() {
    return typeof this.mutex.idle === 'function' ? this.mutex.idle() : Promise.resolve();
  }

  /** Secret-free metadata: counts and file info only. */
  stats() {
    return {
      file: this.store.fileName,
      users: this._users.length,
      uniqueKeys: this._index.size,
      store: typeof this.store.stats === 'function' ? this.store.stats() : null,
    };
  }

  /** JSON.stringify(repository) must never expose record contents. */
  toJSON() {
    return this.stats();
  }
}

/** Factory: build a user repository over DATA_DIR (or an injected store). */
function createUserRepository(options) {
  return new UserRepository(options);
}

module.exports = {
  USERS_FILE_NAME,
  USERNAME_PATTERN,
  USERNAME_MIN_LENGTH,
  USERNAME_MAX_LENGTH,
  USERNAME_TAKEN,
  VALIDATION_ERROR,
  CREDENTIAL_FIELDS,
  FORBIDDEN_RECORD_FIELDS,
  UserRepository,
  createUserRepository,
  normalizeUsername,
  isValidUsername,
  extractCredential,
  toPublicUser,
};
