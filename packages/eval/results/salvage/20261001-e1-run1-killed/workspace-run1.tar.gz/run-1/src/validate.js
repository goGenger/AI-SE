'use strict';

/**
 * Request input validator (trust-boundary layer).
 *
 * Single place where request bodies are parsed and shape-checked before any
 * handler touches them:
 *   - malformed / non-object JSON      -> 400 VALIDATION_ERROR
 *   - a field outside the endpoint set -> 400 UNKNOWN_FIELD (never ignored)
 *   - bad username / password          -> 400 VALIDATION_ERROR
 *   - bad task title                   -> 400 TITLE_INVALID
 *   - bad dueDate                      -> 400 DATE_INVALID
 *
 * Failures are thrown as AppErrors so the central error handler turns them into
 * the shared { "error": { "code", "message" } } envelope. Nothing here echoes a
 * rejected value, so raw request input never leaks back into a response.
 *
 * The task validators enforce the strict, per-endpoint field whitelists required
 * by FR-3 / FR-5 (TR-06): POST /api/tasks accepts only title and dueDate;
 * PATCH /api/tasks/:id accepts only title, dueDate and done. Any other key is
 * rejected with UNKNOWN_FIELD instead of being silently dropped, and the check
 * always runs before a handler can touch the store.
 */

const { AppError, ERROR_CODES } = require('./errors/errorEnvelope.js');
const { readBody, MAX_BODY_BYTES } = require('./http/request.js');

/** Username rule from FR-1: exactly 3-32 letters, digits or underscore. */
const USERNAME_PATTERN = /^[A-Za-z0-9_]{3,32}$/;
const USERNAME_REGEX = USERNAME_PATTERN;
const USERNAME_MIN_LENGTH = 3;
const USERNAME_MAX_LENGTH = 32;

/** Password rule from FR-1: 8-72 characters inclusive. */
const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_MAX_LENGTH = 72;

/** Title rule from FR-3/FR-5: 1-100 Unicode code points after trimming. */
const TITLE_MIN_CODEPOINTS = 1;
const TITLE_MAX_CODEPOINTS = 100;

/** dueDate rule from FR-3/FR-5: a real calendar date in YYYY-MM-DD form. */
const DUE_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
const MIN_DUE_DATE_YEAR = 1;
const MAX_DUE_DATE_YEAR = 9999;

/** Exact field whitelists per endpoint (strict: any extra field is rejected). */
const ALLOWED_REGISTER_FIELDS = Object.freeze(['username', 'password']);
const ALLOWED_LOGIN_FIELDS = Object.freeze(['username', 'password']);
const ALLOWED_CREDENTIAL_FIELDS = ALLOWED_REGISTER_FIELDS;
const ALLOWED_CREATE_TASK_FIELDS = Object.freeze(['title', 'dueDate']);
const ALLOWED_UPDATE_TASK_FIELDS = Object.freeze(['title', 'dueDate', 'done']);

const hasOwn = Object.prototype.hasOwnProperty;

/** Lowercase normalisation used as the case-insensitive uniqueness key (AC-05). */
function normalizeUsername(username) {
  return typeof username === 'string' ? username.toLowerCase() : '';
}

function isValidUsername(value) {
  return typeof value === 'string' && USERNAME_PATTERN.test(value);
}

function isValidPassword(value) {
  return (
    typeof value === 'string' &&
    value.length >= PASSWORD_MIN_LENGTH &&
    value.length <= PASSWORD_MAX_LENGTH
  );
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !Buffer.isBuffer(value);
}

/** Read one own field, ignoring anything inherited from the prototype chain. */
function readOwnField(body, name) {
  return hasOwn.call(body, name) ? body[name] : undefined;
}

/** True when the body carries this own field (prototype-inherited keys never count). */
function hasOwnField(body, name) {
  return hasOwn.call(body, name);
}

/**
 * Parse a raw JSON body string.
 * Empty/whitespace-only input yields {} so missing-field validation reports the
 * real problem; malformed JSON or a non-object payload is a VALIDATION_ERROR
 * (never an uncaught exception or a 500).
 */
function parseJsonText(text) {
  const raw = typeof text === 'string' ? text.trim() : '';
  if (raw.length === 0) {
    return {};
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body must be valid JSON');
  }
  if (!isPlainObject(parsed)) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body must be a JSON object');
  }
  return parsed;
}

/**
 * Read and parse a JSON request body from an http IncomingMessage.
 * Bodies over the limit or an unreadable stream surface as VALIDATION_ERROR.
 */
async function parseJsonBody(req, limit) {
  const raw = await readBody(req, limit);
  return parseJsonText(raw);
}

function assertJsonObject(body) {
  if (!isPlainObject(body)) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body must be a JSON object');
  }
  return body;
}

/**
 * Strict whitelist: any own field outside `allowedFields` is rejected with
 * UNKNOWN_FIELD instead of being silently dropped.
 */
function assertAllowedFields(body, allowedFields) {
  assertJsonObject(body);
  const allowed = new Set(
    Array.isArray(allowedFields) ? allowedFields : allowedFields instanceof Set ? allowedFields : []
  );
  for (const key of Object.keys(body)) {
    if (!allowed.has(key)) {
      throw new AppError(ERROR_CODES.UNKNOWN_FIELD);
    }
  }
  return body;
}

function assertUsername(value) {
  if (!isValidUsername(value)) {
    throw new AppError(
      ERROR_CODES.VALIDATION_ERROR,
      'Username must be 3-32 characters using letters, digits or underscore'
    );
  }
  return value;
}

function assertPassword(value) {
  if (!isValidPassword(value)) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Password must be between 8 and 72 characters');
  }
  return value;
}

/**
 * Validate a register/login body: strict fields, username rule, password rule.
 * Returns the original-case username plus its normalised uniqueness key.
 */
function validateCredentialsBody(body) {
  const value = assertJsonObject(body);
  assertAllowedFields(value, ALLOWED_CREDENTIAL_FIELDS);
  const username = assertUsername(readOwnField(value, 'username'));
  const password = assertPassword(readOwnField(value, 'password'));
  return { username, password, usernameLower: normalizeUsername(username) };
}

const validateRegisterInput = validateCredentialsBody;
const validateLoginInput = validateCredentialsBody;

/**
 * Count Unicode code points (astral characters count as one) using the string
 * iterator, never String#length which would count UTF-16 units (TR-04).
 */
function countCodePoints(value) {
  if (typeof value !== 'string') {
    return 0;
  }
  let count = 0;
  for (const point of value) {
    void point;
    count += 1;
  }
  return count;
}

/** True when two integers form a real calendar day (rejects 2026-02-30, ...). */
function isRealCalendarDay(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return false;
  }
  const probe = new Date(Date.UTC(2000, month - 1, day));
  probe.setUTCFullYear(year);
  return (
    probe.getUTCFullYear() === year && probe.getUTCMonth() === month - 1 && probe.getUTCDate() === day
  );
}

/** True for a syntactically valid YYYY-MM-DD string that is a real calendar date. */
function isValidDueDateString(value) {
  if (typeof value !== 'string') {
    return false;
  }
  const match = DUE_DATE_PATTERN.exec(value);
  if (match === null) {
    return false;
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (!Number.isInteger(year) || year < MIN_DUE_DATE_YEAR || year > MAX_DUE_DATE_YEAR) {
    return false;
  }
  return isRealCalendarDay(year, month, day);
}

/** Trim a title and enforce the 1-100 code-point rule, else TITLE_INVALID. */
function assertTitle(value) {
  if (typeof value !== 'string') {
    throw new AppError(ERROR_CODES.TITLE_INVALID);
  }
  const trimmed = value.trim();
  const length = countCodePoints(trimmed);
  if (length < TITLE_MIN_CODEPOINTS || length > TITLE_MAX_CODEPOINTS) {
    throw new AppError(ERROR_CODES.TITLE_INVALID);
  }
  return trimmed;
}

/** Enforce the dueDate rule (real YYYY-MM-DD) for a provided value, else DATE_INVALID. */
function assertDueDate(value) {
  if (!isValidDueDateString(value)) {
    throw new AppError(ERROR_CODES.DATE_INVALID);
  }
  return value;
}

/**
 * Validate a create-task body (POST /api/tasks): strict whitelist {title, dueDate}.
 * Returns the trimmed title plus the dueDate echo (the submitted string when it
 * was provided, otherwise null). Any other field is UNKNOWN_FIELD; nothing here
 * writes to the store.
 */
function validateCreateTaskInput(body) {
  const value = assertJsonObject(body);
  assertAllowedFields(value, ALLOWED_CREATE_TASK_FIELDS);
  const title = assertTitle(readOwnField(value, 'title'));
  let dueDate = null;
  if (hasOwnField(value, 'dueDate') && readOwnField(value, 'dueDate') !== null) {
    dueDate = assertDueDate(readOwnField(value, 'dueDate'));
  }
  return { title, dueDate };
}

/**
 * Validate an update-task body (PATCH /api/tasks/:id): strict whitelist
 * {title, dueDate, done}. Only the provided keys are validated and returned, so
 * a partial update never clobbers an untouched field. done must be a boolean.
 */
function validateUpdateTaskInput(body) {
  const value = assertJsonObject(body);
  assertAllowedFields(value, ALLOWED_UPDATE_TASK_FIELDS);
  const patch = {};
  if (hasOwnField(value, 'title')) {
    patch.title = assertTitle(readOwnField(value, 'title'));
  }
  if (hasOwnField(value, 'dueDate')) {
    const dueDate = readOwnField(value, 'dueDate');
    patch.dueDate = dueDate === null ? null : assertDueDate(dueDate);
  }
  if (hasOwnField(value, 'done')) {
    const done = readOwnField(value, 'done');
    if (typeof done !== 'boolean') {
      throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Field done must be a boolean');
    }
    patch.done = done;
  }
  return patch;
}

const validateCreateTaskBody = validateCreateTaskInput;
const validateUpdateTaskBody = validateUpdateTaskInput;

module.exports = {
  USERNAME_PATTERN,
  USERNAME_REGEX,
  USERNAME_MIN_LENGTH,
  USERNAME_MAX_LENGTH,
  PASSWORD_MIN_LENGTH,
  PASSWORD_MAX_LENGTH,
  TITLE_MIN_CODEPOINTS,
  TITLE_MAX_CODEPOINTS,
  DUE_DATE_PATTERN,
  ALLOWED_REGISTER_FIELDS,
  ALLOWED_LOGIN_FIELDS,
  ALLOWED_CREDENTIAL_FIELDS,
  ALLOWED_CREATE_TASK_FIELDS,
  ALLOWED_UPDATE_TASK_FIELDS,
  MAX_BODY_BYTES,
  normalizeUsername,
  isValidUsername,
  isValidPassword,
  isPlainObject,
  hasOwnField,
  parseJsonText,
  parseJsonBody,
  assertJsonObject,
  assertAllowedFields,
  assertUsername,
  assertPassword,
  countCodePoints,
  isRealCalendarDay,
  isValidDueDateString,
  assertTitle,
  assertDueDate,
  validateCredentialsBody,
  validateRegisterInput,
  validateLoginInput,
  validateCreateTaskInput,
  validateUpdateTaskInput,
  validateCreateTaskBody,
  validateUpdateTaskBody,
};
