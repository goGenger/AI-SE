'use strict';

/**
 * AC-01: health endpoints and the error-envelope baseline.
 *
 * Every test here starts a real HTTP server on an ephemeral port with an
 * isolated temporary DATA_DIR, so the suite is repeatable and independent of
 * any other test's ordering or leftover state.
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const { loadConfig } = require('../src/config.js');
const { makeDataDir, startTestServer, getJson } = require('./helpers.js');

const HEALTH_PATHS = ['/healthz', '/health', '/ready'];
const UNKNOWN_PATH = '/definitely/unknown/ac01/envelope';

test('AC-01: /healthz, /health and /ready all return 200 with {status:"ok"}', async () => {
  const dataDir = makeDataDir('ac01-health');
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir, TOKEN_SECRET: 'ac01-signing-key' });
  const ctx = await startTestServer({ dataDir, config });
  try {
    for (const path of HEALTH_PATHS) {
      const response = await getJson(ctx.url + path);
      assert.equal(response.status, 200, path + ' must return 200');
      assert.deepEqual(response.body, { status: 'ok' }, path + ' body must be {status:"ok"}');
      assert.match(String(response.headers.get('content-type')), /application\/json/);
    }
  } finally {
    await ctx.close();
  }
});

test('AC-01: unknown path returns 404 NOT_FOUND in the {"error":{"code","message"}} envelope', async () => {
  const dataDir = makeDataDir('ac01-envelope');
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir, TOKEN_SECRET: 'ac01-signing-key' });
  const ctx = await startTestServer({ dataDir, config });
  try {
    const response = await getJson(ctx.url + UNKNOWN_PATH);
    assert.equal(response.status, 404, 'unknown path must return 404');
    assert.match(String(response.headers.get('content-type')), /application\/json/);
    assert.deepEqual(Object.keys(response.body), ['error'], 'top level must contain only "error"');
    assert.deepEqual(Object.keys(response.body.error).sort(), ['code', 'message']);
    assert.equal(response.body.error.code, 'NOT_FOUND');
    assert.equal(typeof response.body.error.message, 'string');
    assert.equal(response.body.error.message.length > 0, true, 'message must be non-empty');
  } finally {
    await ctx.close();
  }
});
