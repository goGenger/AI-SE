'use strict';

/**
 * AC-04: plaintext-password scan of DATA_DIR + restart persistence (FR-7).
 *
 * Two guarantees are asserted:
 *   1) after registering a user with a distinctive sentinel password, EVERY file
 *      under DATA_DIR is scanned recursively and must NOT contain the plaintext
 *      password string nor any obvious plaintext-password field; the stored user
 *      record must instead carry salted-hash fields (password_algo / password_salt
 *      / password_params / password_hash);
 *   2) restarting the service on the SAME DATA_DIR (close the server, then build
 *      a brand-new server + app + repository + secret store from disk) still logs
 *      the same user in with the original credentials, returning 200 with the SAME
 *      user.id, and the restart-issued token verifies against the persisted
 *      signing key.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { loadConfig } = require('../src/config.js');
const { startServer } = require('../src/server.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { createSecretStore, SECRET_FILE_NAME } = require('../src/auth/secretStore.js');
const { verifyToken } = require('../src/auth/token.js');

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const USERS_FILE_NAME = 'users.json';
const SENTINEL_FRAGMENT = 'AC04sentinel';
const SENTINEL_PASSWORD = SENTINEL_FRAGMENT + '_Pa55w0rd!';
const USERNAME = 'AC04_ScanUser';
const REGISTER_PATH = '/api/register';
const LOGIN_PATH = '/api/login';

const SILENT_LOGGER = Object.freeze({ info() {}, warn() {}, debug() {}, error() {}, fatal() {} });

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-ac04-' + (name || 'x') + '-'));
}

/** Recursively list every regular file under a directory (absolute paths). */
function listFilesRecursive(root) {
  const found = [];
  const visit = (current) => {
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        visit(full);
      } else if (entry.isFile()) {
        found.push(full);
      }
    }
  };
  visit(root);
  return found;
}

/** Read every file under DATA_DIR as text, keyed by its path relative to DATA_DIR. */
function readAllDataFiles(dataDir) {
  const contents = new Map();
  for (const file of listFilesRecursive(dataDir)) {
    contents.set(path.relative(dataDir, file), fs.readFileSync(file, 'utf8'));
  }
  return contents;
}

async function postJson(baseUrl, routePath, body) {
  const response = await fetch(baseUrl + routePath, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await response.text();
  let parsed = null;
  try {
    parsed = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    parsed = text;
  }
  return { status: response.status, body: parsed, text };
}

function closeServer(server) {
  return new Promise((resolve) => {
    server.close(() => resolve());
    server.closeAllConnections();
  });
}

/**
 * Build one full service instance over an existing DATA_DIR through the real
 * server bootstrap. Every call is a fresh process-equivalent: new config, new
 * user repository, new secret store and a new app that reads only what is on disk.
 */
async function startInstance(dataDir) {
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir });
  const services = {
    userRepository: createUserRepository({ dataDir }),
    secretStore: createSecretStore({ dataDir, env: {} }),
  };
  return startServer({ config, logger: SILENT_LOGGER, host: '127.0.0.1', appOptions: { services } });
}

test('AC-04: DATA_DIR holds no plaintext password and a restart keeps the same user.id', async () => {
  const dataDir = makeDataDir('scan');
  let registeredUserId;

  // A benign nested file proves the scan really is recursive over DATA_DIR.
  fs.mkdirSync(path.join(dataDir, 'nested'), { recursive: true });
  fs.writeFileSync(path.join(dataDir, 'nested', 'decoy.json'), JSON.stringify({ note: 'benign' }), 'utf8');

  let first;
  try {
    first = await startInstance(dataDir);

    // --- register a user with the sentinel password ---
    const registration = await postJson(first.url, REGISTER_PATH, {
      username: USERNAME,
      password: SENTINEL_PASSWORD,
    });
    assert.equal(registration.status, 201);
    assert.equal(registration.body.user.username, USERNAME);
    assert.match(registration.body.user.id, UUID_PATTERN);
    registeredUserId = registration.body.user.id;

    // --- recursively scan every DATA_DIR file ---
    const contents = readAllDataFiles(dataDir);
    assert.equal(contents.has(path.join('nested', 'decoy.json')), true, 'the scan must recurse into subdirectories');
    assert.equal(contents.size >= 3, true, 'DATA_DIR must contain the user file, the key file and the decoy');

    for (const [relativePath, text] of contents) {
      assert.equal(
        text.includes(SENTINEL_PASSWORD),
        false,
        'plaintext password must not appear in ' + relativePath
      );
      assert.equal(
        text.includes(SENTINEL_FRAGMENT),
        false,
        'sentinel password fragment must not appear in ' + relativePath
      );
      assert.equal(/"password"\s*:/.test(text), false, 'no plaintext password field in ' + relativePath);
      assert.equal(
        /"passwordPlain"\s*:|"plainPassword"\s*:|"plaintext"\s*:|"password_plain"\s*:/.test(text),
        false,
        'no plaintext-password alias field in ' + relativePath
      );
    }

    // --- the stored record uses salted-hash fields instead ---
    const usersText = contents.get(USERS_FILE_NAME);
    assert.equal(typeof usersText, 'string', USERS_FILE_NAME + ' must exist under DATA_DIR');
    const records = JSON.parse(usersText);
    assert.equal(Array.isArray(records), true);
    assert.equal(records.length, 1);
    const record = records[0];
    assert.equal(record.id, registeredUserId);
    assert.equal(record.username, USERNAME);
    assert.equal(typeof record.password_algo, 'string');
    assert.equal(typeof record.password_salt, 'string');
    assert.equal(typeof record.password_params, 'string');
    assert.equal(typeof record.password_hash, 'string');
    assert.equal(record.password_hash.length >= 32, true);
    assert.equal(record.password_salt.length > 0, true);
    assert.equal('password' in record, false);
    assert.equal('password_plain' in record, false);
  } finally {
    if (first) {
      await closeServer(first.server);
    }
  }

  // --- restart: brand-new server + app + repository + secret store over the SAME DATA_DIR ---
  const second = await startInstance(dataDir);
  try {
    const login = await postJson(second.url, LOGIN_PATH, {
      username: USERNAME,
      password: SENTINEL_PASSWORD,
    });
    assert.equal(login.status, 200);
    assert.equal(typeof login.body.token, 'string');
    assert.equal(login.body.token.length > 0, true);
    assert.equal(login.body.user.id, registeredUserId);
    assert.equal(login.body.user.username, USERNAME);

    // The signing key persisted under DATA_DIR, so a freshly loaded secret store
    // still verifies the restart-issued token (the HMAC key survived the restart).
    assert.equal(fs.existsSync(path.join(dataDir, SECRET_FILE_NAME)), true);
    const reloadedSecrets = createSecretStore({ dataDir, env: {} });
    const verified = verifyToken(login.body.token, { secretStore: reloadedSecrets });
    assert.equal(verified.ok, true);
    assert.equal(verified.subject, registeredUserId);

    // Persistence is not an auth bypass: a wrong password still fails after restart.
    const rejected = await postJson(second.url, LOGIN_PATH, {
      username: USERNAME,
      password: SENTINEL_PASSWORD + '_wrong',
    });
    assert.equal(rejected.status, 401);
    assert.equal(rejected.body.error.code, 'INVALID_CREDENTIALS');
  } finally {
    await closeServer(second.server);
  }
});
