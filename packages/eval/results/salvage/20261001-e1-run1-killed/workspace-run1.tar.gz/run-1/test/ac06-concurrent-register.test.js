'use strict';

/**
 * AC-06 concurrent registration consistency (FR-1, TR-11).
 *
 * Drives the real HTTP surface: >=5 parallel POST /api/register requests for the
 * SAME username are fired through Promise.all. Exactly one must answer 201, every
 * other answer must be 409 USERNAME_TAKEN, no response may be a 5xx, and the
 * DATA_DIR user file must end up holding exactly one record for that username and
 * remain parseable as JSON.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { registerRoutes, REGISTER_PATH } = require('../src/http/registerHandler.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { hashPassword } = require('../src/auth/password.js');

const CONCURRENCY = 8;
const USERNAME = 'RaceUser_Ac06';
const PASSWORD = 'S3cret_passw0rd!';
const FAST_SCRYPT = Object.freeze({ N: 1024, r: 8, p: 1, keylen: 32 });
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-ac06-' + (name || 'race') + '-'));
}

function startApp(dataDir) {
  const userRepository = createUserRepository({ dataDir });
  const app = createApp({ services: { userRepository } });
  registerRoutes(app, { hasher: { hash: (plain) => hashPassword(plain, { params: FAST_SCRYPT }) } });
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        server,
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function register(ctx, username) {
  const response = await fetch(ctx.url + REGISTER_PATH, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password: PASSWORD }),
  });
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, body, text };
}

function readUserRecords(dataDir) {
  const filePath = path.join(dataDir, 'users.json');
  assert.equal(fs.existsSync(filePath), true, 'the DATA_DIR user file must exist after registration');
  const raw = fs.readFileSync(filePath, 'utf8');
  const parsed = JSON.parse(raw);
  assert.equal(Array.isArray(parsed), true, 'the DATA_DIR user file must contain a JSON array');
  return { filePath, raw, records: parsed };
}

test('AC-06 register: 8 concurrent requests for one username yield exactly one 201, the rest 409 USERNAME_TAKEN, and one record in DATA_DIR', async () => {
  const dataDir = makeDataDir('concurrent');
  const ctx = await startApp(dataDir);
  try {
    assert.equal(CONCURRENCY >= 5, true, 'at least 5 concurrent registrations are required');
    const attempts = Array.from({ length: CONCURRENCY }, () => register(ctx, USERNAME));
    const responses = await Promise.all(attempts);

    const created = responses.filter((entry) => entry.status === 201);
    const conflicts = responses.filter((entry) => entry.status === 409);
    const serverErrors = responses.filter((entry) => entry.status >= 500);

    assert.equal(serverErrors.length, 0, 'no concurrent registration may answer with a 5xx status');
    assert.equal(created.length, 1, 'exactly one concurrent registration must succeed with 201');
    assert.equal(conflicts.length, responses.length - 1, 'every other response must be 409');

    for (const entry of conflicts) {
      assert.equal(typeof entry.body, 'object');
      assert.equal(entry.body.error.code, 'USERNAME_TAKEN');
      assert.equal(typeof entry.body.error.message, 'string');
    }

    const winner = created[0];
    assert.match(winner.body.user.id, UUID_V4);
    assert.equal(winner.body.user.username, USERNAME);

    const { raw, records } = readUserRecords(dataDir);
    const matches = records.filter((record) => String(record.username).toLowerCase() === USERNAME.toLowerCase());
    assert.equal(matches.length, 1, 'the username must be persisted exactly once');
    assert.equal(records.length, 1, 'no other user record may be written');
    assert.equal(matches[0].id, winner.body.user.id);
    assert.equal(matches[0].usernameLower, USERNAME.toLowerCase());
    assert.equal(JSON.parse(raw).length, 1);
  } finally {
    await ctx.close();
  }
});

test('AC-06 register: after the concurrent race a sequential retry is still 409 and the DATA_DIR file stays valid JSON', async () => {
  const dataDir = makeDataDir('settled');
  const ctx = await startApp(dataDir);
  try {
    const responses = await Promise.all(Array.from({ length: 6 }, () => register(ctx, USERNAME)));
    assert.equal(responses.filter((entry) => entry.status === 201).length, 1);
    assert.equal(responses.filter((entry) => entry.status === 409).length, 5);
    assert.equal(responses.filter((entry) => entry.status >= 500).length, 0);

    const retry = await register(ctx, USERNAME);
    assert.equal(retry.status, 409);
    assert.equal(retry.body.error.code, 'USERNAME_TAKEN');

    const { records } = readUserRecords(dataDir);
    assert.equal(records.length, 1);
    assert.equal(records.filter((record) => record.usernameLower === USERNAME.toLowerCase()).length, 1);
  } finally {
    await ctx.close();
  }
});
