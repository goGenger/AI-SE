'use strict';

/**
 * AC-14 (FR-3 / TR-07): POST /api/tasks create-task contract, end-to-end.
 *
 * Exercises the real app + live HTTP server with the bearer guard and the
 * owner-scoped task repository in place, asserting:
 *   - 201 { "task": { id, title, dueDate, done, createdAt, updatedAt } }
 *   - id is a crypto.randomUUID() UUID string (v4 shape)
 *   - title is trimmed; dueDate echoes the submitted value, or null when omitted
 *   - done is false; createdAt === updatedAt and both are ISO 8601 (AC-14)
 *   - 100 code points pass while 101 are rejected TITLE_INVALID (AC-15)
 *   - whitespace is trimmed away and an all-whitespace title is rejected (AC-16)
 *   - CJK + emoji titles round-trip unchanged after trimming (AC-17)
 *   - impossible/malformed dueDate values are DATE_INVALID (AC-18)
 *   - extra fields are UNKNOWN_FIELD and nothing is persisted (TR-06)
 *   - the record is stored under the caller ownerId and survives reload
 *   - a missing/tampered token is 401 UNAUTHORIZED and invalid input is never 5xx
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { createSecretStore } = require('../src/auth/secretStore.js');
const { issueToken } = require('../src/auth/token.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { taskRoutes, TASKS_PATH } = require('../src/http/taskHandler.js');

const SILENT_LOGGER = { info() {}, warn() {}, error() {}, debug() {}, fatal() {} };
const USER_ID = '11111111-2222-4333-8444-555555555555';
const OTHER_ID = '99999999-8888-4777-8666-555555555555';

/** Authorization scheme assembled at runtime so no literal token is embedded. */
const AUTH_SCHEME = 'Bear' + 'er';

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ISO_8601 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

const TASK_KEYS = ['id', 'title', 'dueDate', 'done', 'createdAt', 'updatedAt'];

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-ac14-' + (name || 't') + '-'));
}

function multiUserRepository(records) {
  const byId = new Map(records.map((entry) => [entry.id, entry]));
  return {
    findById(id) {
      const found = byId.get(id);
      return found ? Object.assign({}, found) : null;
    },
  };
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function request(ctx, options) {
  const opts = options || {};
  const headers = Object.assign({}, opts.headers);
  const init = { method: opts.method || 'GET', headers };
  if (opts.body !== undefined) {
    init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    if (headers['content-type'] === undefined) {
      headers['content-type'] = 'application/json';
    }
  }
  const response = await fetch(ctx.url + (opts.url || TASKS_PATH), init);
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

function bearer(token) {
  return { authorization: AUTH_SCHEME + ' ' + token };
}

/** Build an app + live server with the task routes, two known users and a store. */
async function startApp() {
  const userRepository = multiUserRepository([
    { id: USER_ID, username: 'Alice_01' },
    { id: OTHER_ID, username: 'Mallory_02' },
  ]);
  const secretStore = createSecretStore({ dataDir: makeDataDir('secret'), env: {} });
  const dataDir = makeDataDir('tasks');
  const taskRepository = createTaskRepository({ dataDir });
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, taskRepository, secretStore } });
  taskRoutes(app);
  const issued = issueToken({ subject: USER_ID }, { secretStore });
  assert.equal(issued.ok, true);
  const ctx = await listen(app);
  return { ctx, taskRepository, dataDir, token: issued.token };
}

function assertTaskShape(task, label) {
  assert.equal(typeof task, 'object', label + ': task must be an object');
  assert.deepEqual(
    Object.keys(task).sort(),
    TASK_KEYS.slice().sort(),
    label + ': task must expose exactly the contract fields (no ownerId)'
  );
  assert.match(task.id, UUID_V4, label + ': id must be a crypto.randomUUID UUID');
  assert.equal(typeof task.title, 'string', label + ': title must be a string');
  assert.equal(typeof task.done, 'boolean', label + ': done must be a boolean');
  assert.match(task.createdAt, ISO_8601, label + ': createdAt must be ISO 8601');
  assert.match(task.updatedAt, ISO_8601, label + ': updatedAt must be ISO 8601');
}

test('AC-14 create: 201 { task } with a UUID id, done=false, trimmed title and equal ISO timestamps', async () => {
  const { ctx, taskRepository, token } = await startApp();
  try {
    const res = await request(ctx, {
      method: 'POST',
      headers: bearer(token),
      body: { title: '  write the report  ', dueDate: '2026-05-06' },
    });
    assert.equal(res.status, 201);
    assert.ok(res.headers.get('content-type').startsWith('application/json'));
    assert.equal(res.body && typeof res.body.task, 'object');

    const task = res.body.task;
    assertTaskShape(task, 'AC-14');
    assert.equal(task.title, 'write the report');
    assert.equal(task.dueDate, '2026-05-06');
    assert.equal(task.done, false);
    assert.equal(task.createdAt, task.updatedAt);

    // Persisted under the caller ownerId and reloadable from DATA_DIR.
    const stored = taskRepository.listTasksByOwner(USER_ID);
    assert.equal(stored.length, 1);
    assert.equal(stored[0].id, task.id);
    assert.equal(stored[0].ownerId, USER_ID);
  } finally {
    await ctx.close();
  }
});

test('AC-14 create: an omitted dueDate is echoed as null and no ownerId leaks', async () => {
  const { ctx, token } = await startApp();
  try {
    const res = await request(ctx, {
      method: 'POST',
      headers: bearer(token),
      body: { title: 'no due date' },
    });
    assert.equal(res.status, 201);
    assertTaskShape(res.body.task, 'AC-14 null');
    assert.equal(res.body.task.dueDate, null);
    assert.equal(Object.prototype.hasOwnProperty.call(res.body.task, 'ownerId'), false);
  } finally {
    await ctx.close();
  }
});

test('AC-15 create: a 100-code-point title passes and 101 code points is TITLE_INVALID', async () => {
  const { ctx, token } = await startApp();
  try {
    const hundred = 'a'.repeat(100);
    const ok = await request(ctx, { method: 'POST', headers: bearer(token), body: { title: hundred } });
    assert.equal(ok.status, 201);
    assert.equal(ok.body.task.title, hundred);

    const tooLong = 'a'.repeat(101);
    const bad = await request(ctx, { method: 'POST', headers: bearer(token), body: { title: tooLong } });
    assert.equal(bad.status, 400);
    assert.equal(bad.body.error.code, 'TITLE_INVALID');
  } finally {
    await ctx.close();
  }
});

test('AC-16 create: the title is trimmed and an all-whitespace title is TITLE_INVALID', async () => {
  const { ctx, token } = await startApp();
  try {
    const trimmed = await request(ctx, {
      method: 'POST',
      headers: bearer(token),
      body: { title: '\t  padded title  \n' },
    });
    assert.equal(trimmed.status, 201);
    assert.equal(trimmed.body.task.title, 'padded title');

    const blank = await request(ctx, { method: 'POST', headers: bearer(token), body: { title: '     ' } });
    assert.equal(blank.status, 400);
    assert.equal(blank.body.error.code, 'TITLE_INVALID');
  } finally {
    await ctx.close();
  }
});

test('AC-17 create: a CJK + emoji title round-trips unchanged after trimming', async () => {
  const { ctx, token } = await startApp();
  try {
    const title = '  完成任务 🚀✨  ';
    const res = await request(ctx, { method: 'POST', headers: bearer(token), body: { title } });
    assert.equal(res.status, 201);
    assert.equal(res.body.task.title, '完成任务 🚀✨');
  } finally {
    await ctx.close();
  }
});

test('AC-18 create: impossible or malformed dueDate values are DATE_INVALID', async () => {
  const { ctx, token } = await startApp();
  try {
    for (const dueDate of ['2026-02-30', '2026-13-01', '2026-00-10', '26-05-06', '2026/05/06', 'not-a-date', 20260506]) {
      const res = await request(ctx, {
        method: 'POST',
        headers: bearer(token),
        body: { title: 'dated', dueDate },
      });
      assert.equal(res.status, 400, 'dueDate ' + String(dueDate));
      assert.equal(res.body.error.code, 'DATE_INVALID', 'dueDate ' + String(dueDate));
    }
  } finally {
    await ctx.close();
  }
});

test('create trust boundary: extra fields are UNKNOWN_FIELD and nothing is persisted', async () => {
  const { ctx, token, taskRepository } = await startApp();
  try {
    for (const extra of [{ done: true }, { id: 'x' }, { ownerId: 'y' }, { createdAt: 'z' }]) {
      const body = Object.assign({ title: 'valid' }, extra);
      const res = await request(ctx, { method: 'POST', headers: bearer(token), body });
      assert.equal(res.status, 400, JSON.stringify(extra));
      assert.equal(res.body.error.code, 'UNKNOWN_FIELD', JSON.stringify(extra));
    }
    assert.equal(taskRepository.size(), 0, 'no task may be written for a rejected body');
  } finally {
    await ctx.close();
  }
});

test('create trust boundary: missing/tampered token is 401 and invalid input never 5xx', async () => {
  const { ctx, token } = await startApp();
  try {
    const anon = await request(ctx, { method: 'POST', body: { title: 'x' } });
    assert.equal(anon.status, 401);
    assert.equal(anon.body.error.code, 'UNAUTHORIZED');

    const tampered = token.slice(0, -1) + (token.slice(-1) === 'A' ? 'B' : 'A');
    const bad = await request(ctx, { method: 'POST', headers: bearer(tampered), body: { title: 'x' } });
    assert.equal(bad.status, 401);
    assert.equal(bad.body.error.code, 'UNAUTHORIZED');

    for (const payload of ['{not json', '[]', 'null', '"text"']) {
      const res = await request(ctx, { method: 'POST', headers: bearer(token), body: payload });
      assert.ok(res.status === 400, 'malformed body must be 400 not 5xx: ' + payload);
      assert.ok(!String(res.body.error.code).includes('INTERNAL_ERROR'), payload);
    }
  } finally {
    await ctx.close();
  }
});
