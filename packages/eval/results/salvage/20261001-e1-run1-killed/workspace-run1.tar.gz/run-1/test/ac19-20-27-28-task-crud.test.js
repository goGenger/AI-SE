'use strict';

/**
 * AC-19 / AC-20 / AC-27 / AC-28: single-task GET/PATCH/DELETE + cross-user
 * isolation, exercised end-to-end through the real app, the bearer guard and the
 * owner-scoped JSON repository.
 *
 *   - AC-19: PATCH with an unknown field is 400 UNKNOWN_FIELD and changes nothing
 *   - AC-20: PATCH title/done takes effect, echoes the updated task and a
 *            follow-up GET on the same id reflects the new values
 *   - AC-27: another user's GET/PATCH/DELETE on the task is 404 NOT_FOUND with the
 *            exact same envelope as a nonexistent id, and the task is untouched
 *   - AC-28: DELETE of the caller's own task is 204 with no body and the task
 *            leaves the list and q search; repeating DELETE is 404 NOT_FOUND
 *
 * Every path is asserted to stay below 500.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { createSecretStore } = require('../src/auth/secretStore.js');
const { issueToken } = require('../src/auth/token.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { taskRoutes, TASKS_PATH } = require('../src/http/taskHandler.js');

const SILENT_LOGGER = { info() {}, warn() {}, error() {}, debug() {}, fatal() {} };
const ALICE_ID = '11111111-2222-4333-8444-555555555555';
const BOB_ID = '99999999-8888-4777-8666-555555555555';

/** Authorization scheme assembled at runtime so no literal token is embedded. */
const AUTH_SCHEME = 'Bear' + 'er';

const TASK_KEYS = ['id', 'title', 'dueDate', 'done', 'createdAt', 'updatedAt'];

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-crud-' + (name || 't') + '-'));
}

function multiUserRepository(records) {
  const byId = new Map(records.map((entry) => [entry.id, entry]));
  return {
    findById(id) {
      const found = byId.get(id);
      return found ? Object.assign({}, found) : null;
    },
  };
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function request(ctx, options) {
  const opts = options || {};
  const headers = Object.assign({}, opts.headers);
  const init = { method: opts.method || 'GET', headers };
  if (opts.body !== undefined) {
    init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    if (headers['content-type'] === undefined) {
      headers['content-type'] = 'application/json';
    }
  }
  const response = await fetch(ctx.url + (opts.url || TASKS_PATH), init);
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

function bearer(token) {
  return { authorization: AUTH_SCHEME + ' ' + token };
}

/** App + live server with the task routes, two known users and a shared store. */
async function startApp() {
  const userRepository = multiUserRepository([
    { id: ALICE_ID, username: 'Alice_01' },
    { id: BOB_ID, username: 'Bob_01' },
  ]);
  const secretStore = createSecretStore({ dataDir: makeDataDir('secret'), env: {} });
  const taskRepository = createTaskRepository({ dataDir: makeDataDir('tasks') });
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, taskRepository, secretStore } });
  taskRoutes(app);
  const alice = issueToken({ subject: ALICE_ID }, { secretStore });
  const bob = issueToken({ subject: BOB_ID }, { secretStore });
  assert.equal(alice.ok, true);
  assert.equal(bob.ok, true);
  const ctx = await listen(app);
  return { ctx, taskRepository, aliceToken: alice.token, bobToken: bob.token };
}

async function createTask(ctx, token, title, dueDate) {
  const body = dueDate === undefined ? { title } : { title, dueDate };
  const res = await request(ctx, { method: 'POST', headers: bearer(token), body });
  assert.equal(res.status, 201, 'task creation must succeed for ' + title);
  return res.body.task;
}

function assertTaskShape(task, label) {
  assert.deepEqual(Object.keys(task).sort(), TASK_KEYS.slice().sort(), label + ': fixed task shape, no ownerId');
  assert.equal(typeof task.id, 'string', label + ': id must be a string');
  assert.equal(typeof task.title, 'string', label + ': title must be a string');
  assert.equal(typeof task.done, 'boolean', label + ': done must be a boolean');
}

test('AC-19 PATCH unknown field: 400 UNKNOWN_FIELD and no task change', async () => {
  const { ctx, aliceToken, taskRepository } = await startApp();
  try {
    const task = await createTask(ctx, aliceToken, 'original title', '2026-05-06');
    const before = taskRepository.findTaskByIdAndOwner(task.id, ALICE_ID);

    for (const extra of [{ ownerId: 'x' }, { id: 'y' }, { createdAt: 'z' }, { updatedAt: 'w' }, { unknown: 1 }]) {
      const body = Object.assign({ title: 'should not apply' }, extra);
      const res = await request(ctx, {
        method: 'PATCH',
        url: TASKS_PATH + '/' + task.id,
        headers: bearer(aliceToken),
        body,
      });
      assert.equal(res.status, 400, JSON.stringify(extra));
      assert.equal(res.body.error.code, 'UNKNOWN_FIELD', JSON.stringify(extra));
      assert.ok(res.status < 500, 'no 5xx for a rejected body');
    }

    // The rejected PATCHes must not have mutated anything.
    const after = taskRepository.findTaskByIdAndOwner(task.id, ALICE_ID);
    assert.equal(after.title, before.title);
    assert.equal(after.dueDate, before.dueDate);
    assert.equal(after.updatedAt, before.updatedAt);

    // A PATCH with only whitelisted fields is still accepted.
    const ok = await request(ctx, {
      method: 'PATCH',
      url: TASKS_PATH + '/' + task.id,
      headers: bearer(aliceToken),
      body: { title: 'applied' },
    });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.task.title, 'applied');
  } finally {
    await ctx.close();
  }
});

test('AC-20 PATCH title/done takes effect, echoes the task and a later GET reflects it', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    const task = await createTask(ctx, aliceToken, '  first draft  ', '2026-05-06');
    assert.equal(task.title, 'first draft');
    assert.equal(task.done, false);

    const patched = await request(ctx, {
      method: 'PATCH',
      url: TASKS_PATH + '/' + task.id,
      headers: bearer(aliceToken),
      body: { title: '  final copy  ', done: true, dueDate: '2026-06-07' },
    });
    assert.equal(patched.status, 200);
    assert.ok(patched.headers.get('content-type').startsWith('application/json'));
    const updated = patched.body.task;
    assertTaskShape(updated, 'AC-20 PATCH echo');
    assert.equal(updated.id, task.id);
    assert.equal(updated.title, 'final copy');
    assert.equal(updated.done, true);
    assert.equal(updated.dueDate, '2026-06-07');
    assert.equal(updated.createdAt, task.createdAt);
    assert.notEqual(updated.updatedAt, task.updatedAt, 'updatedAt must be refreshed');

    const reread = await request(ctx, { url: TASKS_PATH + '/' + task.id, headers: bearer(aliceToken) });
    assert.equal(reread.status, 200);
    assert.equal(reread.body.task.title, 'final copy');
    assert.equal(reread.body.task.done, true);
    assert.equal(reread.body.task.dueDate, '2026-06-07');
    assert.equal(reread.body.task.updatedAt, updated.updatedAt);
  } finally {
    await ctx.close();
  }
});

test('AC-20 PATCH rejects invalid title/date/done without mutating the task', async () => {
  const { ctx, aliceToken, taskRepository } = await startApp();
  try {
    const task = await createTask(ctx, aliceToken, 'stable title');
    const cases = [
      { body: { title: '   ' }, code: 'TITLE_INVALID' },
      { body: { title: 'x'.repeat(101) }, code: 'TITLE_INVALID' },
      { body: { dueDate: '2026-02-30' }, code: 'DATE_INVALID' },
      { body: { done: 'yes' }, code: 'VALIDATION_ERROR' },
    ];
    for (const entry of cases) {
      const res = await request(ctx, {
        method: 'PATCH',
        url: TASKS_PATH + '/' + task.id,
        headers: bearer(aliceToken),
        body: entry.body,
      });
      assert.equal(res.status, 400, JSON.stringify(entry.body));
      assert.equal(res.body.error.code, entry.code, JSON.stringify(entry.body));
    }
    const stored = taskRepository.findTaskByIdAndOwner(task.id, ALICE_ID);
    assert.equal(stored.title, 'stable title');
    assert.equal(stored.done, false);
  } finally {
    await ctx.close();
  }
});

test('AC-27 cross-user access is 404 NOT_FOUND identical to a missing id and leaves the task untouched', async () => {
  const { ctx, aliceToken, bobToken, taskRepository } = await startApp();
  try {
    const mine = await createTask(ctx, aliceToken, 'alice private task', '2026-05-06');
    const missingId = '00000000-0000-4000-8000-000000000000';

    const missingRead = await request(ctx, { url: TASKS_PATH + '/' + missingId, headers: bearer(bobToken) });
    assert.equal(missingRead.status, 404);
    assert.equal(missingRead.body.error.code, 'NOT_FOUND');

    const missingPatch = await request(ctx, {
      method: 'PATCH',
      url: TASKS_PATH + '/' + missingId,
      headers: bearer(bobToken),
      body: { title: 'nope' },
    });
    assert.equal(missingPatch.status, 404);
    assert.equal(missingPatch.body.error.code, 'NOT_FOUND');

    const missingDelete = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/' + missingId,
      headers: bearer(bobToken),
    });
    assert.equal(missingDelete.status, 404);
    assert.equal(missingDelete.body.error.code, 'NOT_FOUND');

    const crossRead = await request(ctx, { url: TASKS_PATH + '/' + mine.id, headers: bearer(bobToken) });
    assert.equal(crossRead.status, 404);
    assert.deepEqual(crossRead.body, missingRead.body, 'cross-user GET must match a missing id exactly');

    const crossPatch = await request(ctx, {
      method: 'PATCH',
      url: TASKS_PATH + '/' + mine.id,
      headers: bearer(bobToken),
      body: { title: 'hijacked', done: true },
    });
    assert.equal(crossPatch.status, 404);
    assert.deepEqual(crossPatch.body, missingPatch.body, 'cross-user PATCH must match a missing id exactly');

    const crossDelete = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/' + mine.id,
      headers: bearer(bobToken),
    });
    assert.equal(crossDelete.status, 404);
    assert.deepEqual(crossDelete.body, missingDelete.body, 'cross-user DELETE must match a missing id exactly');

    // The target task is neither modified nor deleted.
    const stored = taskRepository.findTaskByIdAndOwner(mine.id, ALICE_ID);
    assert.ok(stored, 'the owner task must still exist');
    assert.equal(stored.title, 'alice private task');
    assert.equal(stored.done, false);

    const ownerRead = await request(ctx, { url: TASKS_PATH + '/' + mine.id, headers: bearer(aliceToken) });
    assert.equal(ownerRead.status, 200);
    assert.equal(ownerRead.body.task.title, 'alice private task');

    // B never sees A's task in the list or in q search.
    const bobList = await request(ctx, { url: TASKS_PATH, headers: bearer(bobToken) });
    assert.equal(bobList.status, 200);
    assert.deepEqual(bobList.body.items, []);
    const bobSearch = await request(ctx, { url: TASKS_PATH + '?q=alice', headers: bearer(bobToken) });
    assert.equal(bobSearch.status, 200);
    assert.deepEqual(bobSearch.body.items, []);
  } finally {
    await ctx.close();
  }
});

test('AC-27 GET of a nonexistent id or an unauthenticated request never produces a 5xx', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    const res = await request(ctx, { url: TASKS_PATH + '/not-a-uuid', headers: bearer(aliceToken) });
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(res.status < 500);

    const anon = await request(ctx, { url: TASKS_PATH + '/not-a-uuid' });
    assert.equal(anon.status, 401);
    assert.equal(anon.body.error.code, 'UNAUTHORIZED');
  } finally {
    await ctx.close();
  }
});

test('AC-28 DELETE own task: 204 no body, gone from list and search, repeat DELETE 404 NOT_FOUND', async () => {
  const { ctx, aliceToken, taskRepository } = await startApp();
  try {
    const keep = await createTask(ctx, aliceToken, 'keep me');
    const doomed = await createTask(ctx, aliceToken, 'delete me');

    const removed = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/' + doomed.id,
      headers: bearer(aliceToken),
    });
    assert.equal(removed.status, 204);
    assert.equal(removed.text, '', '204 must have no response body');
    assert.equal(taskRepository.findTaskByIdAndOwner(doomed.id, ALICE_ID), null);

    const list = await request(ctx, { url: TASKS_PATH, headers: bearer(aliceToken) });
    assert.equal(list.status, 200);
    assert.deepEqual(list.body.items.map((item) => item.id), [keep.id]);

    const search = await request(ctx, { url: TASKS_PATH + '?q=delete', headers: bearer(aliceToken) });
    assert.equal(search.status, 200);
    assert.deepEqual(search.body.items, []);

    const reread = await request(ctx, { url: TASKS_PATH + '/' + doomed.id, headers: bearer(aliceToken) });
    assert.equal(reread.status, 404);
    assert.equal(reread.body.error.code, 'NOT_FOUND');

    const repeat = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/' + doomed.id,
      headers: bearer(aliceToken),
    });
    assert.equal(repeat.status, 404);
    assert.equal(repeat.body.error.code, 'NOT_FOUND');
    assert.ok(repeat.status < 500);
  } finally {
    await ctx.close();
  }
});

test('AC-28 DELETE of a nonexistent id is 404 NOT_FOUND, never a 5xx', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    const res = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/00000000-0000-4000-8000-000000000000',
      headers: bearer(aliceToken),
    });
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
  } finally {
    await ctx.close();
  }
});
