'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { startTestServer, getJson } = require('./helpers.js');
const homeModule = require('../src/http/homeHandler.js');
const { HOME_CONTENT_TYPE, HOME_TESTIDS } = homeModule;

const REQUIRED_TESTIDS = ['home-title', 'task-list', 'search-input', 'new-task-button'];

async function getHome(url) {
  const response = await fetch(url + '/');
  const text = await response.text();
  return { status: response.status, headers: response.headers, text };
}

test('AC-21 home: GET / returns 200 text/html with the full document', async () => {
  const ctx = await startTestServer();
  try {
    const response = await getHome(ctx.url);
    assert.equal(response.status, 200);
    assert.match(String(response.headers.get('content-type')), /^text\/html/);
    assert.equal(String(response.headers.get('content-type')).includes('charset=utf-8'), true);
    assert.equal(response.text.startsWith('<!DOCTYPE html>'), true);
    assert.equal(response.text.includes('</html>'), true);
    assert.equal(HOME_CONTENT_TYPE, 'text/html; charset=utf-8');
  } finally {
    await ctx.close();
  }
});

test('AC-21 home: all four data-testid elements exist in the first server response body', async () => {
  const ctx = await startTestServer();
  try {
    const response = await getHome(ctx.url);
    for (const testid of REQUIRED_TESTIDS) {
      assert.equal(
        response.text.includes('data-testid="' + testid + '"'),
        true,
        'missing data-testid=' + testid
      );
    }
    assert.deepEqual(Object.values(HOME_TESTIDS).slice().sort(), REQUIRED_TESTIDS.slice().sort());
  } finally {
    await ctx.close();
  }
});

test('AC-21 home: the task list has a container plus an empty-state placeholder', async () => {
  const html = homeModule.renderHomePage();
  assert.equal(html.includes('<ul class="task-list-items"></ul>'), true);
  assert.equal(html.includes('data-testid="task-list"'), true);
  assert.equal(html.includes(homeModule.HOME_EMPTY_STATE), true);
});

test('AC-21 home: the search input and the new-task button are real form controls', async () => {
  const html = homeModule.renderHomePage();
  assert.equal(/<input[^>]*id="search-input"[^>]*data-testid="search-input"/.test(html), true);
  assert.equal(/<button[^>]*data-testid="new-task-button"[^>]*>/.test(html), true);
});

test('AC-21 home: the page needs no client script and no asynchronous rendering', async () => {
  const html = homeModule.renderHomePage();
  assert.equal(/<script/i.test(html), false);
  const ctx = await startTestServer();
  try {
    const response = await getHome(ctx.url);
    assert.equal(response.text.includes('home-title'), true);
  } finally {
    await ctx.close();
  }
});

test('AC-21 home: GET / never echoes request input and is served without authentication', async () => {
  const ctx = await startTestServer();
  try {
    const crafted = await fetch(ctx.url + '/?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E');
    const text = await crafted.text();
    assert.equal(crafted.status, 200);
    assert.equal(text.includes('<script>alert(1)</script>'), false);
    assert.equal(text.includes('data-testid="home-title"'), true);
  } finally {
    await ctx.close();
  }
});
