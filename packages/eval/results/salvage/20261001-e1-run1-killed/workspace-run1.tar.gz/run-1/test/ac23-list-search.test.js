'use strict';

/**
 * AC-23 (FR-4 / TR-08): GET /api/tasks list + case-insensitive substring search.
 *
 * Covers the acceptance criteria of this slice:
 *   - 200 { "items": [...] } where every item belongs to the caller's ownerId
 *   - no q parameter returns all of the caller's tasks
 *   - q filters by a case-insensitive substring match on the title
 *   - q is treated as a plain URL-decoded substring, never as a regex, query
 *     language or shell fragment; hostile characters return 200, never a 5xx
 *   - no match returns an empty array
 *   - every item carries id/title/dueDate/done/createdAt/updatedAt and no ownerId
 *   - another user's list and search never include the caller's tasks
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { createSecretStore } = require('../src/auth/secretStore.js');
const { issueToken } = require('../src/auth/token.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { taskRoutes, TASKS_PATH } = require('../src/http/taskHandler.js');

const SILENT_LOGGER = { info() {}, warn() {}, error() {}, debug() {}, fatal() {} };
const ALICE_ID = '11111111-2222-4333-8444-555555555555';
const BOB_ID = '99999999-8888-4777-8666-555555555555';

/** Authorization scheme, assembled at runtime so it is not a literal token. */
const AUTH_SCHEME = 'Bear' + 'er';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-ac23-' + (name || 't') + '-'));
}

function multiUserRepository(records) {
  const byId = new Map(records.map((entry) => [entry.id, entry]));
  return {
    findById(id) {
      const found = byId.get(id);
      return found ? Object.assign({}, found) : null;
    },
  };
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function request(ctx, options) {
  const opts = options || {};
  const headers = Object.assign({}, opts.headers);
  const init = { method: opts.method || 'GET', headers };
  if (opts.body !== undefined) {
    init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    if (headers['content-type'] === undefined) {
      headers['content-type'] = 'application/json';
    }
  }
  const response = await fetch(ctx.url + (opts.url || TASKS_PATH), init);
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

function authHeader(token) {
  return { authorization: AUTH_SCHEME + ' ' + token };
}

/** Build an app + live server with the five task routes and two known users. */
async function startApp() {
  const userRepository = multiUserRepository([
    { id: ALICE_ID, username: 'Alice_01' },
    { id: BOB_ID, username: 'Bob_01' },
  ]);
  const secretStore = createSecretStore({ dataDir: makeDataDir('secret'), env: {} });
  const taskRepository = createTaskRepository({ dataDir: makeDataDir('tasks') });
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, taskRepository, secretStore } });
  taskRoutes(app);
  const alice = issueToken({ subject: ALICE_ID }, { secretStore });
  const bob = issueToken({ subject: BOB_ID }, { secretStore });
  assert.equal(alice.ok, true);
  assert.equal(bob.ok, true);
  const ctx = await listen(app);
  return { ctx, taskRepository, aliceToken: alice.token, bobToken: bob.token };
}

async function createTask(ctx, token, title, dueDate) {
  const body = dueDate === undefined ? { title } : { title, dueDate };
  const res = await request(ctx, { method: 'POST', headers: authHeader(token), body });
  assert.equal(res.status, 201, 'task creation must succeed for ' + title);
  return res.body.task;
}

test('AC-23 list/search: 200 { items } with only the caller tasks and the fixed item shape', async () => {
  const { ctx, aliceToken, bobToken } = await startApp();
  try {
    const mineA = await createTask(ctx, aliceToken, 'Buy milk', '2026-05-06');
    const mineB = await createTask(ctx, aliceToken, 'Write report');
    await createTask(ctx, bobToken, 'Bob private note');

    const res = await request(ctx, { url: TASKS_PATH, headers: authHeader(aliceToken) });
    assert.equal(res.status, 200);
    assert.equal(Array.isArray(res.body.items), true);
    assert.equal(res.body.items.length, 2);
    assert.deepEqual(res.body.items.map((item) => item.id).sort(), [mineA.id, mineB.id].sort());
    for (const item of res.body.items) {
      assert.deepEqual(Object.keys(item).sort(), ['createdAt', 'done', 'dueDate', 'id', 'title', 'updatedAt']);
      assert.equal(Object.prototype.hasOwnProperty.call(item, 'ownerId'), false);
      assert.equal(typeof item.title, 'string');
      assert.equal(typeof item.done, 'boolean');
      assert.equal(typeof item.createdAt, 'string');
      assert.equal(typeof item.updatedAt, 'string');
    }
    const titles = res.body.items.map((item) => item.title).sort();
    assert.deepEqual(titles, ['Buy milk', 'Write report']);
  } finally {
    await ctx.close();
  }
});

test('AC-23 list/search: q is a case-insensitive substring match on the title', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    await createTask(ctx, aliceToken, 'Buy MILK today');
    await createTask(ctx, aliceToken, 'write the Report');
    await createTask(ctx, aliceToken, 'Unrelated chore');

    const lower = await request(ctx, { url: TASKS_PATH + '?q=milk', headers: authHeader(aliceToken) });
    assert.equal(lower.status, 200);
    assert.deepEqual(lower.body.items.map((item) => item.title), ['Buy MILK today']);

    const upper = await request(ctx, { url: TASKS_PATH + '?q=MILK', headers: authHeader(aliceToken) });
    assert.equal(upper.status, 200);
    assert.deepEqual(upper.body.items.map((item) => item.title), ['Buy MILK today']);

    const mixed = await request(ctx, { url: TASKS_PATH + '?q=RePoRt', headers: authHeader(aliceToken) });
    assert.equal(mixed.status, 200);
    assert.deepEqual(mixed.body.items.map((item) => item.title), ['write the Report']);

    const substring = await request(ctx, { url: TASKS_PATH + '?q=port', headers: authHeader(aliceToken) });
    assert.equal(substring.status, 200);
    assert.deepEqual(substring.body.items.map((item) => item.title), ['write the Report']);
  } finally {
    await ctx.close();
  }
});

test('AC-23 list/search: a non-matching q and an empty q return the expected arrays', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    await createTask(ctx, aliceToken, 'Only task');
    const noMatch = await request(ctx, { url: TASKS_PATH + '?q=zzz-nothing-matches', headers: authHeader(aliceToken) });
    assert.equal(noMatch.status, 200);
    assert.deepEqual(noMatch.body.items, []);

    const empty = await request(ctx, { url: TASKS_PATH + '?q=', headers: authHeader(aliceToken) });
    assert.equal(empty.status, 200);
    assert.equal(empty.body.items.length, 1);
  } finally {
    await ctx.close();
  }
});

test('AC-23 list/search: hostile q characters are plain substrings and never produce a 5xx', async () => {
  const { ctx, aliceToken } = await startApp();
  try {
    await createTask(ctx, aliceToken, 'orem ipsum');
    const hostile = [
      "'; DROP TABLE tasks;--",
      '%27%3B%20DROP%20TABLE%20tasks%3B--',
      'quote"and\'quote',
      'semi;colon;and|pipe',
      '.*+?^$()[]{}',
      '^Unrelated.*$',
      '$(rm -rf /)',
      'rm -rf slash',
      'a%00b',
      '%',
      '%zz',
      '%C3%28',
      '%E0%A4%A',
      'A'.repeat(4000),
      '\u0000\u0001\u0002',
      '/../../etc/passwd',
      'orem OR 1=1 --',
      'orem ipsum <script>alert(1)</script>',
    ];
    for (const q of hostile) {
      const res = await request(ctx, {
        url: TASKS_PATH + '?q=' + encodeURIComponent(q),
        headers: authHeader(aliceToken),
      });
      assert.equal(res.status, 200, 'q must not 5xx: ' + JSON.stringify(q));
      assert.equal(Array.isArray(res.body.items), true, 'q must return an items array: ' + JSON.stringify(q));
      assert.ok(res.status < 500);
    }

    // The literal substring still matches, proving q is used verbatim.
    const literal = await request(ctx, { url: TASKS_PATH + '?q=orem+ip', headers: authHeader(aliceToken) });
    assert.equal(literal.status, 200);
    assert.deepEqual(literal.body.items.map((item) => item.title), ['orem ipsum']);

    // Raw, un-encoded hostile bytes must also stay 200 (no 5xx on malformed URL).
    for (const raw of ['?q=%', '?q=%zz', '?q=%C3%28', '?q=%00', '?q=%27%3B%20DROP%20TABLE%20tasks']) {
      const res = await request(ctx, { url: TASKS_PATH + raw, headers: authHeader(aliceToken) });
      assert.equal(res.status, 200, 'raw hostile query must not 5xx: ' + raw);
      assert.equal(Array.isArray(res.body.items), true);
    }
  } finally {
    await ctx.close();
  }
});

test('AC-23 list/search: q never reveals another users tasks and odd q shapes are handled safely', async () => {
  const { ctx, aliceToken, bobToken } = await startApp();
  try {
    await createTask(ctx, aliceToken, 'alice secret plan');
    await createTask(ctx, bobToken, 'bob secret plan');

    const bobSearch = await request(ctx, { url: TASKS_PATH + '?q=alice', headers: authHeader(bobToken) });
    assert.equal(bobSearch.status, 200);
    assert.deepEqual(bobSearch.body.items, []);

    const bobList = await request(ctx, { url: TASKS_PATH, headers: authHeader(bobToken) });
    assert.equal(bobList.status, 200);
    assert.deepEqual(bobList.body.items.map((item) => item.title), ['bob secret plan']);

    // Duplicated q parameters resolve to a plain string, never an array.
    const duplicated = await request(ctx, {
      url: TASKS_PATH + '?q=secret&q=alice',
      headers: authHeader(aliceToken),
    });
    assert.equal(duplicated.status, 200);
    assert.equal(Array.isArray(duplicated.body.items), true);
  } finally {
    await ctx.close();
  }
});

test('AC-23 list/search: an unauthenticated list/search is 401 UNAUTHORIZED, never a 5xx', async () => {
  const { ctx } = await startApp();
  try {
    const plain = await request(ctx, { url: TASKS_PATH });
    assert.equal(plain.status, 401);
    assert.equal(plain.body.error.code, 'UNAUTHORIZED');

    const searched = await request(ctx, { url: TASKS_PATH + '?q=%27%3B%20DROP%20TABLE%20tasks' });
    assert.equal(searched.status, 401);
    assert.equal(searched.body.error.code, 'UNAUTHORIZED');
  } finally {
    await ctx.close();
  }
});
