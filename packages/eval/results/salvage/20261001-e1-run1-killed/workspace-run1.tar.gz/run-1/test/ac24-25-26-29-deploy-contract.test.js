'use strict';

/**
 * AC-24 / AC-25 / AC-26 / AC-29 deployment static contract tests (TS-05 / TS-06 / TS-07).
 *
 * No container runtime is available in this environment, so the deployment
 * contract is asserted statically from the Dockerfile, the package.json start
 * script and the runtime logging sources:
 *
 *   - AC-24: the image is based on a node base image, the container launch runs
 *     the packaged start command, port 3000 is published and the three health
 *     endpoints are wired for post-run reachability.
 *   - AC-25: VOLUME /data plus ENV DATA_DIR=/data are declared so a container
 *     restart keeps persisted data, and neither the build nor the start command
 *     points DATA_DIR anywhere else.
 *   - AC-26: a dedicated non-root user is created, owns /data and is selected by
 *     the final USER instruction.
 *   - AC-29: application logs go to stdout/stderr (console or the stdout stream),
 *     never to a file, and no log call prints a plaintext password or signing-key
 *     material.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { ROOT, listFiles, relative, read } = require('../src/scripts/scan.js');
const { HEALTH_PATHS } = require('../src/http/app.js');

const DOCKERFILE_PATH = path.join(ROOT, 'Dockerfile');
const PACKAGE_PATH = path.join(ROOT, 'package.json');
const LOGGER_PATH = path.join(ROOT, 'src/logger.js');

const RUNTIME_FILES = listFiles('src')
  .filter((file) => file.endsWith('.js'))
  .filter((file) => !relative(file).startsWith('src/scripts/'));

/** A stdout/stderr redirect whose target is a file or path (not the 2>&1 merge). */
const FILE_REDIRECT = /(?:[0-9]?)>>?\s*(?!&)\S/;
/** Piping output into tee would duplicate the log into a file. */
const TEE_PIPE = /(^|[\s|;&(])tee(\s|$)/;
/** A quoted token that names a .log file. */
const LOG_FILE_PATH = /['"][^'"]*\.log['"]/;
/** Material that must never appear inside a log call. */
const FORBIDDEN_LOG_MATERIAL = /password|passwd|secret|getKeyBuffer|getKey\s*\(/i;
/** A delete verb whose target is the data volume. */
const REMOVE_DATA = /(^|[;&|]\s*)(rm|rmdir)\s+[^\n]*\/data(\s|$)/;

/** Dockerfile instructions with comments removed, continuations joined and spaces collapsed. */
function dockerInstructions(source) {
  return source
    .replace(/\\\r?\n/g, ' ')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && line.startsWith('#') === false)
    .map((line) => line.replace(/\s+/g, ' '));
}

/** Every value declared for one Dockerfile instruction, e.g. all ENV lines. */
function instructionValues(instructions, name) {
  const upper = name.toUpperCase();
  const values = [];
  for (const line of instructions) {
    const match = line.match(/^([A-Za-z]+)\s+(.*)$/);
    if (match && match[1].toUpperCase() === upper) {
      values.push(match[2].trim());
    }
  }
  return values;
}

/** The packaged start command (package.json scripts.start). */
function startScriptSource() {
  const pkg = JSON.parse(read(PACKAGE_PATH));
  return String((pkg.scripts && pkg.scripts.start) || '');
}

/** Extract the full text of every logger/console call expression in a source file. */
function logCallExpressions(source) {
  const callStart = /\b(?:logger|console)\.(?:debug|info|warn|error|fatal|log)\s*\(/g;
  const calls = [];
  let match = callStart.exec(source);
  while (match !== null) {
    let depth = 0;
    let end = -1;
    for (let index = match.index + match[0].length - 1; index < source.length; index += 1) {
      if (source[index] === '(') {
        depth += 1;
      } else if (source[index] === ')') {
        depth -= 1;
        if (depth === 0) {
          end = index;
          break;
        }
      }
    }
    if (end > -1) {
      calls.push(source.slice(match.index, end + 1));
    }
    match = callStart.exec(source);
  }
  return calls;
}

test('AC-24: the Dockerfile builds a node image that runs the packaged start command on port 3000 with health routes', () => {
  assert.equal(fs.existsSync(DOCKERFILE_PATH), true, 'a Dockerfile must exist at the repo root');
  const instructions = dockerInstructions(read(DOCKERFILE_PATH));

  const fromValues = instructionValues(instructions, 'FROM');
  assert.equal(fromValues.length > 0, true, 'the Dockerfile must declare a FROM base image');
  for (const value of fromValues) {
    assert.match(value, /^node(:[A-Za-z0-9._-]+)?(\s+AS\s+\S+)?$/i, 'every FROM must be a node base image, saw: ' + value);
  }

  assert.equal(fs.existsSync(PACKAGE_PATH), true, 'package.json must exist so the image can build');
  assert.equal(fs.existsSync(path.join(ROOT, 'pnpm-lock.yaml')), true, 'pnpm-lock.yaml must be committed for a reproducible build');

  const envs = instructionValues(instructions, 'ENV');
  assert.equal(envs.includes('PORT=3000'), true, 'ENV PORT=3000 must be declared, saw: ' + JSON.stringify(envs));

  const exposes = instructionValues(instructions, 'EXPOSE').join(' ');
  assert.match(exposes, /(^|[\s/])3000([\s/]|$)/, 'container port 3000 must be exposed, saw: ' + exposes);

  const launch = instructionValues(instructions, 'ENTRYPOINT')
    .concat(instructionValues(instructions, 'CMD'))
    .join(' ');
  assert.equal(launch.length > 0, true, 'the Dockerfile must define CMD or ENTRYPOINT');
  const start = startScriptSource();
  assert.match(start, /node\s+src\/server\.js/, 'the packaged start script must launch src/server.js, saw: ' + start);
  assert.match(launch, /(npm|pnpm|node)/i, 'the container launch must invoke the packaged runtime, saw: ' + launch);
  assert.match(launch, /start|src\/server\.js/, 'the container must run the application start command, saw: ' + launch);

  assert.deepEqual(HEALTH_PATHS.slice().sort(), ['/health', '/healthz', '/ready']);
  const appSource = read(path.join(ROOT, 'src/http/app.js'));
  assert.match(appSource, /HEALTH_PATHS\s*=\s*Object\.freeze\(\[[^\]]*\/healthz[^\]]*\/health[^\]]*\/ready/, 'the health routes must be wired in the app');
});

test('AC-26: the container creates a dedicated non-root user that owns /data and runs as that USER', () => {
  const instructions = dockerInstructions(read(DOCKERFILE_PATH));

  const userValues = instructionValues(instructions, 'USER');
  assert.equal(userValues.length > 0, true, 'a USER instruction is required so the container is not root');
  for (const value of userValues) {
    const name = value.split(':')[0].trim().toLowerCase();
    assert.equal(name !== '' && name !== 'root' && name !== '0', true, 'USER must not be root, saw: ' + value);
  }
  const user = userValues[userValues.length - 1].split(':')[0].trim();

  const runValues = instructionValues(instructions, 'RUN');
  const userCreation = runValues.filter((value) => /adduser|useradd/.test(value)).join(' ');
  assert.equal(userCreation.length > 0, true, 'a non-root user must be created with adduser/useradd');
  assert.equal(userCreation.includes(user), true, 'the USER ' + user + ' must be created in a RUN step, saw: ' + userCreation);

  const chown = runValues.filter((value) => /chown/.test(value)).join(' ');
  assert.equal(chown.includes('/data'), true, 'the non-root user must be granted ownership of /data, saw: ' + chown);
  assert.equal(new RegExp('chown[^;&]*\\b' + user + '\\b').test(chown), true, '/data must be owned by ' + user + ', saw: ' + chown);

  const addUserIndex = instructions.findIndex((line) => /^RUN\b/i.test(line) && /adduser|useradd/.test(line));
  const userIndex = instructions.findIndex((line) => /^USER\b/i.test(line));
  assert.equal(addUserIndex > -1 && userIndex > addUserIndex, true, 'USER must be declared after the user is created');
});

test('AC-25: the container declares VOLUME /data with ENV DATA_DIR=/data and never repoints the data volume', () => {
  const dockerText = read(DOCKERFILE_PATH);
  const instructions = dockerInstructions(dockerText);

  const volumes = instructionValues(instructions, 'VOLUME').join(' ');
  assert.equal(volumes.includes('/data'), true, 'VOLUME /data must be declared, saw: ' + volumes);

  const envs = instructionValues(instructions, 'ENV');
  assert.equal(envs.includes('DATA_DIR=/data'), true, 'ENV DATA_DIR=/data must be declared, saw: ' + JSON.stringify(envs));

  for (const line of instructions) {
    assert.equal(REMOVE_DATA.test(line), false, 'the build must not delete the data volume: ' + line);
  }

  const start = startScriptSource();
  assert.equal(/DATA_DIR=(?!\s*\/data)/.test(start), false, 'the start script must not point DATA_DIR elsewhere, saw: ' + start);
  assert.equal(/\/tmp|mktemp/.test(start), false, 'the start script must not use a temporary data directory, saw: ' + start);

  const configSource = read(path.join(ROOT, 'src/config.js'));
  assert.match(configSource, /CONTAINER_DATA_DIR\s*=\s*'\/data'/, 'the container DATA_DIR default must be /data');
  assert.match(configSource, /DEFAULT_DATA_DIR\s*=\s*'\.\/data'/, 'the local DATA_DIR default must be ./data');
});

test('AC-29: container logs go to stdout/stderr, never to a file, and print no password or signing-key material', () => {
  const dockerText = read(DOCKERFILE_PATH);
  const instructions = dockerInstructions(dockerText);
  const start = startScriptSource();

  for (const line of instructions.concat([start])) {
    assert.equal(FILE_REDIRECT.test(line), false, 'logs must not be redirected to a file: ' + line);
    assert.equal(TEE_PIPE.test(line), false, 'logs must not be piped into tee: ' + line);
  }
  assert.equal(LOG_FILE_PATH.test(dockerText), false, 'the Dockerfile must not reference a .log file');
  assert.equal(LOG_FILE_PATH.test(start), false, 'the start script must not reference a .log file');

  const loggerSource = read(LOGGER_PATH);
  assert.match(loggerSource, /stream\s*=\s*opts\.stream\s*\|\|\s*process\.stdout/, 'the logger default sink must be process.stdout');
  assert.equal(/require\('node:fs'\)/.test(loggerSource), false, 'the logger must not import node:fs');
  assert.equal(/createWriteStream|appendFile/.test(loggerSource), false, 'the logger must not write logs to a file stream');

  for (const file of RUNTIME_FILES) {
    const rel = relative(file);
    const source = read(file);
    assert.equal(/process\.stdout\s*=/.test(source), false, rel + ' must not reassign process.stdout');
    assert.equal(/process\.stderr\s*=/.test(source), false, rel + ' must not reassign process.stderr');
    assert.equal(LOG_FILE_PATH.test(source), false, rel + ' must not reference a .log file');
  }

  const logSources = RUNTIME_FILES.map((file) => read(file)).join('\n');
  assert.match(logSources, /\b(?:logger|console)\s*\.\s*(?:debug|info|warn|error|fatal|log)\s*\(/, 'application logs must go through console or the logger');

  for (const file of RUNTIME_FILES) {
    for (const call of logCallExpressions(read(file))) {
      assert.equal(FORBIDDEN_LOG_MATERIAL.test(call), false, relative(file) + ' log call must not print credentials: ' + call);
    }
  }

  const sensitiveKeyLine = loggerSource.split('\n').find((line) => line.includes('SENSITIVE_KEY =')) || '';
  assert.notEqual(sensitiveKeyLine, '', 'the logger must define a SENSITIVE_KEY redaction set');
  for (const word of ['pass', 'secret', 'token']) {
    assert.equal(sensitiveKeyLine.toLowerCase().includes(word), true, 'the redaction set must cover ' + word);
  }
});
