'use strict';

/**
 * AC-01 / AC-24 precondition: the three health endpoints must stay reachable
 * after the PORT / DATA_DIR configuration and bind-address rework.
 *
 *   - GET /healthz, GET /health and GET /ready return 200 with {"status":"ok"}.
 *   - When PORT is set to a non-default value the service listens on that port
 *     and the health endpoints answer there.
 *   - The server binds 0.0.0.0 so a container port mapping is reachable.
 *   - /ready returns 200 after DATA_DIR data has been loaded on startup.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { loadConfig } = require('../src/config.js');
const { startServer } = require('../src/server.js');
const { createLogger } = require('../src/logger.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { makeDataDir, getJson } = require('./helpers.js');

const HEALTH_PATHS = ['/healthz', '/health', '/ready'];
const SILENT = createLogger({ stream: { write() {} } });

/** Start the real server on a custom PORT, returning { server, baseUrl, port, host, close }. */
async function startOnCustomPort(dataDir, PORT) {
  const config = loadConfig({ PORT: String(PORT), DATA_DIR: dataDir, TOKEN_SECRET: 'test-signing-key-0123456789' });
  const started = await startServer({ config, logger: SILENT });
  const address = started.server.address();
  const port = address.port;
  return {
    server: started.server,
    port,
    configuredPort: PORT,
    host: address.address,
    baseUrl: 'http://127.0.0.1:' + port,
    close() {
      return new Promise((resolve) => {
        started.server.close(() => resolve());
        started.server.closeAllConnections();
      });
    },
  };
}

test('AC-01/AC-24: health endpoints return 200 {"status":"ok"} on a custom PORT bound to 0.0.0.0', async () => {
  const dataDir = makeDataDir('ac24-custom-port');
  const customPort = 42317;
  const ctx = await startOnCustomPort(dataDir, customPort);
  try {
    assert.equal(ctx.host, '0.0.0.0', 'the server must bind 0.0.0.0 so port mapping is reachable');
    assert.equal(ctx.port, customPort, 'the configured non-default PORT must be honoured exactly');
    assert.equal(ctx.port !== 3000, true, 'the custom PORT must not be the default 3000');
    for (const candidate of HEALTH_PATHS) {
      const response = await getJson(ctx.baseUrl + candidate);
      assert.equal(response.status, 200, candidate + ' must return 200 on the custom port');
      assert.deepEqual(response.body, { status: 'ok' }, candidate + ' body must be {"status":"ok"}');
      assert.match(String(response.headers.get('content-type')), /application\/json/);
    }
  } finally {
    await ctx.close();
  }
});

test('AC-01: /ready returns 200 {"status":"ok"} after DATA_DIR data is loaded on startup', async () => {
  const dataDir = makeDataDir('ac24-ready-load');
  // Seed DATA_DIR with real persisted files so startup performs an actual load.
  const users = createUserRepository({ dataDir });
  const tasks = createTaskRepository({ dataDir });
  assert.equal(users.size ? users.size() : 0, 0);
  assert.equal(typeof tasks.size, 'function');
  fs.writeFileSync(path.join(dataDir, 'tasks.json'), '[]\n');

  const ctx = await startOnCustomPort(dataDir, 42318);
  try {
    const response = await getJson(ctx.baseUrl + '/ready');
    assert.equal(response.status, 200, '/ready must return 200 once DATA_DIR is loaded');
    assert.deepEqual(response.body, { status: 'ok' });
  } finally {
    await ctx.close();
  }
});
