'use strict';

/**
 * Secret store and HMAC token service tests.
 *
 * Covers the slice acceptance criteria:
 *   - without TOKEN_SECRET the first start generates and persists a key under
 *     DATA_DIR; a "restarted" store reuses it and old tokens still verify
 *   - issued tokens are non-empty; a one-character tamper or a truncation fails
 *     verification and neither throws an uncaught exception
 *   - comparison uses crypto.timingSafeEqual and no key material appears in a
 *     token, in describe()/JSON output, or in stdout
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const secretStoreModule = require('../src/auth/secretStore.js');
const {
  SecretStore,
  createSecretStore,
  encodeSecret,
  decodeSecret,
  generateSecret,
  sanitizeSecretFileName,
  resolveDataDir,
  KEY_BYTES,
  PRIVATE_FILE_MODE,
  SECRET_FILE_NAME,
} = secretStoreModule;

const tokenModule = require('../src/auth/token.js');
const {
  issueToken,
  verifyToken,
  isValidToken,
  safeEqualBytes,
  extractBearerToken,
  base64urlEncode,
  base64urlDecode,
  computeSignature,
  TOKEN_FAILURES,
} = tokenModule;

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-auth-' + (name || 'x') + '-'));
}

function flipLastCharacter(value) {
  const last = value[value.length - 1];
  const replacement = last === 'A' ? 'B' : 'A';
  return value.slice(0, -1) + replacement;
}

test('auth secret store: [REDACTED] environment secret is used and never persisted', () => {
  const dataDir = makeDataDir('env');
  const store = createSecretStore({ dataDir, env: { TOKEN_SECRET: 'environment-supplied-key' } });
  assert.equal(store.isFromEnvironment(), true);
  assert.equal(store.describe().source, 'environment');
  assert.equal(store.getKey(), encodeSecret(Buffer.from('environment-supplied-key', 'utf8')));
  assert.equal(fs.existsSync(path.join(dataDir, SECRET_FILE_NAME)), false);
  assert.equal(JSON.stringify(store).includes('environment-supplied-key'), false);
});

test('auth secret store: [REDACTED] a generated key is persisted under DATA_DIR and reused after restart (AC-09/AC-12/AC-13 root cause)', () => {
  const dataDir = makeDataDir('persist');
  const first = createSecretStore({ dataDir, env: {} });
  assert.equal(first.describe().source, 'generated');
  assert.equal(first.describe().persisted, true);
  const secretPath = path.join(dataDir, SECRET_FILE_NAME);
  assert.equal(fs.existsSync(secretPath), true);
  const firstKey = first.getKey();
  assert.equal(firstKey.length > 0, true);
  assert.equal(first.getKeyLength(), KEY_BYTES);

  // Simulate a process restart: a brand new store reads the same DATA_DIR.
  const second = createSecretStore({ dataDir, env: {} });
  assert.equal(second.describe().source, 'file');
  assert.equal(second.getKey(), firstKey);
});

test('auth secret store: [REDACTED] persisted key file uses restricted permissions', () => {
  const dataDir = makeDataDir('perms');
  const store = createSecretStore({ dataDir, env: {} });
  assert.equal(store.getKey().length > 0, true);
  const mode = fs.statSync(path.join(dataDir, SECRET_FILE_NAME)).mode & 0o777;
  assert.equal(mode, PRIVATE_FILE_MODE);
  assert.equal(mode & 0o077, 0);
});

test('auth secret store: [REDACTED] a corrupt key file is backed up, not silently lost', () => {
  const dataDir = makeDataDir('corrupt');
  const secretPath = path.join(dataDir, SECRET_FILE_NAME);
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(secretPath, 'not-valid-base64-key-material', 'utf8');
  const store = createSecretStore({ dataDir, env: {} });
  assert.equal(store.describe().corrupt, true);
  assert.notEqual(store.describe().corruptBackup, null);
  assert.equal(store.getKeyLength(), KEY_BYTES);
  const backups = fs.readdirSync(dataDir).filter((name) => name.includes('.corrupt'));
  assert.equal(backups.length, 1);
});

test('auth secret store: [REDACTED] metadata output never exposes key material', () => {
  const dataDir = makeDataDir('meta');
  const store = createSecretStore({ dataDir, env: {} });
  const raw = store.getKey();
  const described = JSON.stringify(store.describe());
  const serialized = JSON.stringify(store);
  assert.equal(described.includes(raw), false);
  assert.equal(serialized.includes(raw), false);
  assert.equal(typeof store.describe().keyBytes, 'number');
  assert.equal('key' in store.describe(), false);
});

test('auth secret store: [REDACTED] malformed configuration and file names are rejected', () => {
  assert.throws(() => resolveDataDir(''), { name: 'SecretStoreError' });
  assert.throws(() => resolveDataDir('   '), { name: 'SecretStoreError' });
  assert.throws(() => sanitizeSecretFileName('../escape.key'), { name: 'SecretStoreError' });
  assert.throws(() => sanitizeSecretFileName('nested/secret.key'), { name: 'SecretStoreError' });
  assert.throws(() => sanitizeSecretFileName(' padded.key'), { name: 'SecretStoreError' });
  assert.throws(() => new SecretStore({ dataDir: '' }), { name: 'SecretStoreError' });
  assert.equal(decodeSecret('short'), null);
  assert.equal(decodeSecret(''), null);
  assert.equal(decodeSecret(generateSecret().toString('base64')).length, KEY_BYTES);
});

test('auth token: [REDACTED] issue returns a non-empty signed token carrying sub and iat (AC-09)', () => {
  const store = createSecretStore({ dataDir: makeDataDir('issue'), env: {} });
  const issued = issueToken({ subject: 'user-123' }, { secretStore: store });
  assert.equal(issued.ok, true);
  assert.equal(typeof issued.token, 'string');
  assert.equal(issued.token.length > 0, true);
  assert.equal(issued.payload.sub, 'user-123');
  assert.equal(typeof issued.payload.iat, 'number');
  assert.equal(issued.token.split('.').length, 2);
});

test('auth token: [REDACTED] a valid token verifies and yields the identity (AC-09)', () => {
  const store = createSecretStore({ dataDir: makeDataDir('verify'), env: {} });
  const issued = issueToken({ subject: 'alice-id' }, { secretStore: store });
  const result = verifyToken(issued.token, { secretStore: store });
  assert.equal(result.ok, true);
  assert.equal(result.subject, 'alice-id');
  assert.equal(isValidToken(issued.token, { secretStore: store }), true);
});

test('auth token: [REDACTED] any single-character change invalidates the signature (AC-12)', () => {
  const store = createSecretStore({ dataDir: makeDataDir('tamper'), env: {} });
  const issued = issueToken({ subject: 'bob-id' }, { secretStore: store });
  const tampered = flipLastCharacter(issued.token);
  assert.notEqual(tampered, issued.token);
  const result = verifyToken(tampered, { secretStore: store });
  assert.equal(result.ok, false);
  assert.equal(result.code, TOKEN_FAILURES.INVALID_SIGNATURE);
});

test('auth token: [REDACTED] truncation is rejected (AC-13)', () => {
  const store = createSecretStore({ dataDir: makeDataDir('truncate'), env: {} });
  const issued = issueToken({ subject: 'carol-id' }, { secretStore: store });
  const truncated = issued.token.slice(0, issued.token.length - 4);
  const result = verifyToken(truncated, { secretStore: store });
  assert.equal(result.ok, false);
  assert.equal(result.ok === false && result.code.length > 0, true);
  const payloadOnly = issued.token.split('.')[0];
  assert.equal(verifyToken(payloadOnly, { secretStore: store }).ok, false);
  const signatureOnly = issued.token.split('.')[1];
  assert.equal(verifyToken(signatureOnly, { secretStore: store }).ok, false);
});

test('auth token: [REDACTED] missing and malformed tokens fail without throwing', () => {
  const store = createSecretStore({ dataDir: makeDataDir('malformed'), env: {} });
  const bad = [undefined, null, '', 123, {}, [], 'no-delimiter', 'a.b.c', '.', 'a.', '.b', 'x'.repeat(9000)];
  for (const value of bad) {
    const result = verifyToken(value, { secretStore: store });
    assert.equal(result.ok, false);
    assert.equal(typeof result.code, 'string');
  }
  assert.equal(verifyToken('', { secretStore: store }).code, TOKEN_FAILURES.MISSING);
  assert.equal(verifyToken('a.b.c', { secretStore: store }).code, TOKEN_FAILURES.MALFORMED);
});

test('auth token: [REDACTED] a different key cannot verify the token and expiry is enforced', () => {
  const store = createSecretStore({ dataDir: makeDataDir('keys'), env: {} });
  const other = createSecretStore({ dataDir: makeDataDir('keys-other'), env: {} });
  const issued = issueToken({ subject: 'dave-id' }, { secretStore: store });
  assert.equal(verifyToken(issued.token, { secretStore: other }).ok, false);

  const expiring = issueToken({ subject: 'erin-id', exp: 1000 }, { secretStore: store });
  assert.equal(verifyToken(expiring.token, { secretStore: store, now: 500 }).ok, true);
  const expired = verifyToken(expiring.token, { secretStore: store, now: 5000 });
  assert.equal(expired.ok, false);
  assert.equal(expired.code, TOKEN_FAILURES.EXPIRED);
});

test('auth token: [REDACTED] signing key material never appears in a token or a failure result', () => {
  const store = createSecretStore({ dataDir: makeDataDir('leak'), env: {} });
  const issued = issueToken({ subject: 'frank-id' }, { secretStore: store });
  const key = store.getKey();
  assert.equal(issued.token.includes(key), false);
  assert.equal(JSON.stringify(issued).includes(key), false);
  const failed = verifyToken(flipLastCharacter(issued.token), { secretStore: store });
  assert.equal(JSON.stringify(failed).includes(key), false);
  assert.equal(confirmConstantTimeHelper(), true);
});

function confirmConstantTimeHelper() {
  const source = require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'src', 'auth', 'token.js'), 'utf8');
  return source.includes('crypto.timingSafeEqual');
}

test('auth token: [REDACTED] constant-time comparison is used and length mismatch never throws', () => {
  const same = Buffer.from('abcdef');
  assert.equal(safeEqualBytes(same, Buffer.from('abcdef')), true);
  assert.equal(safeEqualBytes(same, Buffer.from('abcdeg')), false);
  assert.equal(safeEqualBytes(same, Buffer.from('much-longer-value')), false);
  assert.equal(base64urlDecode(base64urlEncode('hello')).toString('utf8'), 'hello');
  assert.equal(computeSignature('msg', Buffer.from('key')).length, 32);
});

test('auth token: [REDACTED] bearer header parsing is strict and never throws', () => {
  assert.equal(extractBearerToken('Bearer abc.def'), 'abc.def');
  assert.equal(extractBearerToken('Bearer   abc.def   '), 'abc.def');
  assert.equal(extractBearerToken('bearer abc.def'), null);
  assert.equal(extractBearerToken('Basic abc.def'), null);
  assert.equal(extractBearerToken(''), null);
  assert.equal(extractBearerToken(undefined), null);
  assert.equal(extractBearerToken('Bearer'), null);
});

test('auth token: [REDACTED] an invalid subject or expiry is rejected without throwing', () => {
  const store = createSecretStore({ dataDir: makeDataDir('subject'), env: {} });
  assert.equal(issueToken({ subject: '' }, { secretStore: store }).ok, false);
  assert.equal(issueToken({}, { secretStore: store }).ok, false);
  assert.equal(issueToken({ subject: 'x', exp: 'soon' }, { secretStore: store }).ok, false);
  assert.equal(issueToken({ userId: 'ok-id' }, { secretStore: store }).ok, true);
  const noKey = new SecretStore({
    dataDir: makeDataDir('nokey'),
    env: {},
    autoload: false,
  });
  noKey._key = null;
  noKey.resolve = () => null;
  assert.equal(issueToken({ subject: 'y' }, { secretStore: noKey }).ok, false);
});
