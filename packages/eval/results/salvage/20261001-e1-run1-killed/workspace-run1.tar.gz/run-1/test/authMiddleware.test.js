'use strict';

/**
 * Bearer auth middleware and protected route mount point tests (FR-2-AUTH).
 *
 * These exercise the real HTTP path (a live node:http server), so the response
 * stream behaves exactly as in production.
 *
 * Covers the task acceptance criteria:
 *   - AC-11: no Authorization header on a protected route -> 401 UNAUTHORIZED
 *     with the standard error envelope
 *   - AC-12: a token altered in any single character (including the last one)
 *     -> 401, never a 5xx
 *   - AC-13: a truncated token -> 401
 *   - missing / wrong-case / empty Bearer prefix -> 401 and never a 5xx
 *   - a valid token populates the request context (id + username) and reaches
 *     the downstream handler
 *   - the public paths and health endpoints stay unauthenticated
 *   - an internal middleware fault still answers 401, never 500
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { createSecretStore } = require('../src/auth/secretStore.js');
const { issueToken } = require('../src/auth/token.js');
const { createRouter } = require('../src/http/router.js');
const { sendJson } = require('../src/http/respond.js');
const { createAuthMiddleware, requiresAuth, isPublicPath, isApiPath, PUBLIC_PATHS } = require('../src/http/authMiddleware.js');

const SILENT_LOGGER = { info() {}, warn() {}, error() {}, debug() {}, fatal() {} };
const USER_ID = '11111111-2222-4333-8444-555555555555';
const USERNAME = 'Alice_01';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-authmw-' + (name || 't') + '-'));
}

/** Repository double that resolves exactly one identity by id. */
function stubRepository(record) {
  const stored = record === undefined ? { id: USER_ID, username: USERNAME } : record;
  return {
    findById(id) {
      return stored && stored.id === id ? Object.assign({}, stored) : null;
    },
  };
}

function flipLastCharacter(value) {
  const last = value[value.length - 1];
  return value.slice(0, -1) + (last === 'A' ? 'B' : 'A');
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function request(ctx, options) {
  const opts = options || {};
  const headers = Object.assign({}, opts.headers);
  const response = await fetch(ctx.url + (opts.url || '/api/tasks'), { method: opts.method || 'GET', headers });
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

/** Build an app + live server with a protected /api/tasks route. */
async function startApp(options) {
  const opts = options || {};
  const secretStore = opts.secretStore || createSecretStore({ dataDir: makeDataDir('mw'), env: {} });
  const userRepository = opts.userRepository || stubRepository();
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, secretStore } });
  const seen = [];
  app.addProtectedRoute('GET', '/api/tasks', (ctx) => {
    seen.push({ user: ctx.user, userId: ctx.userId, reqUser: ctx.req && ctx.req.user });
    sendJson(ctx.res, 200, { items: [], user: ctx.user });
  });
  const ctx = await listen(app);
  return { ctx, secretStore, userRepository, seen };
}

test('AC-11 auth middleware: a protected route without an Authorization header returns 401 UNAUTHORIZED', async () => {
  const { ctx, seen } = await startApp();
  try {
    const res = await request(ctx);
    assert.equal(res.status, 401);
    assert.deepEqual(res.body, { error: { code: 'UNAUTHORIZED', message: 'Authentication is required' } });
    assert.equal(seen.length, 0);
    assert.match(String(res.headers.get('content-type')), /application\/json/);
  } finally {
    await ctx.close();
  }
});

test('AC-12 auth middleware: a token altered in any single character returns 401, never a 5xx', async () => {
  const { ctx, secretStore, seen } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    assert.equal(issued.ok, true);

    const lastChar = await request(ctx, { headers: { authorization: 'Bearer ' + flipLastCharacter(issued.token) } });
    assert.equal(lastChar.status, 401);
    assert.equal(lastChar.body.error.code, 'UNAUTHORIZED');

    const index = Math.floor(issued.token.length / 2);
    const flipped = issued.token.slice(0, index) + (issued.token[index] === 'a' ? 'b' : 'a') + issued.token.slice(index + 1);
    const midChar = await request(ctx, { headers: { authorization: 'Bearer ' + flipped } });
    assert.equal(midChar.status, 401);
    assert.equal(midChar.body.error.code, 'UNAUTHORIZED');
    assert.equal(seen.length, 0);
  } finally {
    await ctx.close();
  }
});

test('AC-13 auth middleware: a truncated token returns 401', async () => {
  const { ctx, secretStore, seen } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const truncated = issued.token.slice(0, issued.token.length - 6);
    const res = await request(ctx, { headers: { authorization: 'Bearer ' + truncated } });
    assert.equal(res.status, 401);
    assert.equal(res.body.error.code, 'UNAUTHORIZED');
    assert.equal(seen.length, 0);
  } finally {
    await ctx.close();
  }
});

test('auth middleware: missing, wrong-case, empty and malformed Bearer prefixes return 401 and never 5xx', async () => {
  const { ctx, secretStore } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const headerValues = [
      undefined,
      'bearer ' + issued.token,
      'BEARER ' + issued.token,
      'Bearer',
      'Bearer ',
      'Bearer    ',
      'Basic ' + issued.token,
      'Token ' + issued.token,
      '',
      'Bearer a.b.c',
      'Bearer not-a-token',
    ];
    for (const value of headerValues) {
      const headers = value === undefined ? {} : { authorization: value };
      const res = await request(ctx, { headers });
      assert.equal(res.status < 500, true, 'must never be a 5xx for ' + JSON.stringify(value));
      assert.equal(res.status, 401, 'must be 401 for ' + JSON.stringify(value));
      assert.equal(res.body.error.code, 'UNAUTHORIZED');
    }
  } finally {
    await ctx.close();
  }
});

test('auth middleware: a valid token resolves the identity and reaches the downstream handler', async () => {
  const { ctx, secretStore, seen } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const res = await request(ctx, { headers: { authorization: 'Bearer ' + issued.token } });
    assert.equal(res.status, 200);
    assert.equal(seen.length, 1);
    assert.deepEqual(seen[0].user, { id: USER_ID, username: USERNAME });
    assert.equal(seen[0].userId, USER_ID);
    assert.equal(seen[0].reqUser.id, USER_ID);
    assert.deepEqual(res.body.user, { id: USER_ID, username: USERNAME });
  } finally {
    await ctx.close();
  }
});

test('auth middleware: a valid token whose subject no longer exists is rejected with 401', async () => {
  const secretStore = createSecretStore({ dataDir: makeDataDir('gone'), env: {} });
  const { ctx } = await startApp({ secretStore, userRepository: stubRepository(null) });
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const res = await request(ctx, { headers: { authorization: 'Bearer ' + issued.token } });
    assert.equal(res.status, 401);
    assert.equal(res.body.error.code, 'UNAUTHORIZED');
  } finally {
    await ctx.close();
  }
});

test('auth middleware: an internal repository fault still answers 401, never a 5xx', async () => {
  const secretStore = createSecretStore({ dataDir: makeDataDir('boom'), env: {} });
  const exploding = {
    findById() {
      throw new Error('repository exploded');
    },
  };
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository: exploding, secretStore } });
  app.addProtectedRoute('GET', '/api/tasks', () => {
    throw new Error('handler must not run');
  });
  const ctx = await listen(app);
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const res = await request(ctx, { headers: { authorization: 'Bearer ' + issued.token } });
    assert.equal(res.status, 401);
    assert.equal(res.body.error.code, 'UNAUTHORIZED');
    assert.equal(res.text.includes('exploded'), false);
  } finally {
    await ctx.close();
  }
});

test('auth middleware: public paths and health endpoints stay unauthenticated', async () => {
  for (const publicPath of PUBLIC_PATHS) {
    assert.equal(isPublicPath(publicPath), true, publicPath + ' must be public');
    assert.equal(requiresAuth(publicPath), false);
  }
  const { ctx } = await startApp();
  try {
    for (const publicPath of ['/healthz', '/health', '/ready']) {
      const res = await request(ctx, { url: publicPath });
      assert.equal(res.status, 200);
      assert.deepEqual(res.body, { status: 'ok' });
    }
  } finally {
    await ctx.close();
  }
});

test('auth middleware: the /api surface is guarded by default so future task routes are covered', () => {
  assert.equal(isApiPath('/api/tasks'), true);
  assert.equal(isApiPath('/api/tasks/abc'), true);
  assert.equal(isApiPath('/api'), true);
  assert.equal(requiresAuth('/api/tasks'), true);
  assert.equal(requiresAuth('/api/tasks/abc-123'), true);
  assert.equal(requiresAuth('/api/whatever'), true);
  assert.equal(requiresAuth('/public-ish', { auth: false }), false);
  assert.equal(requiresAuth('/anything', { auth: true }), true);
});

test('auth middleware: the protected mount point also works through a mounted sub-router', async () => {
  const secretStore = createSecretStore({ dataDir: makeDataDir('mount'), env: {} });
  const userRepository = stubRepository();
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, secretStore } });
  const tasks = createRouter();
  tasks.addProtected('GET', '/', (ctx) => {
    sendJson(ctx.res, 200, { items: [], user: ctx.user });
  });
  app.mount('/api/tasks', tasks);
  const ctx = await listen(app);
  try {
    const anonymous = await request(ctx, { url: '/api/tasks' });
    assert.equal(anonymous.status, 401);
    assert.equal(anonymous.body.error.code, 'UNAUTHORIZED');

    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const authorized = await request(ctx, { url: '/api/tasks', headers: { authorization: 'Bearer ' + issued.token } });
    assert.equal(authorized.status, 200);
    assert.deepEqual(authorized.body.user, { id: USER_ID, username: USERNAME });
  } finally {
    await ctx.close();
  }
});

test('auth middleware: an unmatched non-API path stays a 404 NOT_FOUND (no behaviour change)', async () => {
  const { ctx } = await startApp();
  try {
    const res = await request(ctx, { url: '/definitely/missing' });
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
  } finally {
    await ctx.close();
  }
});

test('auth middleware: a directly invoked middleware writes the 401 envelope and a challenge', async () => {
  const middleware = createAuthMiddleware();
  const writes = { status: 0, headers: {}, body: null };
  const res = {
    writableEnded: false,
    headersSent: false,
    setHeader(name, value) {
      writes.headers[String(name).toLowerCase()] = value;
    },
    writeHead(status) {
      writes.status = status;
      this.headersSent = true;
      return this;
    },
    end(payload) {
      writes.body = payload === undefined ? null : String(payload);
      this.writableEnded = true;
    },
    destroy() {
      this.writableEnded = true;
    },
  };
  await middleware({ req: { headers: {} }, res, method: 'GET', pathname: '/api/tasks' });
  assert.equal(writes.status, 401);
  assert.equal(writes.headers['www-authenticate'], 'Bearer');
  assert.deepEqual(JSON.parse(writes.body).error.code, 'UNAUTHORIZED');
});
