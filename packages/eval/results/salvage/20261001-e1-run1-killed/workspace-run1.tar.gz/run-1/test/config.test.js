'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const configModule = require('../src/config.js');
const { loadConfig, describeConfig, getConfig, resetConfigCache, DEFAULT_PORT, DEFAULT_DATA_DIR, ConfigError } = configModule;

const PRD_SECRET = 'unit-secret-should-never-be-logged';

function tmpRoot(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-config-' + name + '-'));
}

function envWith(overrides) {
  return Object.assign({}, overrides);
}

test('config: PORT defaults to 3000 when unset', () => {
  const root = tmpRoot('portdefault');
  const config = loadConfig(envWith({ DATA_DIR: path.join(root, 'data') }));
  assert.equal(config.port, DEFAULT_PORT);
  assert.equal(config.port, 3000);
});

test('config: PORT set by the environment is honoured', () => {
  const root = tmpRoot('portset');
  const config = loadConfig(envWith({ PORT: '4123', DATA_DIR: path.join(root, 'data') }));
  assert.equal(config.port, 4123);
});

test('config: PORT=0 is accepted for ephemeral ports', () => {
  const root = tmpRoot('portzero');
  const config = loadConfig(envWith({ PORT: '0', DATA_DIR: path.join(root, 'data') }));
  assert.equal(config.port, 0);
});

test('config: DATA_DIR defaults to ./data and is created recursively', () => {
  const root = tmpRoot('datadir');
  const config = loadConfig(envWith({ DATA_DIR: path.join(root, 'nested', 'deeper', 'data') }));
  assert.equal(config.dataDirSetting, path.join(root, 'nested', 'deeper', 'data'));
  assert.ok(fs.existsSync(config.dataDir));
  assert.ok(fs.statSync(config.dataDir).isDirectory());
});

test('config: a missing DATA_DIR path is created recursively without crashing', () => {
  const root = tmpRoot('missing');
  const target = path.join(root, 'a', 'b', 'c', 'data');
  assert.equal(fs.existsSync(target), false);
  const config = loadConfig(envWith({ DATA_DIR: target }));
  assert.equal(fs.existsSync(config.dataDir), true);
  assert.equal(fs.statSync(config.dataDir).isDirectory(), true);
});

test('config: TOKEN_SECRET is optional and hidden from serialisation', () => {
  const root = tmpRoot('secret');
  const withSecret = loadConfig(envWith({ DATA_DIR: path.join(root, 'data'), TOKEN_SECRET: PRD_SECRET }));
  assert.equal(withSecret.hasTokenSecret, true);
  assert.equal(withSecret.tokenSecret, PRD_SECRET);
  assert.equal(JSON.stringify(withSecret).includes(PRD_SECRET), false);
  assert.equal(JSON.stringify(describeConfig(withSecret)).includes(PRD_SECRET), false);

  const without = loadConfig(envWith({ DATA_DIR: path.join(root, 'plain') }));
  assert.equal(without.tokenSecret, null);
  assert.equal(without.hasTokenSecret, false);
});

test('config: describeConfig never contains the signing key', () => {
  const root = tmpRoot('describe');
  const config = loadConfig(envWith({ DATA_DIR: path.join(root, 'data'), TOKEN_SECRET: PRD_SECRET }));
  const described = describeConfig(config);
  assert.equal(described.hasTokenSecret, true);
  assert.equal(described.tokenSecretSource, 'environment');
  assert.equal('tokenSecret' in described, false);
  assert.equal(JSON.stringify(described).includes(PRD_SECRET), false);
});

test('config: invalid PORT falls back to the default 3000', () => {
  const root = tmpRoot('badport');
  const dataDir = path.join(root, 'data');
  assert.equal(loadConfig(envWith({ PORT: 'abc', DATA_DIR: dataDir })).port, 3000);
  assert.equal(loadConfig(envWith({ PORT: '70000', DATA_DIR: dataDir })).port, 3000);
  assert.equal(loadConfig(envWith({ PORT: '-1', DATA_DIR: dataDir })).port, 3000);
  assert.equal(loadConfig(envWith({ PORT: '3.5', DATA_DIR: dataDir })).port, 3000);
  assert.equal(loadConfig(envWith({ PORT: '   ', DATA_DIR: dataDir })).port, 3000);
});

test('config: DATA_DIR defaults to ./data locally and /data in a container', () => {
  const local = loadConfig(envWith({ TASKKBOARD_CONTAINER: '0' }));
  assert.equal(local.dataDirSetting, './data');
  assert.equal(local.dataDir, path.resolve('./data'));

  const container = loadConfig(envWith({ TASKKBOARD_CONTAINER: '1' }));
  assert.equal(container.dataDirSetting, '/data');
  assert.equal(container.dataDir, path.resolve('/data'));
});

test('config: DATA_DIR is created and write-probe verified', () => {
  const root = tmpRoot('writable');
  const target = path.join(root, 'nested', 'data');
  const config = loadConfig(envWith({ DATA_DIR: target }));
  assert.equal(fs.existsSync(config.dataDir), true);
  const probe = path.join(config.dataDir, 'probe.txt');
  fs.writeFileSync(probe, 'ok');
  assert.equal(fs.readFileSync(probe, 'utf8'), 'ok');
  fs.unlinkSync(probe);
});

test('config: the config object is frozen after load', () => {
  const root = tmpRoot('frozen');
  const config = loadConfig(envWith({ DATA_DIR: path.join(root, 'data') }));
  assert.equal(Object.isFrozen(config), true);
  assert.throws(() => {
    config.port = 1;
  }, TypeError);
});

test('config: getConfig reads the environment once and memoises the result', () => {
  const root = tmpRoot('once');
  resetConfigCache();
  const previousPort = process.env.PORT;
  const previousDir = process.env.DATA_DIR;
  process.env.PORT = '4321';
  process.env.DATA_DIR = path.join(root, 'data');
  try {
    const first = getConfig();
    process.env.PORT = '5555';
    process.env.DATA_DIR = path.join(root, 'other');
    const second = getConfig();
    assert.equal(first, second);
    assert.equal(second.port, 4321);
  } finally {
    if (previousPort === undefined) {
      delete process.env.PORT;
    } else {
      process.env.PORT = previousPort;
    }
    if (previousDir === undefined) {
      delete process.env.DATA_DIR;
    } else {
      process.env.DATA_DIR = previousDir;
    }
    resetConfigCache();
  }
});

test('config: defaults are exported for other modules', () => {
  assert.equal(DEFAULT_PORT, 3000);
  assert.equal(DEFAULT_DATA_DIR, './data');
});
