'use strict';

/**
 * Runtime configuration contract tests (FR-8.2 / FR-8.3, TS-02 / TS-03).
 *
 * Verifies the observable behaviour of the running service, not just the parser:
 *   - FR-8.2 PORT: with a custom PORT the process listens on exactly that port and
 *     answers HTTP there; with PORT unset the process listens on the default 3000.
 *   - FR-8.3 DATA_DIR: with DATA_DIR unset the resolved default is '/data' in a
 *     container and './data' locally, the directory is created and is writable,
 *     and every storage file path is derived from DATA_DIR (never hardcoded).
 *
 * All processes use isolated temporary directories and are shut down at the end
 * of each test so the file is safe to run under `node --test`.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { loadConfig, DEFAULT_PORT, DEFAULT_DATA_DIR, CONTAINER_DATA_DIR } = require('../src/config.js');
const { startServer } = require('../src/server.js');
const { createLogger } = require('../src/logger.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { createJsonStore } = require('../src/store/jsonStore.js');

const SILENT = createLogger({ stream: { write() {} } });
const USERS_FILE = 'users.json';
const TASKS_FILE = 'tasks.json';

/** Isolated temporary directory for one test. */
function tmpDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-configcontract-' + name + '-'));
}

/** Ask the OS for a currently free TCP port (bind :0, read it, release it). */
function freePort() {
  return new Promise((resolve, reject) => {
    const probe = http.createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const { port } = probe.address();
      probe.close(() => resolve(port));
    });
  });
}

async function getJson(url) {
  const response = await fetch(url, { headers: { accept: 'application/json' } });
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

/** Start the real service from an explicit environment and return a closer. */
async function startWithEnv(env) {
  const config = loadConfig(env);
  const started = await startServer({ config, logger: SILENT });
  const address = started.server.address();
  return {
    config,
    server: started.server,
    address,
    close() {
      return new Promise((resolve) => {
        started.server.close(() => resolve());
        started.server.closeAllConnections();
      });
    },
  };
}

test('AC-24 FR-8.2 PORT: a custom PORT is honoured and the service is reachable on that port', async () => {
  const dataDir = tmpDir('custom-port');
  const customPort = await freePort();
  assert.equal(customPort !== DEFAULT_PORT, true, 'the free port must differ from the default 3000');

  const ctx = await startWithEnv({ PORT: String(customPort), DATA_DIR: dataDir });
  try {
    assert.equal(ctx.address.port, customPort, 'the process must listen on the configured PORT');
    assert.equal(ctx.address.address, '0.0.0.0', 'the process must bind 0.0.0.0 so port mapping works');

    const response = await getJson('http://127.0.0.1:' + customPort + '/healthz');
    assert.equal(response.status, 200, 'the service must answer on the custom PORT');
    assert.deepEqual(response.body, { status: 'ok' });
  } finally {
    await ctx.close();
  }
});

test('AC-24 FR-8.2 PORT: an unset PORT listens on the default 3000', async () => {
  const dataDir = tmpDir('default-port');
  assert.equal(DEFAULT_PORT, 3000);
  // No PORT key at all in the supplied environment.
  const ctx = await startWithEnv({ DATA_DIR: dataDir });
  try {
    assert.equal(ctx.config.port, 3000, 'resolved port must default to 3000 when PORT is unset');
    assert.equal(ctx.address.port, 3000, 'the process must actually listen on port 3000');
    const response = await getJson('http://127.0.0.1:3000/healthz');
    assert.equal(response.status, 200, 'the service must answer on the default port 3000');
  } finally {
    await ctx.close();
  }
});

test('AC-25 FR-8.3 DATA_DIR: unset DATA_DIR resolves to the container/local defaults and is writable', () => {
  assert.equal(DEFAULT_DATA_DIR, './data');
  assert.equal(CONTAINER_DATA_DIR, '/data');

  const local = loadConfig({ TASKKBOARD_CONTAINER: '0' });
  assert.equal(local.dataDirSetting, './data', 'local default must be ./data');
  assert.equal(local.dataDir, path.resolve('./data'));
  assert.equal(fs.existsSync(local.dataDir), true, 'the local default directory must be created');
  assert.equal(fs.statSync(local.dataDir).isDirectory(), true);

  const container = loadConfig({ TASKKBOARD_CONTAINER: '1' });
  assert.equal(container.dataDirSetting, '/data', 'container default must be /data');
  assert.equal(container.dataDir, path.resolve('/data'));
  assert.equal(fs.existsSync(container.dataDir), true, 'the container default directory must be created');
  assert.equal(fs.statSync(container.dataDir).isDirectory(), true);

  for (const dir of [local.dataDir, container.dataDir]) {
    const probe = path.join(dir, '.config-contract-probe-' + process.pid);
    fs.writeFileSync(probe, 'ok');
    assert.equal(fs.readFileSync(probe, 'utf8'), 'ok', dir + ' must be writable');
    fs.unlinkSync(probe);
  }
});

test('AC-25 FR-8.3 DATA_DIR: storage file paths are derived from DATA_DIR, never hardcoded', async () => {
  const root = tmpDir('derived-paths');
  const custom = path.join(root, 'custom-data');
  const resolvedCustom = path.resolve(custom);
  const resolvedLocalDefault = path.resolve(DEFAULT_DATA_DIR);

  const config = loadConfig({ DATA_DIR: custom, PORT: '0' });
  assert.equal(config.dataDir, resolvedCustom);

  const users = createUserRepository({ dataDir: custom });
  const tasks = createTaskRepository({ dataDir: custom });
  const raw = createJsonStore({ dataDir: custom, fileName: USERS_FILE, createEmpty: () => [] });

  assert.equal(raw.filePath, path.join(resolvedCustom, USERS_FILE));
  assert.equal(users.store.filePath, path.join(resolvedCustom, USERS_FILE));
  assert.equal(tasks.store.filePath, path.join(resolvedCustom, TASKS_FILE));
  for (const filePath of [users.store.filePath, tasks.store.filePath]) {
    assert.equal(filePath.startsWith(resolvedCustom + path.sep), true, filePath + ' must live under DATA_DIR');
    assert.equal(
      filePath.startsWith(resolvedLocalDefault + path.sep),
      false,
      filePath + ' must not fall back to ./data'
    );
  }

  // Two different DATA_DIR values must yield two different derived paths.
  const other = createUserRepository({ dataDir: path.join(root, 'other-data') });
  assert.notEqual(other.store.filePath, users.store.filePath);

  // End to end: the running service persists its user file under the custom
  // DATA_DIR because the repositories are built from config.dataDir.
  const ctx = await startWithEnv({ DATA_DIR: custom, PORT: '0', TOKEN_SECRET: 'config-contract-signing-key' });
  try {
    const created = await fetch('http://127.0.0.1:' + ctx.address.port + '/api/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'derived_path_user', password: 'S3cret_password!' }),
    });
    assert.equal(created.status, 201);
    const persisted = path.join(resolvedCustom, USERS_FILE);
    assert.equal(fs.existsSync(persisted), true, 'the user file must be written under the custom DATA_DIR');
    assert.equal(fs.readFileSync(persisted, 'utf8').includes('S3cret_password!'), false);
  } finally {
    await ctx.close();
  }
});
