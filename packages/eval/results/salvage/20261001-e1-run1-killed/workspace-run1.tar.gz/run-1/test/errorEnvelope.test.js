'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  CODES,
  API_ERROR_CODES,
  AppError,
  toErrorEnvelope,
  buildErrorBody,
  isErrorCode,
  safeMessage,
} = require('../src/errors/errorEnvelope.js');

test('errorEnvelope: the PRD code set is complete and mapped to the right statuses', () => {
  const expected = {
    VALIDATION_ERROR: 400,
    TITLE_INVALID: 400,
    DATE_INVALID: 400,
    UNKNOWN_FIELD: 400,
    UNAUTHORIZED: 401,
    INVALID_CREDENTIALS: 401,
    USERNAME_TAKEN: 409,
    NOT_FOUND: 404,
  };
  assert.deepEqual(API_ERROR_CODES.slice().sort(), Object.keys(expected).sort());
  for (const [code, status] of Object.entries(expected)) {
    assert.equal(CODES[code].status, status, code);
    assert.equal(isErrorCode(code), true);
  }
  assert.equal(CODES.INTERNAL_ERROR.status, 500);
});

test('errorEnvelope: the envelope shape is always { error: { code, message } }', () => {
  const body = buildErrorBody('VALIDATION_ERROR', 'bad input');
  assert.deepEqual(Object.keys(body), ['error']);
  assert.deepEqual(Object.keys(body.error), ['code', 'message']);
  assert.equal(body.error.code, 'VALIDATION_ERROR');
  assert.equal(body.error.message, 'bad input');

  const fromError = new AppError('NOT_FOUND').toEnvelope();
  assert.equal(fromError.error.code, 'NOT_FOUND');
  assert.equal(typeof fromError.error.message, 'string');
});

test('errorEnvelope: AppError carries the status implied by its code', () => {
  assert.equal(new AppError('UNAUTHORIZED').status, 401);
  assert.equal(new AppError('USERNAME_TAKEN').status, 409);
  assert.equal(new AppError('UNKNOWN_FIELD').status, 400);
  assert.equal(new AppError('NOT_FOUND').status, 404);
  assert.equal(AppError.isAppError(new AppError('NOT_FOUND')), true);
  assert.equal(AppError.isAppError(new Error('plain')), false);
});

test('errorEnvelope: unexpected errors collapse to the fixed 500 envelope', () => {
  const thrown = new Error('internal detail with password=hunter2');
  thrown.code = 'E_SOMETHING_WEIRD';
  const mapped = toErrorEnvelope(thrown);
  assert.equal(mapped.status, 500);
  assert.deepEqual(mapped.body, { error: { code: 'INTERNAL_ERROR', message: 'Internal server error' } });
  assert.equal(JSON.stringify(mapped.body).includes('hunter2'), false);
  assert.equal(JSON.stringify(mapped.body).includes('stack'), false);
});

test('errorEnvelope: null/undefined/non-Error throws are handled safely', () => {
  for (const value of [null, undefined, 42, 'a string', Symbol('x')]) {
    const mapped = toErrorEnvelope(value);
    assert.equal(mapped.status === 500 || mapped.status === 400 || mapped.status === 401, true);
    assert.equal(typeof mapped.body.error.code, 'string');
  }
  assert.equal(toErrorEnvelope(null).status, 500);
  assert.equal(toErrorEnvelope(undefined).status, 500);
});

test('errorEnvelope: messages are sanitised so HTML/control characters cannot echo', () => {
  const body = buildErrorBody('VALIDATION_ERROR', '<script>alert(1)</script>');
  assert.equal(body.error.message, CODES.VALIDATION_ERROR.message);
  const control = buildErrorBody('VALIDATION_ERROR', 'bad\nvalue');
  assert.equal(control.error.message, CODES.VALIDATION_ERROR.message);
  const long = buildErrorBody('VALIDATION_ERROR', 'x'.repeat(500));
  assert.equal(long.error.message, CODES.VALIDATION_ERROR.message);
  assert.equal(safeMessage('VALIDATION_ERROR', 'plain text is fine'), 'plain text is fine');
});

test('errorEnvelope: unknown codes never reach a client response', () => {
  const body = buildErrorBody('TOTALLY_UNKNOWN', 'nope');
  assert.equal(body.error.code, 'INTERNAL_ERROR');
  const appError = new AppError('ALSO_UNKNOWN');
  assert.equal(appError.code, 'INTERNAL_ERROR');
  assert.equal(appError.status, 500);
});
