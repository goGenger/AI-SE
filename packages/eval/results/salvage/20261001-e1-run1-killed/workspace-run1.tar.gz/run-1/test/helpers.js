'use strict';

/** Shared test helpers: temp data dir, silent-but-captured logger, live server. */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { loadConfig } = require('../src/config.js');
const { createLogger } = require('../src/logger.js');
const { startServer } = require('../src/server.js');

/** Create an isolated, empty data directory for one test. */
function makeDataDir(name) {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-' + (name || 'test') + '-'));
  return base;
}

/** In-memory log sink so tests can assert what was written to stdout. */
function makeLogSink() {
  const lines = [];
  return {
    lines,
    stream: {
      write(chunk) {
        lines.push(String(chunk).replace(/\n$/, ''));
        return true;
      },
    },
    text() {
      return lines.join('\n');
    },
  };
}

/**
 * Start a real HTTP server on an ephemeral port with an isolated DATA_DIR.
 * Returns { server, url, log, config, close }.
 */
async function startTestServer(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const dataDir = opts.dataDir || makeDataDir('server');
  const config = opts.config || loadConfig({ PORT: '0', DATA_DIR: dataDir, TOKEN_SECRET: 'test-signing-key' });
  const log = makeLogSink();
  const logger = createLogger({ stream: log.stream, level: opts.level || 'debug' });
  const started = await startServer({
    config,
    logger,
    appOptions: opts.appOptions || {},
    services: opts.services || {},
    host: '127.0.0.1',
  });
  return {
    server: started.server,
    app: started.app,
    url: started.url,
    config,
    dataDir,
    log,
    logger,
    close() {
      return new Promise((resolve) => {
        started.server.close(() => resolve());
        started.server.closeAllConnections();
      });
    },
  };
}

async function getJson(url) {
  const response = await fetch(url, { headers: { accept: 'application/json' } });
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

/** Lightweight fake response object for unit-testing handlers directly. */
function makeFakeResponse() {
  const state = { status: 0, headers: {}, body: '', ended: false, headersSent: false, writableEnded: false };
  return {
    state,
    setHeader(name, value) {
      state.headers[String(name).toLowerCase()] = value;
    },
    getHeader(name) {
      return state.headers[String(name).toLowerCase()];
    },
    writeHead(status) {
      state.status = status;
      state.headersSent = true;
      return state;
    },
    end(payload) {
      state.body = payload === undefined ? '' : String(payload);
      state.ended = true;
      state.writableEnded = true;
    },
    destroy() {
      state.ended = true;
      state.writableEnded = true;
    },
    on() {
      return this;
    },
    removeListener() {
      return this;
    },
    once() {
      return this;
    },
  };
}

/** Fake node:http request object feeding a JSON body (or raw text). */
function makeFakeRequest(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const payload = opts.body === undefined ? '' : opts.body;
  const listeners = new Map();
  const readable = {
    url: opts.url || '/',
    method: opts.method || 'GET',
    headers: opts.headers || {},
    on(event, handler) {
      if (!listeners.has(event)) {
        listeners.set(event, []);
      }
      listeners.get(event).push(handler);
      return readable;
    },
    removeListener(event, handler) {
      const list = listeners.get(event) || [];
      listeners.set(
        event,
        list.filter((entry) => entry !== handler)
      );
      return readable;
    },
    resume() {
      return readable;
    },
    emit(event, arg) {
      for (const handler of listeners.get(event) || []) {
        handler(arg);
      }
      return true;
    },
  };
  process.nextTick(() => {
    if (payload.length > 0) {
      readable.emit('data', Buffer.from(payload, 'utf8'));
    }
    readable.emit('end');
  });
  return readable;
}

module.exports = {
  makeDataDir,
  makeLogSink,
  startTestServer,
  getJson,
  makeFakeResponse,
  makeFakeRequest,
};
