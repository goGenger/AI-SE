'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { createLogger, redactString, sanitize, describeError, logger } = require('../src/logger.js');
const { makeLogSink } = require('./helpers.js');

const PLAIN_PASSWORD = 'Sup3r-Secret-Password';
const SCRYPT_HASH = 'a1b2c3d4e5f60718293a4b5c6d7e8f9012345678abcdef01';
const SIGNING_KEY = 'hmac-signing-key-material-should-never-appear';

test('logger: writes to stdout by default and never opens a file', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream });
  log.info('hello');
  assert.equal(sink.lines.length, 1);
  const record = JSON.parse(sink.lines[0]);
  assert.equal(record.level, 'info');
  assert.equal(record.msg, 'hello');
  assert.equal(typeof record.ts, 'string');
  assert.equal(log.stream, sink.stream);
});

test('logger: plaintext passwords are redacted from fields', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'debug' });
  log.info('register', { username: 'alice', password: PLAIN_PASSWORD, passwordHash: SCRYPT_HASH });
  assert.equal(sink.text().includes(PLAIN_PASSWORD), false);
  assert.equal(sink.text().includes(SCRYPT_HASH), false);
  assert.equal(sink.text().includes('[REDACTED]'), true);
  const record = JSON.parse(sink.lines[0]);
  assert.equal(record.fields.username, 'alice');
  assert.equal(record.fields.password, '[REDACTED]');
  assert.equal(record.fields.passwordHash, '[REDACTED]');
});

test('logger: signing keys, tokens and hashes are redacted everywhere', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'debug' });
  log.warn('auth', {
    tokenSecret: SIGNING_KEY,
    authorization: 'Bearer abcdefghijklmnopqrstuvwxyz0123456789',
    digest: SCRYPT_HASH,
    salt: 'cafe'.repeat(8),
  });
  const text = sink.text();
  assert.equal(text.includes(SIGNING_KEY), false);
  assert.equal(text.includes('abcdefghijklmnopqrstuvwxyz0123456789'), false);
  assert.equal(text.includes(SCRYPT_HASH), false);
});

test('logger: credential patterns inside free-form messages are scrubbed', () => {
  assert.equal(redactString('password=' + PLAIN_PASSWORD).includes(PLAIN_PASSWORD), false);
  assert.equal(redactString('token: ' + SIGNING_KEY).includes(SIGNING_KEY), false);
  assert.equal(redactString('Authorization: Bearer ' + SIGNING_KEY).includes(SIGNING_KEY), false);
  assert.equal(redactString('GET /healthz').includes('/healthz'), true);
  assert.equal(redactString('GET /?q=SELECT+1').includes('SELECT'), true);
});

test('logger: nested login payloads are redacted recursively', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'debug' });
  log.info('login', { request: { body: { username: 'bob', password: PLAIN_PASSWORD } } });
  assert.equal(sink.text().includes(PLAIN_PASSWORD), false);
  assert.equal(sink.text().includes('bob'), true);
});

test('logger: error objects log name/message but the message is scrubbed', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'debug' });
  const error = new Error('login failed for password=' + PLAIN_PASSWORD);
  error.code = 'INVALID_CREDENTIALS';
  log.error('boom', error);
  const text = sink.text();
  assert.equal(text.includes(PLAIN_PASSWORD), false);
  assert.equal(text.includes('INVALID_CREDENTIALS'), true);
  assert.equal(text.includes('login failed'), true);
});

test('logger: cycles and deep structures never throw', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'debug' });
  const cyclic = { name: 'root' };
  cyclic.self = cyclic;
  assert.doesNotThrow(() => log.info('cycle', cyclic));
  const nested = { a: { b: { c: { d: { e: { f: 'deep' } } } } } };
  assert.doesNotThrow(() => log.info('deep', nested));
  assert.equal(sink.text().includes('root'), true);
});

test('logger: level filtering suppresses lower levels', () => {
  const sink = makeLogSink();
  const log = createLogger({ stream: sink.stream, level: 'warn' });
  log.debug('debug-msg');
  log.info('info-msg');
  log.warn('warn-msg');
  assert.equal(sink.text().includes('debug-msg'), false);
  assert.equal(sink.text().includes('info-msg'), false);
  assert.equal(sink.text().includes('warn-msg'), true);
  assert.equal(sink.lines.length, 1);
});

test('logger: a closed stdout never crashes the process', () => {
  const failing = {
    write() {
      const error = new Error('EPIPE');
      error.code = 'EPIPE';
      throw error;
    },
  };
  const log = createLogger({ stream: failing });
  assert.doesNotThrow(() => log.info('after close'));
});

test('logger: sanitize returns primitives untouched and hides sensitive keys', () => {
  assert.equal(sanitize(1), 1);
  assert.equal(sanitize(true), true);
  assert.equal(sanitize(null), null);
  const safe = sanitize({ password: PLAIN_PASSWORD, visible: 'ok' });
  assert.equal(safe.password, '[REDACTED]');
  assert.equal(safe.visible, 'ok');
  const described = describeError(new Error('plain failure'));
  assert.equal(described.name, 'Error');
  assert.equal(described.message, 'plain failure');
  assert.equal(typeof logger.info, 'function');
});
