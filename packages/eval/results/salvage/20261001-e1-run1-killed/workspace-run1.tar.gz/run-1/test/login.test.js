'use strict';

/**
 * POST /api/login handler tests (FR-2).
 *
 * Covers the task acceptance criteria:
 *   - correct credentials -> 200, non-empty token shaped payload.signature,
 *     user contains at least id and username
 *   - wrong password -> 401 INVALID_CREDENTIALS
 *   - unknown username -> 401 INVALID_CREDENTIALS with the SAME status and body
 *     as the wrong-password case (no user-existence disclosure)
 *   - a body field other than username/password -> 400 UNKNOWN_FIELD
 *   - malformed JSON / missing fields -> 400 VALIDATION_ERROR
 *   - case-insensitive username lookup succeeds (Alice registered, alice logs in)
 *   - after a simulated process restart the same credentials still work because
 *     the user data and the signing key persist under DATA_DIR
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { registerRoutes, REGISTER_PATH } = require('../src/http/registerHandler.js');
const { loginRoutes, LOGIN_PATH } = require('../src/http/loginHandler.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { createSecretStore, SECRET_FILE_NAME } = require('../src/auth/secretStore.js');
const { hashPassword } = require('../src/auth/password.js');
const { verifyToken } = require('../src/auth/token.js');

const FAST_PARAMS = Object.freeze({ N: 1024, r: 8, p: 1, keylen: 32 });
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const PLAINTEXT = 'S3cret_password!';
const WRONG = 'Wrong_password_9';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-login-' + (name || 'test') + '-'));
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        server,
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function postJson(baseUrl, routePath, body, raw) {
  const payload = raw === undefined ? JSON.stringify(body) : raw;
  const response = await fetch(baseUrl + routePath, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: payload,
  });
  const text = await response.text();
  let parsed = null;
  try {
    parsed = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    parsed = text;
  }
  return { status: response.status, body: parsed, text };
}

/** Build a live app with slow scrypt swapped for fast test parameters. */
async function startAuthServer(dataDir) {
  const userRepository = createUserRepository({ dataDir });
  const secretStore = createSecretStore({ dataDir, env: {} });
  const app = createApp({
    logger: { info() {}, warn() {}, error() {}, debug() {}, fatal() {} },
    services: { userRepository, secretStore },
  });
  const hasher = {
    hash: (pwd) => hashPassword(pwd, { params: FAST_PARAMS }),
    verify: async (pwd, credential) => {
      const { verifyPassword } = require('../src/auth/password.js');
      return verifyPassword(pwd, credential);
    },
  };
  registerRoutes(app, { hasher });
  loginRoutes(app, { hasher });
  const ctx = await listen(app);
  return { ctx, userRepository, secretStore, hasher };
}

async function register(ctx, username, password) {
  return postJson(ctx.url, REGISTER_PATH, { username, password: password || PLAINTEXT });
}

async function login(ctx, username, password) {
  return postJson(ctx.url, LOGIN_PATH, { username, password: password || PLAINTEXT });
}

test('AC-09 login: correct credentials return 200 with a signed token and the user id/username', async () => {
  const dataDir = makeDataDir('ok');
  const { ctx } = await startAuthServer(dataDir);
  try {
    assert.equal((await register(ctx, 'Alice_01')).status, 201);
    const response = await login(ctx, 'Alice_01');
    assert.equal(response.status, 200);
    assert.equal(typeof response.body.token, 'string');
    assert.equal(response.body.token.length > 0, true);
    assert.equal(response.body.token.split('.').length, 2);
    assert.equal(typeof response.body.user, 'object');
    assert.match(response.body.user.id, UUID_PATTERN);
    assert.equal(response.body.user.username, 'Alice_01');
    assert.equal(response.text.includes(PLAINTEXT), false);
    assert.equal(/password_hash|password_salt/i.test(response.text), false);
  } finally {
    await ctx.close();
  }
});

test('AC-09 login: the returned token verifies against the persisted signing key', async () => {
  const dataDir = makeDataDir('token');
  const { ctx, secretStore, userRepository } = await startAuthServer(dataDir);
  try {
    await register(ctx, 'TokenUser');
    const response = await login(ctx, 'TokenUser');
    assert.equal(response.status, 200);
    const verified = verifyToken(response.body.token, { secretStore });
    assert.equal(verified.ok, true);
    const record = userRepository.findByUsername('TokenUser');
    assert.equal(verified.subject, record.id);
  } finally {
    await ctx.close();
  }
});

test('AC-09 login: lookup is case-insensitive (registered Alice, logs in as alice)', async () => {
  const dataDir = makeDataDir('case');
  const { ctx } = await startAuthServer(dataDir);
  try {
    assert.equal((await register(ctx, 'Alice')).status, 201);
    const response = await login(ctx, 'alice');
    assert.equal(response.status, 200);
    assert.equal(response.body.user.username, 'Alice');
  } finally {
    await ctx.close();
  }
});

test('AC-10 login: a wrong password returns 401 INVALID_CREDENTIALS', async () => {
  const dataDir = makeDataDir('wrongpass');
  const { ctx } = await startAuthServer(dataDir);
  try {
    await register(ctx, 'Bob_02');
    const response = await login(ctx, 'Bob_02', WRONG);
    assert.equal(response.status, 401);
    assert.equal(response.body.error.code, 'INVALID_CREDENTIALS');
    assert.equal(response.text.includes(WRONG), false);
  } finally {
    await ctx.close();
  }
});

test('login: unknown user and wrong password are indistinguishable (same status and body)', async () => {
  const dataDir = makeDataDir('nodisclose');
  const { ctx } = await startAuthServer(dataDir);
  try {
    await register(ctx, 'Carol_03');
    const wrongPassword = await login(ctx, 'Carol_03', WRONG);
    const unknownUser = await login(ctx, 'NoSuchUser_99', PLAINTEXT);
    assert.equal(wrongPassword.status, 401);
    assert.equal(unknownUser.status, 401);
    assert.deepEqual(unknownUser.body, wrongPassword.body);
    assert.equal(unknownUser.body.error.code, 'INVALID_CREDENTIALS');
  } finally {
    await ctx.close();
  }
});

test('login: a body field other than username/password returns 400 UNKNOWN_FIELD', async () => {
  const dataDir = makeDataDir('unknown');
  const { ctx } = await startAuthServer(dataDir);
  try {
    await register(ctx, 'Dave_04');
    const response = await postJson(ctx.url, LOGIN_PATH, {
      username: 'Dave_04',
      password: PLAINTEXT,
      role: 'admin',
    });
    assert.equal(response.status, 400);
    assert.equal(response.body.error.code, 'UNKNOWN_FIELD');
  } finally {
    await ctx.close();
  }
});

test('login: malformed JSON returns 400 VALIDATION_ERROR, never a 500', async () => {
  const dataDir = makeDataDir('malformed');
  const { ctx } = await startAuthServer(dataDir);
  try {
    const response = await postJson(ctx.url, LOGIN_PATH, null, '{not json');
    assert.equal(response.status, 400);
    assert.equal(response.body.error.code, 'VALIDATION_ERROR');
  } finally {
    await ctx.close();
  }
});

test('login: a missing or non-string field returns 400 VALIDATION_ERROR', async () => {
  const dataDir = makeDataDir('missing');
  const { ctx } = await startAuthServer(dataDir);
  try {
    const bodies = [{}, { username: 'Dave_04' }, { password: PLAINTEXT }, { username: 5, password: PLAINTEXT }];
    for (const body of bodies) {
      const response = await postJson(ctx.url, LOGIN_PATH, body);
      assert.equal(response.status, 400);
      assert.equal(response.body.error.code, 'VALIDATION_ERROR');
    }
  } finally {
    await ctx.close();
  }
});

test('login AC: a simulated process restart still logs the same user in (persistent data and key)', async () => {
  const dataDir = makeDataDir('restart');
  const first = await startAuthServer(dataDir);
  try {
    await register(first.ctx, 'RestartUser');
    assert.equal((await login(first.ctx, 'RestartUser')).status, 200);
  } finally {
    await first.ctx.close();
  }

  // Fresh app instance + fresh repositories over the same DATA_DIR.
  const second = await startAuthServer(dataDir);
  try {
    const response = await login(second.ctx, 'RestartUser');
    assert.equal(response.status, 200);
    assert.equal(typeof response.body.token, 'string');
    assert.equal(response.body.token.length > 0, true);
    assert.equal(fs.existsSync(path.join(dataDir, SECRET_FILE_NAME)), true);
  } finally {
    await second.ctx.close();
  }
});

test('login: a missing user repository fails safely with the 500 envelope', async () => {
  const app = createApp({ logger: { info() {}, warn() {}, error() {}, debug() {}, fatal() {} } });
  loginRoutes(app);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, LOGIN_PATH, { username: 'NoRepo', password: PLAINTEXT });
    assert.equal(response.status, 500);
    assert.equal(response.body.error.code, 'INTERNAL_ERROR');
  } finally {
    await ctx.close();
  }
});
