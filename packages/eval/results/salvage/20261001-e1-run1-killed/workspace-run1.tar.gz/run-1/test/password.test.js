'use strict';

/**
 * Password hasher tests: per-user random salt, scrypt derivation, constant-time
 * verification and trust-boundary validation of candidate credentials.
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const passwordModule = require('../src/auth/password.js');
const {
  hashPassword,
  verifyPassword,
  formatParams,
  parseParams,
  normalizeParams,
  toPasswordFields,
  fromPasswordFields,
  hasPasswordFields,
  describeHash,
  safeEqual,
  ALGO,
  SALT_BYTES,
  DEFAULT_PARAMS,
} = passwordModule;

const FAST_PARAMS = Object.freeze({ N: 1024, r: 8, p: 1, keylen: 32 });

test('password: the same password hashed twice uses a different random salt each time', async () => {
  const first = await hashPassword('correct horse battery', { params: FAST_PARAMS });
  const second = await hashPassword('correct horse battery', { params: FAST_PARAMS });
  assert.equal(first.algo, ALGO);
  assert.equal(first.salt.length > 0, true);
  assert.notEqual(first.salt, second.salt);
  assert.notEqual(first.hash, second.hash);
  assert.equal(Buffer.from(first.salt, 'base64').length, SALT_BYTES);
  assert.equal(first.encoding, 'base64');
});

test('password: a fresh random salt produces a digest of the configured key length', async () => {
  const credential = await hashPassword('another-secret', { params: FAST_PARAMS });
  const params = parseParams(credential.params);
  assert.equal(params.N, FAST_PARAMS.N);
  assert.equal(params.keylen, FAST_PARAMS.keylen);
  assert.equal(Buffer.from(credential.hash, 'base64').length, FAST_PARAMS.keylen);
  assert.equal(credential.params, formatParams(FAST_PARAMS));
  assert.equal(credential.params.includes(ALGO), true);
});

test('password: hex encoding is supported and round-trips through verification', async () => {
  const credential = await hashPassword('hex-encoded-secret', { params: FAST_PARAMS, encoding: 'hex' });
  assert.match(credential.salt, /^[0-9a-f]+$/);
  assert.match(credential.hash, /^[0-9a-f]+$/);
  assert.equal(await verifyPassword('hex-encoded-secret', credential), true);
  assert.equal(await verifyPassword('hex-encoded-secrez', credential), false);
});

test('password: verifyPassword accepts the right password and rejects a wrong one', async () => {
  const credential = await hashPassword('s3cret-password', { params: FAST_PARAMS });
  assert.equal(await verifyPassword('s3cret-password', credential), true);
  assert.equal(await verifyPassword('s3cret-passwore', credential), false);
  assert.equal(await verifyPassword('', credential), false);
  assert.equal(await verifyPassword('S3CRET-PASSWORD', credential), false);
});

test('password: verification works against the persisted snake_case record fields', async () => {
  const credential = await hashPassword('stored-secret', { params: FAST_PARAMS });
  const record = Object.assign({ id: 'x' }, toPasswordFields(credential));
  assert.equal(hasPasswordFields(record), true);
  assert.equal(await verifyPassword('stored-secret', record), true);
  assert.equal(await verifyPassword('nope-nope-nope', record), false);
  const shape = describeHash(record);
  assert.equal(shape.algo, ALGO);
  assert.equal(shape.hashLength > 0, true);
});

test('password: malformed credentials and non-string passwords return false, never throw', async () => {
  assert.equal(await verifyPassword('anything', null), false);
  assert.equal(await verifyPassword('anything', {}), false);
  assert.equal(await verifyPassword('anything', 'not-an-object'), false);
  assert.equal(await verifyPassword(null, { algo: 'scrypt', salt: 'AAAA', params: 'x', hash: 'AAAA' }), false);
  const broken = {
    password_algo: 'scrypt',
    password_salt: 'c2FsdA==',
    password_params: 'not-valid-params',
    password_hash: 'aGFzaA==',
  };
  assert.equal(await verifyPassword('anything', broken), false);
  const otherAlgo = Object.assign({}, broken, { password_params: formatParams(FAST_PARAMS), password_algo: 'md5' });
  assert.equal(await verifyPassword('anything', otherAlgo), false);
});

test('password: hashPassword rejects non-string, empty and oversized passwords', async () => {
  await assert.rejects(() => hashPassword(null), TypeError);
  await assert.rejects(() => hashPassword(''), TypeError);
  await assert.rejects(() => hashPassword(12345678), TypeError);
  await assert.rejects(() => hashPassword('x'.repeat(4097)), TypeError);
  await assert.rejects(() => hashPassword('ok-password', { encoding: 'utf16le' }), TypeError);
});

test('password: scrypt parameters are validated before any crypto work', () => {
  assert.deepEqual(normalizeParams(undefined), DEFAULT_PARAMS);
  assert.throws(() => normalizeParams({ N: 1000, r: 8, p: 1, keylen: 32 }), TypeError);
  assert.throws(() => normalizeParams({ N: 1024, r: 0, p: 1, keylen: 32 }), TypeError);
  assert.throws(() => normalizeParams({ N: 1024, r: 8, p: 1, keylen: 4 }), TypeError);
  assert.throws(() => parseParams('scrypt$N=oops,r=8,p=1,keylen=32'), TypeError);
  assert.throws(() => parseParams(42), TypeError);
  assert.deepEqual(parseParams('scrypt$N=1024,r=8,p=1,keylen=32'), { N: 1024, r: 8, p: 1, keylen: 32 });
  assert.deepEqual(parseParams({ N: 1024, r: 8, p: 1, keylen: 32 }), { N: 1024, r: 8, p: 1, keylen: 32 });
});

test('password: safeEqual compares digests in constant time without throwing on length mismatch', () => {
  const same = Buffer.from('abcdef');
  assert.equal(safeEqual(same, Buffer.from('abcdef')), true);
  assert.equal(safeEqual(same, Buffer.from('abcdeg')), false);
  assert.equal(safeEqual(same, Buffer.from('abcdef00')), false);
  assert.equal(safeEqual('short', 'a-much-longer-value'), false);
});

test('password: toPasswordFields rejects an incomplete credential', () => {
  assert.throws(() => toPasswordFields({ algo: 'scrypt' }), TypeError);
  assert.throws(() => toPasswordFields(null), TypeError);
  assert.equal(fromPasswordFields({ algo: 'scrypt' }), null);
});
