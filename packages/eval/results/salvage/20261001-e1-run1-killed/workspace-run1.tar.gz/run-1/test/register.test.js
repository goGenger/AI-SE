'use strict';

/**
 * POST /api/register handler tests (FR-1).
 *
 * Covers the slice acceptance criteria:
 *   - AC-02 fresh username -> 201 with { user: { id, username } }, UUID id,
 *     originally submitted username, no password/hash material
 *   - AC-03 exact duplicate -> 409 USERNAME_TAKEN
 *   - AC-05 case-only conflict (Alice then alice) -> 409 USERNAME_TAKEN
 *   - AC-06 >=5 concurrent registrations of one username yield exactly one 201
 *     and the rest 409, with no 500
 *   - AC-07 invalid username -> 400 VALIDATION_ERROR
 *   - AC-08 password shorter than 8 -> 400 VALIDATION_ERROR
 *   - unknown body field -> 400 UNKNOWN_FIELD, malformed JSON -> 400
 *   - AC-04 after a successful registration the DATA_DIR file exists and holds
 *     no plaintext password
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { registerRoutes, REGISTER_PATH } = require('../src/http/registerHandler.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { hashPassword } = require('../src/auth/password.js');

const FAST_PARAMS = Object.freeze({ N: 1024, r: 8, p: 1, keylen: 32 });
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const PLAINTEXT = 'S3cret_password!';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-register-' + (name || 'test') + '-'));
}

function makeApp(dataDir, options) {
  const opts = options && typeof options === 'object' ? options : {};
  const userRepository = createUserRepository({ dataDir });
  const app = createApp({ logger: opts.logger, services: { userRepository } });
  registerRoutes(app, {
    hasher: { hash: (pwd) => hashPassword(pwd, { params: FAST_PARAMS }) },
  });
  return { app, userRepository };
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({
        server,
        url: 'http://127.0.0.1:' + port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function postJson(baseUrl, body, raw) {
  const payload = raw === undefined ? JSON.stringify(body) : raw;
  const response = await fetch(baseUrl + REGISTER_PATH, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: payload,
  });
  const text = await response.text();
  let parsed = null;
  try {
    parsed = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    parsed = text;
  }
  return { status: response.status, body: parsed, text };
}

test('AC-02 register: a fresh username returns 201 with a UUID id and original-case username', async () => {
  const dataDir = makeDataDir('fresh');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, { username: 'Alice_01', password: PLAINTEXT });
    assert.equal(response.status, 201);
    assert.equal(Object.keys(response.body).length, 1);
    assert.equal(typeof response.body.user, 'object');
    assert.match(response.body.user.id, UUID_PATTERN);
    assert.equal(response.body.user.username, 'Alice_01');
    assert.equal('password' in response.body.user, false);
    assert.equal('password_hash' in response.body.user, false);
    assert.equal(response.text.includes(PLAINTEXT), false);
    assert.equal(/password|hash/i.test(response.text), false);
  } finally {
    await ctx.close();
  }
});

test('AC-04 register: the DATA_DIR file holds the new user and no plaintext password', async () => {
  const dataDir = makeDataDir('persist');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, { username: 'PersistUser', password: PLAINTEXT });
    assert.equal(response.status, 201);
    const fileText = fs.readFileSync(path.join(dataDir, 'users.json'), 'utf8');
    assert.equal(fileText.includes(PLAINTEXT), false);
    const records = JSON.parse(fileText);
    assert.equal(records.length, 1);
    assert.equal(records[0].username, 'PersistUser');
    assert.equal(typeof records[0].password_hash, 'string');
    assert.equal('password' in records[0], false);
  } finally {
    await ctx.close();
  }
});

test('AC-03 register: an exact duplicate username returns 409 USERNAME_TAKEN', async () => {
  const dataDir = makeDataDir('dupe');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    assert.equal((await postJson(ctx.url, { username: 'Taken', password: PLAINTEXT })).status, 201);
    const second = await postJson(ctx.url, { username: 'Taken', password: PLAINTEXT });
    assert.equal(second.status, 409);
    assert.equal(second.body.error.code, 'USERNAME_TAKEN');
  } finally {
    await ctx.close();
  }
});

test('AC-05 register: a case-only conflict (Alice then alice) returns 409 USERNAME_TAKEN', async () => {
  const dataDir = makeDataDir('case');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    assert.equal((await postJson(ctx.url, { username: 'Alice', password: PLAINTEXT })).status, 201);
    const conflict = await postJson(ctx.url, { username: 'alice', password: PLAINTEXT });
    assert.equal(conflict.status, 409);
    assert.equal(conflict.body.error.code, 'USERNAME_TAKEN');
  } finally {
    await ctx.close();
  }
});

test('AC-06 register: concurrent registrations of one username yield exactly one 201', async () => {
  const dataDir = makeDataDir('concurrent');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const attempts = Array.from({ length: 8 }, () =>
      postJson(ctx.url, { username: 'Racer', password: PLAINTEXT })
    );
    const results = await Promise.all(attempts);
    const created = results.filter((entry) => entry.status === 201);
    const conflicts = results.filter((entry) => entry.status === 409);
    const serverErrors = results.filter((entry) => entry.status >= 500);
    assert.equal(created.length, 1);
    assert.equal(conflicts.length, 7);
    assert.equal(serverErrors.length, 0);
    for (const entry of conflicts) {
      assert.equal(entry.body.error.code, 'USERNAME_TAKEN');
    }
    const records = JSON.parse(fs.readFileSync(path.join(dataDir, 'users.json'), 'utf8'));
    assert.equal(records.length, 1);
  } finally {
    await ctx.close();
  }
});

test('AC-07 register: invalid usernames return 400 VALIDATION_ERROR', async () => {
  const dataDir = makeDataDir('baduser');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const invalid = ['ab', 'a b', 'has space', 'üser', 'a'.repeat(33), 'user-name', ''];
    for (const username of invalid) {
      const response = await postJson(ctx.url, { username, password: PLAINTEXT });
      assert.equal(response.status, 400, 'username ' + JSON.stringify(username) + ' should be rejected');
      assert.equal(response.body.error.code, 'VALIDATION_ERROR');
    }
  } finally {
    await ctx.close();
  }
});

test('AC-08 register: passwords outside 8-72 characters return 400 VALIDATION_ERROR', async () => {
  const dataDir = makeDataDir('badpass');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    for (const password of ['', 'short', '1234567', 'p'.repeat(73)]) {
      const response = await postJson(ctx.url, { username: 'ValidName', password });
      assert.equal(response.status, 400);
      assert.equal(response.body.error.code, 'VALIDATION_ERROR');
    }
  } finally {
    await ctx.close();
  }
});

test('register: an unknown body field returns 400 UNKNOWN_FIELD, never silently ignored', async () => {
  const dataDir = makeDataDir('unknown');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, {
      username: 'ExtraField',
      password: PLAINTEXT,
      role: 'admin',
    });
    assert.equal(response.status, 400);
    assert.equal(response.body.error.code, 'UNKNOWN_FIELD');
  } finally {
    await ctx.close();
  }
});

test('register: malformed JSON is a 400 VALIDATION_ERROR, never a 500', async () => {
  const dataDir = makeDataDir('malformed');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, null, '{not json');
    assert.equal(response.status, 400);
    assert.equal(response.body.error.code, 'VALIDATION_ERROR');
  } finally {
    await ctx.close();
  }
});

test('register: a missing user repository fails safely with the 500 envelope', async () => {
  const app = createApp({ logger: { info() {}, warn() {}, error() {}, debug() {}, fatal() {} } });
  registerRoutes(app, { hasher: { hash: (pwd) => hashPassword(pwd, { params: FAST_PARAMS }) } });
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, { username: 'NoRepo', password: PLAINTEXT });
    assert.equal(response.status, 500);
    assert.equal(response.body.error.code, 'INTERNAL_ERROR');
  } finally {
    await ctx.close();
  }
});

test('register: the anonymous/unknown FIELD body never echoes raw input back', async () => {
  const dataDir = makeDataDir('echo');
  const { app } = makeApp(dataDir);
  const ctx = await listen(app);
  try {
    const response = await postJson(ctx.url, { username: 'okname', password: 'x', attack: '<script>' });
    assert.equal(response.status, 400);
    assert.equal(response.text.includes('<script>'), false);
  } finally {
    await ctx.close();
  }
});
