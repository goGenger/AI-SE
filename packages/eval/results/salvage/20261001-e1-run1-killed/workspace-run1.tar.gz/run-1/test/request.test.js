'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { readBody, readJsonBody, parseQuery, parseUrl, headerValue } = require('../src/http/request.js');
const { AppError } = require('../src/errors/errorEnvelope.js');
const { makeFakeRequest } = require('./helpers.js');

test('request: valid JSON bodies are parsed into plain objects', async () => {
  const req = makeFakeRequest({ method: 'POST', body: '{"username":"alice","password":"password1"}' });
  const body = await readJsonBody(req);
  assert.deepEqual(body, { username: 'alice', password: 'password1' });
});

test('request: an absent or empty body resolves to an empty object', async () => {
  assert.deepEqual(await readJsonBody(makeFakeRequest({ method: 'POST' })), {});
  assert.deepEqual(await readJsonBody(makeFakeRequest({ method: 'POST', body: '   ' })), {});
});

test('request: malformed JSON becomes a VALIDATION_ERROR, not an uncaught exception', async () => {
  await assert.rejects(
    () => readJsonBody(makeFakeRequest({ method: 'POST', body: '{not json' })),
    (error) => {
      assert.equal(error instanceof AppError, true);
      assert.equal(error.code, 'VALIDATION_ERROR');
      assert.equal(error.status, 400);
      return true;
    }
  );
});

test('request: non-object JSON payloads (arrays, scalars, null) are rejected', async () => {
  for (const payload of ['[1,2,3]', '42', '"a string"', 'null', 'true']) {
    await assert.rejects(
      () => readJsonBody(makeFakeRequest({ method: 'POST', body: payload })),
      (error) => error instanceof AppError && error.code === 'VALIDATION_ERROR'
    );
  }
});

test('request: a body larger than the limit is rejected without buffering everything', async () => {
  const huge = 'x'.repeat(2048);
  await assert.rejects(
    () => readJsonBody(makeFakeRequest({ method: 'POST', body: huge }), 128),
    (error) => error instanceof AppError && error.code === 'VALIDATION_ERROR'
  );
  const raw = await readBody(makeFakeRequest({ method: 'POST', body: 'ok' }), 128);
  assert.equal(raw, 'ok');
});

test('request: hostile query strings are parsed as plain data and never throw', () => {
  const aggregates = parseQuery('/api/tasks?q=%27%3B%20DROP%20TABLE%20users%3B--&x=1');
  assert.equal(aggregates.q, "'; DROP TABLE users;--");
  assert.equal(aggregates.x, '1');
  const empty = parseQuery('/api/tasks');
  assert.deepEqual(empty, {});
  const repeated = parseQuery('/api/tasks?q=a&q=b');
  assert.equal(repeated.q, 'b');
  const malformed = parseQuery('http://%');
  assert.deepEqual(malformed, {});
});

test('request: parseUrl always yields a usable URL even for broken input', () => {
  const good = parseUrl({ url: '/healthz?probe=1' });
  assert.equal(good.pathname, '/healthz');
  assert.equal(good.searchParams.get('probe'), '1');
  const broken = parseUrl({ url: undefined });
  assert.equal(broken.pathname, '/');
});

test('request: header lookup is case-insensitive and never returns arrays', () => {
  const req = makeFakeRequest({ headers: { authorization: 'Bearer abc' } });
  assert.equal(headerValue(req, 'Authorization'), 'Bearer abc');
  assert.equal(headerValue({ headers: { 'x-multi': ['one', 'two'] } }, 'x-multi'), 'one');
  assert.equal(headerValue({ headers: {} }, 'missing'), undefined);
});
