'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { createRouter, normalizePathname, splitPath } = require('../src/http/router.js');
const { createApp } = require('../src/http/app.js');
const { sendJson } = require('../src/http/respond.js');
const { makeLogSink, makeFakeResponse, makeFakeRequest, startTestServer, getJson } = require('./helpers.js');

test('router: matches literal paths and extracts :params', () => {
  const router = createRouter();
  router.get('/api/tasks', () => {});
  router.get('/api/tasks/:id', () => {});
  const list = router.resolve('GET', '/api/tasks');
  assert.equal(list.route.path, '/api/tasks');
  const single = router.resolve('GET', '/api/tasks/abc-123');
  assert.equal(single.route.path, '/api/tasks/:id');
  assert.deepEqual(single.params, { id: 'abc-123' });
  assert.equal(router.resolve('GET', '/api/tasks/abc/extra').route, null);
});

test('router: method matters and trailing slashes are normalised', () => {
  const router = createRouter();
  router.get('/healthz', () => {});
  assert.equal(router.resolve('POST', '/healthz').route, null);
  assert.equal(router.resolve('GET', '/healthz/').route.path, '/healthz');
  assert.equal(normalizePathname(''), '/');
  assert.deepEqual(splitPath('/api//tasks/'), ['api', 'tasks']);
});

test('router: mounted sub-routers resolve under their prefix', () => {
  const child = createRouter();
  child.get('/x', () => {});
  const parent = createRouter();
  parent.mount('/sub', child);
  const match = parent.resolve('GET', '/sub/x');
  assert.equal(match.route.path, '/x');
  assert.equal(parent.resolve('GET', '/other/x').route, null);
});

test('router: protected routes are flagged and query strings are parsed', async () => {
  const sink = makeLogSink();
  const app = createApp({ logger: { info() {}, warn() {}, error() {}, debug() {}, fatal() {} } });
  app.addProtectedRoute('GET', '/api/locked', () => {});
  const route = app
    .listRoutes()
    .find((entry) => entry.path === '/api/locked');
  assert.equal(route.auth, true);

  const ctx = await startTestServer();
  try {
    const response = await getJson(ctx.url + '/healthz?probe=1');
    assert.equal(response.status, 200);
    assert.equal(sink.text(), '');
  } finally {
    await ctx.close();
  }
});

test('router: the app parses query strings into ctx.query', async () => {
  const app = createApp();
  let captured = null;
  app.addRoute('GET', '/__echo', (ctx) => {
    captured = ctx.query;
    ctx.res.setHeader('Content-Type', 'application/json');
    ctx.res.writeHead(200);
    ctx.res.end(JSON.stringify({ ok: true }));
  });
  const ctx = await startTestServer({ appOptions: { router: app.router } });
  try {
    const response = await getJson(ctx.url + '/__echo?q=hello%20world&n=2');
    assert.equal(response.status, 200);
    assert.deepEqual(captured, { q: 'hello world', n: '2' });
  } finally {
    await ctx.close();
  }
});

test('router: handlers can be dispatched directly with fake req/res objects', async () => {
  const app = createApp();
  const seen = [];
  app.addRoute('POST', '/__direct', (ctx) => {
    seen.push(ctx.method);
    sendJson(ctx.res, 200, { ok: true });
  });
  const req = makeFakeRequest({ method: 'POST', url: '/__direct', body: '{"a":1}' });
  const res = makeFakeResponse();
  app.handleRequest(req, res);
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.deepEqual(seen, ['POST']);
  assert.equal(res.state.status, 200);
  assert.equal(res.state.headers['content-type'], 'application/json; charset=utf-8');
});

test('router: unknown paths return the NOT_FOUND envelope via the app', async () => {
  const app = createApp();
  const req = makeFakeRequest({ method: 'GET', url: '/nope' });
  const res = makeFakeResponse();
  app.handleRequest(req, res);
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(res.state.status, 404);
  assert.deepEqual(JSON.parse(res.state.body), { error: { code: 'NOT_FOUND', message: 'Resource not found' } });
});
