'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');

const { loadConfig } = require('../src/config.js');
const { createLogger } = require('../src/logger.js');
const { buildServer, startServer, main } = require('../src/server.js');
const { makeDataDir, makeLogSink, startTestServer, getJson } = require('./helpers.js');

const RAW_REQUEST_TIMEOUT_MS = 5000;

/** Issue a raw HTTP request so we control the exact wire bytes. */
function rawRequest(port, target, method) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: target, method: method || 'GET', timeout: RAW_REQUEST_TIMEOUT_MS },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          body += chunk;
        });
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
      }
    );
    req.on('timeout', () => req.destroy(new Error('raw request timed out')));
    req.on('error', reject);
    req.end();
  });
}

test('server: buildServer creates a node:http server wired to the app', () => {
  const dataDir = makeDataDir('build');
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir });
  const built = buildServer({ config, logger: createLogger({ stream: { write() {} } }) });
  assert.equal(typeof built.server.listen, 'function');
  assert.equal(built.server instanceof http.Server, true);
  assert.equal(typeof built.app.handleRequest, 'function');
  assert.equal(built.server.requestTimeout > 0, true);
});

test('AC-01 server: /healthz, /health and /ready all return 200 status ok', async () => {
  const ctx = await startTestServer();
  try {
    for (const path of ['/healthz', '/health', '/ready']) {
      const response = await getJson(ctx.url + path);
      assert.equal(response.status, 200, path + ' should return 200');
      assert.deepEqual(response.body, { status: 'ok' });
      assert.match(String(response.headers.get('content-type')), /application\/json/);
    }
  } finally {
    await ctx.close();
  }
});

test('server: listens on the port taken from PORT', async () => {
  const chosen = 0;
  const ctx = await startTestServer({ config: loadConfig({ PORT: String(chosen), DATA_DIR: makeDataDir('port') }) });
  try {
    const address = ctx.server.address();
    assert.equal(typeof address.port, 'number');
    assert.equal(address.port > 0, true);
    const response = await getJson(ctx.url + '/healthz');
    assert.equal(response.status, 200);
  } finally {
    await ctx.close();
  }
});

test('server: startup logs configuration to stdout without the signing key', async () => {
  const dataDir = makeDataDir('logcfg');
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir, TOKEN_SECRET: 'super-secret-signing-key-value' });
  const sink = makeLogSink();
  const started = await startServer({
    config,
    logger: createLogger({ stream: sink.stream, level: 'debug' }),
    host: '127.0.0.1',
  });
  try {
    const text = sink.text();
    assert.equal(text.includes('super-secret-signing-key-value'), false);
    assert.equal(text.includes('configuration loaded'), true);
    assert.equal(text.includes('server listening'), true);
    assert.equal(text.includes(dataDir), true);
  } finally {
    await new Promise((resolve) => {
      started.server.close(() => resolve());
      started.server.closeAllConnections();
    });
  }
});

test('AC-24 server: unmatched routes return a 404 NOT_FOUND envelope, never a 5xx', async () => {
  const ctx = await startTestServer();
  try {
    const response = await getJson(ctx.url + '/definitely/missing');
    assert.equal(response.status, 404);
    assert.equal(response.body.error.code, 'NOT_FOUND');
    assert.equal(typeof response.body.error.message, 'string');
  } finally {
    await ctx.close();
  }
});

test('server: top-level error trap converts a thrown handler error into the 500 envelope', async () => {
  const ctx = await startTestServer();
  try {
    ctx.app.addRoute('GET', '/__boom', () => {
      const error = new Error('kaboom password=leak-me-please');
      error.code = 'E_BOOM';
      throw error;
    });
    const response = await getJson(ctx.url + '/__boom');
    assert.equal(response.status, 500);
    assert.deepEqual(response.body, { error: { code: 'INTERNAL_ERROR', message: 'Internal server error' } });
    assert.equal(response.text.includes('kaboom'), false);
    assert.equal(response.text.includes('leak-me-please'), false);
    assert.equal(response.text.includes('stack'), false);
    assert.equal(response.text.includes('at '), false);
  } finally {
    await ctx.close();
  }
});

test('server: the error trap also catches rejected promises, and logs stay redacted', async () => {
  const ctx = await startTestServer();
  try {
    ctx.app.addRoute('POST', '/__reject', async () => {
      await Promise.resolve();
      throw new Error('async failure password=top-secret-value');
    });
    const response = await new Promise((resolve, reject) => {
      const req = http.request(
        { host: '127.0.0.1', port: ctx.server.address().port, path: '/__reject', method: 'POST' },
        (res) => {
          let body = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => {
            body += chunk;
          });
          res.on('end', () => resolve({ status: res.statusCode, body }));
        }
      );
      req.on('error', reject);
      req.end('{}');
    });
    assert.equal(response.status, 500);
    const body = JSON.parse(response.body);
    assert.equal(body.error.code, 'INTERNAL_ERROR');
    assert.equal(body.error.message, 'Internal server error');
    assert.equal(ctx.log.text().includes('top-secret-value'), false);
  } finally {
    await ctx.close();
  }
});

test('server: malformed URLs and unknown methods never produce a 5xx', async () => {
  const ctx = await startTestServer();
  try {
    const port = ctx.server.address().port;
    const badPercent = await rawRequest(port, '/%zz%', 'GET');
    assert.equal(badPercent.status < 500, true);
    const trace = await rawRequest(port, '/healthz', 'TRACE');
    assert.equal(trace.status < 500, true);
    const brokenJson = await new Promise((resolve, reject) => {
      const req = http.request(
        { host: '127.0.0.1', port, path: '/api/register', method: 'POST' },
        (res) => {
          let body = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => {
            body += chunk;
          });
          res.on('end', () => resolve({ status: res.statusCode, body }));
        }
      );
      req.on('error', reject);
      req.end('{not json');
    });
    assert.equal(brokenJson.status < 500, true);
  } finally {
    await ctx.close();
  }
});

test('server: OPTIONS preflight is answered without touching the router', async () => {
  const ctx = await startTestServer();
  try {
    const response = await rawRequest(ctx.server.address().port, '/api/tasks', 'OPTIONS');
    assert.equal(response.status, 204);
    assert.equal(String(response.headers.allow).includes('GET'), true);
  } finally {
    await ctx.close();
  }
});

test('server: main starts the service and reads PORT plus DATA_DIR from the environment', async () => {
  const dataDir = makeDataDir('main');
  const previous = { PORT: process.env.PORT, DATA_DIR: process.env.DATA_DIR };
  process.env.PORT = '0';
  process.env.DATA_DIR = dataDir;
  try {
    const result = await main();
    assert.equal(result.ok, true);
    assert.equal(typeof result.server.listen, 'function');
    assert.equal(result.config.dataDir, dataDir);
    assert.equal(fs.existsSync(dataDir), true);
    await new Promise((resolve) => {
      result.server.close(() => resolve());
      result.server.closeAllConnections();
    });
  } finally {
    if (previous.PORT === undefined) {
      delete process.env.PORT;
    } else {
      process.env.PORT = previous.PORT;
    }
    if (previous.DATA_DIR === undefined) {
      delete process.env.DATA_DIR;
    } else {
      process.env.DATA_DIR = previous.DATA_DIR;
    }
  }
});
