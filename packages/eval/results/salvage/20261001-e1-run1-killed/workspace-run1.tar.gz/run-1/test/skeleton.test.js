'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { ROOT, listFiles, relative, read } = require('../src/scripts/scan.js');
const { logger, createLogger } = require('../src/logger.js');
const { HEALTH_PATHS } = require('../src/http/app.js');
const serverModule = require('../src/server.js');

const SRC_FILES = listFiles('src').filter((file) => file.endsWith('.js'));
const RUNTIME_FILES = SRC_FILES.filter((file) => !relative(file).startsWith('src/scripts/'));

function packageJson() {
  return JSON.parse(read(path.join(ROOT, 'package.json')));
}

test('skeleton: required modules exist for config, logger and the server entry', () => {
  for (const rel of ['src/config.js', 'src/logger.js', 'src/server.js', 'src/http/app.js', 'src/http/router.js']) {
    assert.equal(fs.existsSync(path.join(ROOT, rel)), true, rel + ' must exist');
  }
});

test('skeleton: package.json keeps zero runtime dependencies', () => {
  const pkg = packageJson();
  assert.equal(typeof pkg.dependencies, 'object');
  assert.deepEqual(Object.keys(pkg.dependencies), []);
});

test('skeleton: package.json exposes the required scripts with the agreed commands', () => {
  const scripts = packageJson().scripts;
  for (const name of ['start', 'test', 'lint', 'typecheck', 'build']) {
    assert.equal(typeof scripts[name], 'string', name + ' script is required');
  }
  assert.equal(scripts.test, 'node --test');
  assert.equal(scripts.start.includes('src/server.js'), true);
});

test('skeleton: no runtime module imports a third-party package', () => {
  for (const file of RUNTIME_FILES) {
    const source = read(file);
    const requires = source.match(/require\('([^']+)'\)/g) || [];
    for (const statement of requires) {
      const spec = statement.slice(statement.indexOf("'") + 1, statement.lastIndexOf("'"));
      const allowed = spec.startsWith('node:') || spec.startsWith('./') || spec.startsWith('../');
      assert.equal(allowed, true, relative(file) + ' imports disallowed module ' + spec);
    }
  }
});

test('skeleton: the src module graph has no circular dependencies', () => {
  const graph = new Map();
  for (const file of RUNTIME_FILES) {
    const rel = relative(file);
    const dependencies = [];
    const requires = read(file).match(/require\('(\.[^']+)'\)/g) || [];
    for (const statement of requires) {
      const spec = statement.slice(statement.indexOf("'") + 1, statement.lastIndexOf("'"));
      dependencies.push(path.relative(ROOT, path.resolve(path.dirname(file), spec)).split(path.sep).join('/'));
    }
    graph.set(rel, dependencies);
  }
  const visiting = new Set();
  const done = new Set();
  const cycles = [];
  function visit(node, trail) {
    if (done.has(node)) {
      return;
    }
    if (visiting.has(node)) {
      cycles.push(trail.concat(node).join(' -> '));
      return;
    }
    visiting.add(node);
    for (const next of graph.get(node) || []) {
      if (graph.has(next)) {
        visit(next, trail.concat(node));
      }
    }
    visiting.delete(node);
    done.add(node);
  }
  for (const node of graph.keys()) {
    visit(node, []);
  }
  assert.deepEqual(cycles, []);
});

test('AC-29 logger: the default logger writes to stdout and never to a file', () => {
  assert.equal(logger.stream, process.stdout);
  const source = read(path.join(ROOT, 'src/logger.js'));
  assert.equal(/require\('node:fs'\)/.test(source), false);
  assert.equal(/createWriteStream|appendFile|writeFileSync/.test(source), false);
  const logFileUse = RUNTIME_FILES.some((file) => /['"][^'"]*\.log['"]/.test(read(file)));
  assert.equal(logFileUse, false);
});

test('AC-29 logger: a captured stdout stream receives every log line', () => {
  const lines = [];
  const log = createLogger({ stream: { write: (chunk) => lines.push(String(chunk)) }, level: 'debug' });
  log.debug('one');
  log.fatal('two');
  assert.equal(lines.length, 2);
  assert.equal(lines[0].endsWith('\n'), true);
});

test('AC-01 skeleton: the three health routes are wired before any auth logic', () => {
  assert.deepEqual(HEALTH_PATHS.slice().sort(), ['/health', '/healthz', '/ready']);
  const appSource = read(path.join(ROOT, 'src/http/app.js'));
  const healthIndex = appSource.indexOf('HEALTH_PATHS');
  const authIndex = appSource.indexOf('authMiddleware');
  assert.equal(healthIndex > -1 && authIndex > -1 && healthIndex < authIndex, true);
});

test('skeleton: the server module exports the bootstrap surface', () => {
  for (const name of ['buildServer', 'startServer', 'installProcessErrorTraps', 'installShutdownHandlers', 'main']) {
    assert.equal(typeof serverModule[name], 'function', name + ' must be exported');
  }
});

test('skeleton: debug and info logging never interpolate the configuration secret', () => {
  const source = read(path.join(ROOT, 'src/server.js'));
  assert.equal(source.includes('config.tokenSecret'), false);
  assert.equal(source.includes('describeConfig(config)'), true);
});

test('skeleton: a data directory is created before the server listens', () => {
  const source = read(path.join(ROOT, 'src/config.js'));
  assert.equal(source.includes('fs.mkdirSync(dataDir.absolute, { recursive: true })'), true);
});

test('container contract: when a Dockerfile exists it must run non-root with a /data volume', { skip: !fs.existsSync(path.join(ROOT, 'Dockerfile')) }, () => {
  const dockerfile = read(path.join(ROOT, 'Dockerfile'));
  assert.match(dockerfile, /^FROM\s+node/m);
  assert.match(dockerfile, /^USER\s+(?!root)/m);
  assert.match(dockerfile, /VOLUME\s+\[?"?\/data/m);
  assert.match(dockerfile, /^CMD\s|^ENTRYPOINT\s/m);
});
