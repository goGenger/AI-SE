'use strict';

/**
 * Start-entry contract for the `pnpm start` script (S4-04).
 *
 *   - the start script launches src/server.js and never redirects logs to a file
 *   - PORT is read from the environment with a default of 3000
 *   - DATA_DIR is read from the environment with a default of ./data and the
 *     directory is created on startup
 *   - the running service logs to the provided (stdout) stream and answers
 *     GET /healthz with 200 {"status":"ok"}
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { ROOT, read } = require('../src/scripts/scan.js');
const { loadConfig, DEFAULT_PORT, DEFAULT_DATA_DIR } = require('../src/config.js');
const { createLogger } = require('../src/logger.js');
const { startServer } = require('../src/server.js');
const { getJson } = require('./helpers.js');

const FILE_REDIRECT = /(?:[0-9]?)>>?\s*(?!&)\S/;
const LOG_FILE_PATH = /['"][^'"]*\.log['"]/;

test('start entry: the start script launches src/server.js without redirecting logs to a file', () => {
  const pkg = JSON.parse(read(path.join(ROOT, 'package.json')));
  const start = String((pkg.scripts && pkg.scripts.start) || '');
  assert.match(start, /node\s+src\/server\.js/);
  assert.equal(FILE_REDIRECT.test(start), false, 'the start script must not redirect stdout/stderr to a file: ' + start);
  assert.equal(LOG_FILE_PATH.test(start), false, 'the start script must not name a .log file: ' + start);
  assert.equal(/tee(\s|$)/.test(start), false, 'the start script must not pipe logs into tee: ' + start);
});

test('start entry: PORT defaults to 3000 and DATA_DIR defaults to ./data when the environment is empty', () => {
  const config = loadConfig({});
  assert.equal(DEFAULT_PORT, 3000);
  assert.equal(DEFAULT_DATA_DIR, './data');
  assert.equal(config.port, 3000, 'an unset PORT must default to 3000');
  assert.equal(config.dataDirSetting, './data', 'an unset DATA_DIR must default to ./data');
  assert.equal(config.dataDir, path.resolve('./data'));
  assert.equal(fs.existsSync(config.dataDir), true, 'the default DATA_DIR must be created on startup');
  assert.equal(fs.statSync(config.dataDir).isDirectory(), true);
});

test('start entry: a custom PORT is honoured and a custom DATA_DIR becomes the data root', () => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-startentry-'));
  const custom = path.join(dataDir, 'volume');
  const config = loadConfig({ PORT: '45999', DATA_DIR: custom });
  assert.equal(config.port, 45999, 'a set PORT must win over the default');
  assert.equal(config.dataDir, path.resolve(custom), 'a set DATA_DIR must win over the default');
  assert.equal(fs.existsSync(config.dataDir), true);
});

test('start entry: the running service logs to the stdout stream and /healthz returns 200 status ok', async () => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-startentry-run-'));
  const config = loadConfig({ PORT: '0', DATA_DIR: dataDir });
  const lines = [];
  const logger = createLogger({ stream: { write: (chunk) => lines.push(String(chunk)) }, level: 'info' });
  const started = await startServer({ config, logger });
  try {
    const text = lines.join('');
    assert.match(text, /configuration loaded/);
    assert.match(text, /server listening/);
    const port = started.server.address().port;
    const response = await getJson('http://127.0.0.1:' + port + '/healthz');
    assert.equal(response.status, 200);
    assert.deepEqual(response.body, { status: 'ok' });
  } finally {
    await new Promise((resolve) => {
      started.server.close(() => resolve());
      started.server.closeAllConnections();
    });
  }
});
