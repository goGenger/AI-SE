'use strict';

/**
 * Storage layer tests: JSON collection persistence, atomic replacement and the
 * in-process mutex/write queue.
 *
 * Covers the slice acceptance criteria:
 *   - missing data file starts from an empty collection without throwing;
 *   - an existing file is loaded in full;
 *   - save() replaces the file via temp file + rename (no partial file visible);
 *   - runExclusive serialises concurrent read-modify-write cycles;
 *   - the store never prints record contents to stdout (no password leakage).
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { JsonStore, JsonStoreError, createJsonStore, atomicWriteFileSync } = require('../src/store/jsonStore.js');
const { createMutex, Mutex, runExclusive } = require('../src/store/mutex.js');

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-store-' + (name || 'test') + '-'));
}

function readFile(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function listTempFiles(dir) {
  return fs.readdirSync(dir).filter((name) => name.endsWith('.tmp'));
}

test('storage: a missing data file starts from an empty collection without throwing', () => {
  const dataDir = makeDataDir('missing');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  assert.deepEqual(store.get(), []);
  assert.equal(store.stats().exists, false);
  assert.equal(store.stats().corrupt, false);
  assert.equal(fs.existsSync(path.join(dataDir, 'users.json')), false);
  assert.equal(store.isEmpty(), true);
});

test('storage: a corrupt data file is backed up and replaced by an empty collection', () => {
  const dataDir = makeDataDir('corrupt');
  const filePath = path.join(dataDir, 'users.json');
  fs.writeFileSync(filePath, '{ not json at all', 'utf8');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  assert.deepEqual(store.get(), []);
  assert.equal(store.stats().corrupt, true);
  assert.equal(store.stats().corruptBackup !== null, true);
  const backups = fs.readdirSync(dataDir).filter((name) => name.endsWith('.corrupt'));
  assert.equal(backups.length, 1);
  assert.equal(readFile(path.join(dataDir, backups[0])), '{ not json at all');
});

test('storage: an existing data file is loaded in full', () => {
  const dataDir = makeDataDir('load');
  const records = [
    { id: 'u1', username: 'Alice' },
    { id: 'u2', username: 'bob' },
  ];
  fs.writeFileSync(path.join(dataDir, 'users.json'), JSON.stringify(records, null, 2) + '\n', 'utf8');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  assert.deepEqual(store.get(), records);
  assert.equal(store.stats().exists, true);
  assert.equal(store.stats().records, 2);
});

test('storage: reload() re-reads the file after an external change', () => {
  const dataDir = makeDataDir('reload');
  const filePath = path.join(dataDir, 'users.json');
  fs.writeFileSync(filePath, '[{"id":"u1"}]\n', 'utf8');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  fs.writeFileSync(filePath, '[{"id":"u1"},{"id":"u2"}]\n', 'utf8');
  assert.equal(store.get().length, 1);
  store.reload();
  assert.equal(store.get().length, 2);
  assert.equal(store.get()[1].id, 'u2');
});

test('storage: serialize()/deserialize() round-trip the collection', () => {
  const dataDir = makeDataDir('serialize');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  const value = [{ id: 'u1', tags: ['a', 'b'], meta: { active: true } }];
  const text = store.serialize(value);
  assert.equal(typeof text, 'string');
  assert.equal(text.endsWith('\n'), true);
  assert.deepEqual(store.deserialize(text), value);
  assert.deepEqual(JSON.parse(JSON.stringify(store)), store.stats());
});

test('storage: save() persists atomically and leaves no temp files behind', async () => {
  const dataDir = makeDataDir('save');
  const filePath = path.join(dataDir, 'users.json');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  await store.save([{ id: 'u1' }]);
  assert.deepEqual(JSON.parse(readFile(filePath)), [{ id: 'u1' }]);
  await store.save([{ id: 'u1' }, { id: 'u2' }]);
  assert.deepEqual(JSON.parse(readFile(filePath)), [{ id: 'u1' }, { id: 'u2' }]);
  assert.deepEqual(listTempFiles(dataDir), []);
  assert.equal(store.stats().exists, true);
  assert.equal(store.stats().lastSavedAt !== null, true);
});

test('storage: save() replaces the file in-place so readers never see a partial file', async () => {
  const dataDir = makeDataDir('atomic');
  const filePath = path.join(dataDir, 'users.json');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  await store.save([{ id: 'u0' }]);

  let observedInvalid = false;
  let reads = 0;
  const reader = setInterval(() => {
    try {
      const parsed = JSON.parse(readFile(filePath));
      assert.equal(Array.isArray(parsed), true);
      reads += 1;
    } catch (error) {
      observedInvalid = true;
    }
  }, 0);

  const writes = [];
  for (let index = 1; index <= 40; index += 1) {
    const payload = [];
    for (let inner = 0; inner <= index; inner += 1) {
      payload.push({ id: 'u' + inner, padding: 'x'.repeat(500) });
    }
    writes.push(store.save(payload));
    // Yield to the timer phase so the polling reader observes real intermediate
    // states while the write queue is still draining.
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  await Promise.all(writes);
  clearInterval(reader);

  assert.equal(observedInvalid, false);
  assert.equal(reads > 0, true);
  assert.equal(JSON.parse(readFile(filePath)).length, 41);
  assert.deepEqual(listTempFiles(dataDir), []);
});

test('storage: atomicWriteFileSync writes to a same-directory temp file and renames', () => {
  const dataDir = makeDataDir('atomic-fn');
  const target = path.join(dataDir, 'users.json');
  atomicWriteFileSync(target, '{"a":1}\n');
  assert.equal(readFile(target), '{"a":1}\n');
  assert.deepEqual(listTempFiles(dataDir), []);
  const source = readFile(path.join(__dirname, '..', 'src', 'store', 'jsonStore.js'));
  assert.equal(source.includes('fs.renameSync(tempPath, targetPath)'), true);
  assert.equal(source.includes('fs.fsyncSync(fd)'), true);
});

test('storage: update() applies queued read-modify-write cycles in order (concurrency)', async () => {
  const dataDir = makeDataDir('update');
  const filePath = path.join(dataDir, 'users.json');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });

  const tasks = [];
  for (let index = 0; index < 25; index += 1) {
    tasks.push(
      store.update((collection) => {
        collection.push({ id: 'u' + index });
        return collection;
      })
    );
  }
  await Promise.all(tasks);

  const persisted = JSON.parse(readFile(filePath));
  assert.equal(persisted.length, 25);
  assert.deepEqual(
    persisted.map((record) => record.id),
    Array.from({ length: 25 }, (unused, index) => 'u' + index)
  );
  assert.equal(store.get().length, 25);
});

test('storage: concurrent check-then-act updates yield exactly one winner', async () => {
  const dataDir = makeDataDir('race');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  await store.save([{ id: 'existing', username: 'Bob', usernameLower: 'bob' }]);

  const attempts = [];
  for (let index = 0; index < 8; index += 1) {
    attempts.push(
      store.update((collection) => {
        if (collection.some((record) => record.usernameLower === 'alice')) {
          throw new Error('duplicate');
        }
        collection.push({ id: 'new', username: 'alice', usernameLower: 'alice' });
        return collection;
      })
    );
  }
  const settled = await Promise.allSettled(attempts);
  assert.equal(settled.filter((entry) => entry.status === 'fulfilled').length, 1);
  assert.equal(settled.filter((entry) => entry.status === 'rejected').length, 7);
  assert.equal(store.get().length, 2);
});

test('storage: store operations never write record contents to stdout', async () => {
  const dataDir = makeDataDir('stdout');
  const store = createJsonStore({ dataDir, fileName: 'users.json', createEmpty: () => [] });
  const secret = 'sup3r-secret-password-hash';
  const chunks = [];
  const originalWrite = process.stdout.write;
  process.stdout.write = (chunk, ...rest) => {
    chunks.push(String(chunk));
    return true;
  };
  try {
    await store.save([{ id: 'u1', password_hash: secret, password: 'plaintext-pass' }]);
    store.reload();
    store.serialize();
    JSON.stringify(store.stats());
  } finally {
    process.stdout.write = originalWrite;
  }
  const captured = chunks.join('');
  assert.equal(captured.includes(secret), false);
  assert.equal(captured.includes('plaintext-pass'), false);
  assert.equal(captured, '');
});

test('storage trust boundary: unsafe DATA_DIR and file names are rejected', () => {
  assert.throws(() => createJsonStore({ dataDir: '' , fileName: 'users.json' }), JsonStoreError);
  assert.throws(() => createJsonStore({ dataDir: null, fileName: 'users.json' }), JsonStoreError);
  const dataDir = makeDataDir('traversal');
  for (const bad of ['../escape.json', 'nested/users.json', '..', '.', '', ' has-space.json', 'a/b', 'x'.repeat(200) + '.json']) {
    assert.throws(() => createJsonStore({ dataDir, fileName: bad }), JsonStoreError, 'rejects ' + JSON.stringify(bad));
  }
  const good = createJsonStore({ dataDir, fileName: 'users.json' });
  assert.equal(good.filePath, path.join(dataDir, 'users.json'));
});

test('mutex: runExclusive serialises tasks in FIFO order', async () => {
  const mutex = createMutex({ name: 'test' });
  const order = [];
  const make = (id) =>
    mutex.runExclusive(async () => {
      order.push('start:' + id);
      await new Promise((resolve) => setTimeout(resolve, 1));
      order.push('end:' + id);
      return id;
    });
  const results = await Promise.all([make(1), make(2), make(3)]);
  assert.deepEqual(results, [1, 2, 3]);
  assert.deepEqual(order, ['start:1', 'end:1', 'start:2', 'end:2', 'start:3', 'end:3']);
  assert.equal(mutex.isIdle(), true);
  assert.equal(mutex.completed, 3);
});

test('mutex: a rejected task is delivered to its caller without stalling the queue', async () => {
  const mutex = new Mutex();
  const first = mutex.runExclusive(() => {
    throw new Error('boom');
  });
  const second = mutex.runExclusive(() => 'ok');
  await assert.rejects(first, /boom/);
  assert.equal(await second, 'ok');
  assert.equal(mutex.failed, 1);
  assert.equal(mutex.completed, 1);
  await assert.rejects(mutex.runExclusive(null), TypeError);
  assert.equal(typeof runExclusive, 'function');
});
