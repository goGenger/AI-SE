'use strict';

/**
 * Owner-scoped task persistence layer tests (slice S2-T04 / FR-6 / FR-7).
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { createTaskRepository } = require('../src/store/taskRepo.js');
const schema = require('../src/store/tasksSchema.js');

const OWNER_A = '11111111-2222-4333-8444-555555555555';
const OWNER_B = '99999999-8888-4777-8666-555555555555';
const OWNER_C = '22222222-3333-4444-8555-666666666666';
const TASKS_FILE = 'tasks.json';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-persist-' + (name || 'test') + '-'));
}

function readStoreFile(dataDir) {
  const filePath = path.join(dataDir, TASKS_FILE);
  assert.equal(fs.existsSync(filePath), true, 'the store file must exist under DATA_DIR');
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

test('AC-27 S2-T04: the five owner-scoped operations persist a task under DATA_DIR', async () => {
  const dataDir = makeDataDir('five-ops');
  const repo = createTaskRepository({ dataDir });

  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'first task' });
  assert.equal(created.ok, true);

  const listed = repo.listTasksByOwner(OWNER_A);
  assert.equal(listed.length, 1);
  assert.equal(repo.findTaskByIdAndOwner(created.task.id, OWNER_A).id, created.task.id);

  const updated = await repo.updateTaskByIdAndOwner(created.task.id, OWNER_A, { done: true });
  assert.equal(updated.ok, true);
  assert.equal(updated.task.done, true);
  await repo.waitForIdle();

  const rows = readStoreFile(dataDir);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].id, created.task.id);
  assert.equal(rows[0].ownerId, OWNER_A);
  assert.equal(rows[0].done, true);

  const removed = await repo.deleteTaskByIdAndOwner(created.task.id, OWNER_A);
  assert.equal(removed.ok, true);
  await repo.waitForIdle();
  assert.deepEqual(readStoreFile(dataDir), []);
});

test('AC-27 S2-T04: every read, update and delete matches id AND ownerId only', async () => {
  const dataDir = makeDataDir('scope');
  const repo = createTaskRepository({ dataDir });
  const mine = await repo.insertTask({ ownerId: OWNER_A, title: 'mine' });
  const id = mine.task.id;

  assert.equal(repo.findTaskByIdAndOwner(id, OWNER_B), null);
  assert.deepEqual(repo.listTasksByOwner(OWNER_B), []);
  assert.equal(repo.findTaskByIdAndOwner('not-a-real-id', OWNER_A), null);

  const crossUpdate = await repo.updateTaskByIdAndOwner(id, OWNER_B, { title: 'hijacked', done: true });
  assert.equal(crossUpdate.ok, false);
  assert.equal(crossUpdate.code, 'NOT_FOUND');
  const crossDelete = await repo.deleteTaskByIdAndOwner(id, OWNER_B);
  assert.equal(crossDelete.ok, false);
  assert.equal(crossDelete.code, 'NOT_FOUND');

  const untouched = repo.findTaskByIdAndOwner(id, OWNER_A);
  assert.equal(untouched.title, 'mine');
  assert.equal(untouched.done, false);
  assert.equal(repo.listTasksByOwner(OWNER_A).length, 1);
});

test('AC-27 S2-T04: a deleted task is never returned by any owner-scoped query', async () => {
  const dataDir = makeDataDir('deleted');
  const repo = createTaskRepository({ dataDir });
  const keep = await repo.insertTask({ ownerId: OWNER_A, title: 'keep' });
  const drop = await repo.insertTask({ ownerId: OWNER_A, title: 'remove-me' });

  const removed = await repo.deleteTaskByIdAndOwner(drop.task.id, OWNER_A);
  assert.equal(removed.ok, true);
  await repo.waitForIdle();

  assert.equal(repo.findTaskByIdAndOwner(drop.task.id, OWNER_A), null);
  assert.equal(repo.findTaskByIdAndOwner(drop.task.id, OWNER_B), null);
  assert.deepEqual(repo.listTasksByOwner(OWNER_A).map((row) => row.id), [keep.task.id]);
  assert.equal(repo.listTasksByOwner(OWNER_B).some((row) => row.title === 'remove-me'), false);

  const reopened = createTaskRepository({ dataDir });
  assert.equal(reopened.findTaskByIdAndOwner(drop.task.id, OWNER_A), null);
  assert.deepEqual(reopened.listTasksByOwner(OWNER_A).map((row) => row.id), [keep.task.id]);

  const again = await repo.deleteTaskByIdAndOwner(drop.task.id, OWNER_A);
  assert.equal(again.ok, false);
  assert.equal(again.code, 'NOT_FOUND');
});

test('AC-25 S2-T04: concurrent writes never leave an interleaved or partial write', async () => {
  const dataDir = makeDataDir('concurrent');
  const repo = createTaskRepository({ dataDir });
  const owners = [OWNER_A, OWNER_B, OWNER_C];

  const inserts = [];
  for (let index = 0; index < 60; index += 1) {
    inserts.push(repo.insertTask({ ownerId: owners[index % owners.length], title: 'task ' + index }));
  }
  const settled = await Promise.all(inserts);
  assert.equal(settled.every((entry) => entry.ok === true), true);
  await repo.waitForIdle();

  const rows = readStoreFile(dataDir);
  assert.equal(rows.length, 60);
  assert.equal(rows.every((row) => schema.validateTaskRecord(row).ok === true), true);
  assert.equal(new Set(rows.map((row) => row.id)).size, 60);

  const mine = repo.listTasksByOwner(OWNER_A);
  const mixed = [];
  for (let index = 0; index < mine.length; index += 1) {
    if (index % 3 === 0) {
      mixed.push(repo.updateTaskByIdAndOwner(mine[index].id, OWNER_A, { done: true }));
    } else if (index % 3 === 1) {
      mixed.push(repo.deleteTaskByIdAndOwner(mine[index].id, OWNER_A));
    } else {
      mixed.push(repo.insertTask({ ownerId: OWNER_A, title: 'added ' + index }));
    }
    mixed.push(repo.findTaskByIdAndOwner(mine[index].id, OWNER_C));
    mixed.push(repo.listTasksByOwner(OWNER_B));
  }
  await Promise.all(mixed);
  await repo.waitForIdle();

  const after = readStoreFile(dataDir);
  assert.equal(after.every((row) => schema.validateTaskRecord(row).ok === true), true);
  const ownerCounts = {};
  for (const row of after) {
    ownerCounts[row.ownerId] = (ownerCounts[row.ownerId] || 0) + 1;
  }
  const total = Object.keys(ownerCounts).reduce((sum, key) => sum + ownerCounts[key], 0);
  assert.equal(total, after.length);
  assert.equal(repo.listTasksByOwner(OWNER_A).length, ownerCounts[OWNER_A] || 0);
  assert.equal(repo.listTasksByOwner(OWNER_B).length, ownerCounts[OWNER_B] || 0);
  assert.equal(repo.listTasksByOwner(OWNER_C).length, ownerCounts[OWNER_C] || 0);

  const leftovers = fs.readdirSync(dataDir).filter((name) => name.endsWith('.tmp') || name.endsWith('.corrupt'));
  assert.deepEqual(leftovers, []);
});

test('AC-25 S2-T04: tasks persist under DATA_DIR across a repository restart', async () => {
  const dataDir = makeDataDir('restart');
  const repo = createTaskRepository({ dataDir });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'survives', dueDate: '2026-12-31' });
  await repo.waitForIdle();

  const restarted = createTaskRepository({ dataDir });
  const found = restarted.findTaskByIdAndOwner(created.task.id, OWNER_A);
  assert.equal(found.title, 'survives');
  assert.equal(found.dueDate, '2026-12-31');
  assert.equal(restarted.size(), 1);
  assert.deepEqual(restarted.listTasksByOwner(OWNER_B), []);
});

test('S2-T04: the persistence layer rejects malformed input without writing anything', async () => {
  const dataDir = makeDataDir('boundary');
  const repo = createTaskRepository({ dataDir });

  const noOwner = await repo.insertTask({ title: 'no owner' });
  assert.equal(noOwner.ok, false);
  assert.equal(noOwner.code, 'VALIDATION_ERROR');

  const blankTitle = await repo.insertTask({ ownerId: OWNER_A, title: '   ' });
  assert.equal(blankTitle.ok, false);
  assert.equal(blankTitle.code, 'TITLE_INVALID');

  const longTitle = await repo.insertTask({ ownerId: OWNER_A, title: 'a'.repeat(101) });
  assert.equal(longTitle.ok, false);
  assert.equal(longTitle.code, 'TITLE_INVALID');

  const badDate = await repo.insertTask({ ownerId: OWNER_A, title: 'ok', dueDate: '2026-02-30' });
  assert.equal(badDate.ok, false);
  assert.equal(badDate.code, 'DATE_INVALID');

  const crossUpdate = await repo.updateTaskByIdAndOwner('missing-id', OWNER_A, { title: 'x' });
  assert.equal(crossUpdate.ok, false);
  assert.equal(crossUpdate.code, 'NOT_FOUND');

  await repo.waitForIdle();
  assert.equal(repo.size(), 0);
  assert.equal(fs.existsSync(path.join(dataDir, TASKS_FILE)), false);
});
