'use strict';

/**
 * Task route registration + Bearer auth guard tests (S2-T05).
 *
 * Covers the task acceptance criteria:
 *   - the five task routes are registered and dispatched by method + path, with
 *     the :id segment extracted from the URL
 *   - every /api/tasks* route passes the Bearer guard first: a missing, tampered
 *     or truncated token returns 401 UNAUTHORIZED
 *   - when no userId is resolved, no task handler logic and no store access run
 *   - the task routes do not collide with /api/register, /api/login, /healthz,
 *     /health, /ready or GET /
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const { createApp } = require('../src/http/app.js');
const { createRouter } = require('../src/http/router.js');
const { createSecretStore } = require('../src/auth/secretStore.js');
const { issueToken } = require('../src/auth/token.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');
const { createUserRepository } = require('../src/store/userRepo.js');
const { registerRoutes } = require('../src/http/registerHandler.js');
const { loginRoutes } = require('../src/http/loginHandler.js');
const { taskRoutes, TASKS_PATH, TASK_ID_PATH } = require('../src/http/taskHandler.js');

const SILENT_LOGGER = { info() {}, warn() {}, error() {}, debug() {}, fatal() {} };
const USER_ID = '11111111-2222-4333-8444-555555555555';
const USERNAME = 'Alice_01';

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-taskroutes-' + (name || 't') + '-'));
}

function stubUserRepository(record) {
  const stored = record === undefined ? { id: USER_ID, username: USERNAME } : record;
  return {
    findById(id) {
      return stored && stored.id === id ? Object.assign({}, stored) : null;
    },
  };
}

/** Repository double resolving several known identities by id. */
function multiUserRepository(records) {
  const byId = new Map(records.map((entry) => [entry.id, entry]));
  return {
    findById(id) {
      const found = byId.get(id);
      return found ? Object.assign({}, found) : null;
    },
  };
}

function listen(app) {
  const server = http.createServer((req, res) => app.handleRequest(req, res));
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        url: 'http://127.0.0.1:' + server.address().port,
        close: () =>
          new Promise((done) => {
            server.close(() => done());
            server.closeAllConnections();
          }),
      });
    });
  });
}

async function request(ctx, options) {
  const opts = options || {};
  const headers = Object.assign({}, opts.headers);
  const init = { method: opts.method || 'GET', headers };
  if (opts.body !== undefined) {
    init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    if (headers['content-type'] === undefined) {
      headers['content-type'] = 'application/json';
    }
  }
  const response = await fetch(ctx.url + (opts.url || TASKS_PATH), init);
  const text = await response.text();
  let body = null;
  try {
    body = text.length === 0 ? null : JSON.parse(text);
  } catch (error) {
    body = text;
  }
  return { status: response.status, headers: response.headers, body, text };
}

/** Build an app + live server with the five task routes and a task repository. */
async function startApp(options) {
  const opts = options || {};
  const secretStore = opts.secretStore || createSecretStore({ dataDir: makeDataDir('mw'), env: {} });
  const userRepository = opts.userRepository || stubUserRepository();
  const taskRepository = opts.taskRepository || createTaskRepository({ dataDir: makeDataDir('tasks') });
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, taskRepository, secretStore } });
  taskRoutes(app);
  const ctx = await listen(app);
  return { ctx, secretStore, taskRepository, app };
}

function bearer(token) {
  return { authorization: 'Bearer ' + token };
}

test('task routes: the five routes are registered with the expected method and path', () => {
  const app = createApp({ logger: SILENT_LOGGER });
  taskRoutes(app);
  const routes = app.listRoutes().map((route) => route.method + ' ' + route.path);
  for (const expected of [
    'POST ' + TASKS_PATH,
    'GET ' + TASKS_PATH,
    'GET ' + TASK_ID_PATH,
    'PATCH ' + TASK_ID_PATH,
    'DELETE ' + TASK_ID_PATH,
  ]) {
    assert.equal(routes.includes(expected), true, expected + ' must be registered');
  }
  for (const route of app.listRoutes()) {
    if (route.path.startsWith('/api/tasks')) {
      assert.equal(route.auth, true, route.method + ' ' + route.path + ' must be auth-guarded');
    }
  }
});

test('task routes: the router dispatches by method and extracts the :id segment', () => {
  const router = createRouter();
  const seen = [];
  router.addProtected('GET', TASK_ID_PATH, (ctx) => seen.push(ctx.params.id));
  const match = router.resolve('GET', '/api/tasks/abc-123');
  assert.equal(match.route.path, TASK_ID_PATH);
  assert.equal(match.params.id, 'abc-123');
  assert.equal(router.resolve('GET', '/api/tasks/abc/extra').route, null);
  assert.equal(router.resolve('POST', TASK_ID_PATH).route, null);
});

test('task routes: a missing token on every task route returns 401 UNAUTHORIZED and never touches the store', async () => {
  const { ctx, taskRepository } = await startApp();
  const calls = [];
  const originalCreate = taskRepository.createTask.bind(taskRepository);
  taskRepository.createTask = (input) => {
    calls.push(input);
    return originalCreate(input);
  };
  try {
    const cases = [
      { method: 'POST', url: TASKS_PATH, body: { title: 'x' } },
      { method: 'GET', url: TASKS_PATH },
      { method: 'GET', url: TASKS_PATH + '/some-id' },
      { method: 'PATCH', url: TASKS_PATH + '/some-id', body: { title: 'y' } },
      { method: 'DELETE', url: TASKS_PATH + '/some-id' },
    ];
    for (const entry of cases) {
      const res = await request(ctx, entry);
      assert.equal(res.status, 401, entry.method + ' ' + entry.url);
      assert.equal(res.body.error.code, 'UNAUTHORIZED');
      assert.match(String(res.headers.get('content-type')), /application\/json/);
    }
    assert.equal(calls.length, 0, 'no store write may happen without a resolved userId');
  } finally {
    await ctx.close();
  }
});

test('task routes: a tampered or truncated token returns 401 on every task route', async () => {
  const { ctx, secretStore } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    assert.equal(issued.ok, true);
    const last = issued.token[issued.token.length - 1];
    const tampered = issued.token.slice(0, -1) + (last === 'A' ? 'B' : 'A');
    const truncated = issued.token.slice(0, issued.token.length - 6);
    const cases = [
      { method: 'POST', url: TASKS_PATH, body: { title: 'x' } },
      { method: 'GET', url: TASKS_PATH },
      { method: 'GET', url: TASKS_PATH + '/some-id' },
      { method: 'PATCH', url: TASKS_PATH + '/some-id', body: { title: 'y' } },
      { method: 'DELETE', url: TASKS_PATH + '/some-id' },
    ];
    for (const token of [tampered, truncated]) {
      for (const entry of cases) {
        const res = await request(ctx, Object.assign({}, entry, { headers: bearer(token) }));
        assert.equal(res.status, 401, entry.method + ' ' + entry.url);
        assert.equal(res.body.error.code, 'UNAUTHORIZED');
      }
    }
  } finally {
    await ctx.close();
  }
});

test('task routes: a valid token reaches the handler and the created task is owner-scoped', async () => {
  const { ctx, secretStore, taskRepository } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const created = await request(ctx, {
      method: 'POST',
      url: TASKS_PATH,
      headers: bearer(issued.token),
      body: { title: '  write the report  ', dueDate: '2026-05-06' },
    });
    assert.equal(created.status, 201);
    assert.equal(created.body.task.title, 'write the report');
    assert.equal(created.body.task.dueDate, '2026-05-06');
    assert.equal(created.body.task.done, false);
    assert.equal(created.body.task.createdAt, created.body.task.updatedAt);
    assert.equal(Object.prototype.hasOwnProperty.call(created.body.task, 'ownerId'), false);

    const stored = taskRepository.listTasksByOwner(USER_ID);
    assert.equal(stored.length, 1);
    assert.equal(stored[0].ownerId, USER_ID);

    const listed = await request(ctx, { url: TASKS_PATH, headers: bearer(issued.token) });
    assert.equal(listed.status, 200);
    assert.equal(listed.body.items.length, 1);

    const single = await request(ctx, {
      url: TASKS_PATH + '/' + created.body.task.id,
      headers: bearer(issued.token),
    });
    assert.equal(single.status, 200);
    assert.equal(single.body.task.id, created.body.task.id);
  } finally {
    await ctx.close();
  }
});

test('task routes: a cross-user id is answered 404 NOT_FOUND and the task is untouched', async () => {
  const otherId = '99999999-8888-4777-8666-555555555555';
  const userRepository = multiUserRepository([
    { id: USER_ID, username: USERNAME },
    { id: otherId, username: 'Mallory_02' },
  ]);
  const { ctx, secretStore, taskRepository } = await startApp({ userRepository });
  try {
    const owner = issueToken({ subject: USER_ID }, { secretStore });
    const created = await request(ctx, {
      method: 'POST',
      url: TASKS_PATH,
      headers: bearer(owner.token),
      body: { title: 'private' },
    });
    const taskId = created.body.task.id;

    const intruder = issueToken({ subject: otherId }, { secretStore });
    const read = await request(ctx, { url: TASKS_PATH + '/' + taskId, headers: bearer(intruder.token) });
    assert.equal(read.status, 404);
    assert.equal(read.body.error.code, 'NOT_FOUND');

    const patched = await request(ctx, {
      method: 'PATCH',
      url: TASKS_PATH + '/' + taskId,
      headers: bearer(intruder.token),
      body: { title: 'hijacked' },
    });
    assert.equal(patched.status, 404);
    assert.equal(patched.body.error.code, 'NOT_FOUND');

    const removed = await request(ctx, {
      method: 'DELETE',
      url: TASKS_PATH + '/' + taskId,
      headers: bearer(intruder.token),
    });
    assert.equal(removed.status, 404);
    assert.equal(removed.body.error.code, 'NOT_FOUND');

    const stillThere = taskRepository.findTaskByIdAndOwner(taskId, USER_ID);
    assert.equal(stillThere.title, 'private');
  } finally {
    await ctx.close();
  }
});

test('task routes: the task routes do not collide with register, login, health or the home route', async () => {
  const dataDir = makeDataDir('collide');
  const secretStore = createSecretStore({ dataDir, env: {} });
  const userRepository = createUserRepository({ dataDir });
  const taskRepository = createTaskRepository({ dataDir });
  const app = createApp({ logger: SILENT_LOGGER, services: { userRepository, taskRepository, secretStore } });
  registerRoutes(app);
  loginRoutes(app);
  taskRoutes(app);
  const ctx = await listen(app);
  try {
    for (const healthPath of ['/healthz', '/health', '/ready']) {
      const res = await request(ctx, { url: healthPath });
      assert.equal(res.status, 200, healthPath);
      assert.deepEqual(res.body, { status: 'ok' });
    }

    const register = await request(ctx, {
      method: 'POST',
      url: '/api/register',
      body: { username: 'Bob_01', password: 'S3cret_password!' },
    });
    assert.equal(register.status, 201);
    assert.equal(typeof register.body.user.id, 'string');

    const login = await request(ctx, {
      method: 'POST',
      url: '/api/login',
      body: { username: 'Bob_01', password: 'S3cret_password!' },
    });
    assert.equal(login.status, 200);
    assert.equal(typeof login.body.token, 'string');

    const tasks = await request(ctx, { url: TASKS_PATH, headers: bearer(login.body.token) });
    assert.equal(tasks.status, 200);
    assert.deepEqual(tasks.body.items, []);

    const home = await request(ctx, { url: '/' });
    assert.equal(home.status, 404);
    assert.equal(home.body.error.code, 'NOT_FOUND');
  } finally {
    await ctx.close();
  }
});

test('task routes: an unmatched /api/tasks sub-path is a 404 NOT_FOUND, never a 5xx', async () => {
  const { ctx, secretStore } = await startApp();
  try {
    const issued = issueToken({ subject: USER_ID }, { secretStore });
    const res = await request(ctx, { url: TASKS_PATH + '/a/b/c', headers: bearer(issued.token) });
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
  } finally {
    await ctx.close();
  }
});
