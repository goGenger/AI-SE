'use strict';

/**
 * Focused unit tests for the task input validators (trust boundary).
 *
 * Covers the create/update validation rules of FR-3 / FR-5 (TR-04 / TR-05):
 *   - AC-15 title length measured in Unicode code points (100 pass, 101 reject)
 *   - AC-16 title trimmed, all-whitespace rejected
 *   - AC-17 CJK / emoji titles survive the trim unchanged, one code point each
 *   - AC-18 dueDate must be a real YYYY-MM-DD calendar date, else DATE_INVALID
 * plus the create-time dueDate default (omitted -> null).
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  TITLE_MIN_CODEPOINTS,
  TITLE_MAX_CODEPOINTS,
  countCodePoints,
  isValidDueDateString,
  assertTitle,
  assertDueDate,
  validateCreateTaskInput,
  validateUpdateTaskInput,
} = require('../src/validate.js');

const EMOJI = '\u{1F600}';
const CJK = '\u4e2d\u6587';

function thrown(fn) {
  try {
    fn();
  } catch (error) {
    return error;
  }
  return null;
}

test('validate AC-15: title length is counted in Unicode code points, not UTF-16 units', () => {
  assert.equal(TITLE_MIN_CODEPOINTS, 1);
  assert.equal(TITLE_MAX_CODEPOINTS, 100);
  assert.equal(assertTitle('a'.repeat(100)), 'a'.repeat(100));
  const hundredEmoji = EMOJI.repeat(100);
  assert.equal(hundredEmoji.length, 200);
  assert.equal(countCodePoints(hundredEmoji), 100);
  assert.equal(assertTitle(hundredEmoji), hundredEmoji);
  const tooLong = thrown(() => assertTitle('a'.repeat(101)));
  assert.equal(tooLong && tooLong.code, 'TITLE_INVALID');
  assert.equal(tooLong.status, 400);
  assert.equal(thrown(() => assertTitle(EMOJI.repeat(101))).code, 'TITLE_INVALID');
});

test('validate AC-16: the title is trimmed and an all-whitespace title is rejected', () => {
  assert.equal(assertTitle('  hello  '), 'hello');
  assert.equal(assertTitle('\t hello \n'), 'hello');
  assert.equal(assertTitle(' ' + 'a'.repeat(100) + ' '), 'a'.repeat(100));
  const blanks = ['', ' ', '   ', '\t', '\n', '\r\n', '\u3000', '\u00a0', ' \t \n '];
  for (const blank of blanks) {
    const error = thrown(() => assertTitle(blank));
    assert.equal(error && error.code, 'TITLE_INVALID', JSON.stringify(blank));
    assert.equal(error.status, 400);
  }
  assert.equal(thrown(() => assertTitle(undefined)).code, 'TITLE_INVALID');
  assert.equal(thrown(() => assertTitle(42)).code, 'TITLE_INVALID');
});

test('validate AC-17: CJK and emoji titles round-trip unchanged after trimming', () => {
  const title = CJK + ' ' + EMOJI + EMOJI;
  assert.equal(countCodePoints(CJK), 2);
  assert.equal(countCodePoints(EMOJI), 1);
  assert.equal(assertTitle('  ' + title + '\t'), title);
  const created = validateCreateTaskInput({ title: '  ' + title + '  ' });
  assert.equal(created.title, title);
});

test('validate AC-18: dueDate accepts only a real YYYY-MM-DD calendar date', () => {
  for (const good of ['2026-01-01', '2024-02-29', '2000-02-29', '1999-12-31', '2026-12-31']) {
    assert.equal(isValidDueDateString(good), true, good);
    assert.equal(assertDueDate(good), good);
  }
  const bad = [
    '2026-02-30',
    '2026-13-01',
    '2026-00-10',
    '2026-01-00',
    '2025-02-29',
    '2026-04-31',
    '2026-1-01',
    '2026-01-1',
    '2026/01/01',
    '01-01-2026',
    '2026-01-01T00:00:00Z',
    'not-a-date',
    '',
  ];
  for (const value of bad) {
    assert.equal(isValidDueDateString(value), false, JSON.stringify(value));
    const error = thrown(() => assertDueDate(value));
    assert.equal(error && error.code, 'DATE_INVALID', JSON.stringify(value));
    assert.equal(error.status, 400);
  }
  for (const wrongType of [null, undefined, 20260101, true, {}]) {
    assert.equal(isValidDueDateString(wrongType), false, String(wrongType));
  }
});

test('validate AC-14/AC-18: omitted create dueDate becomes null, provided value is echoed', () => {
  assert.deepEqual(validateCreateTaskInput({ title: 'task' }), { title: 'task', dueDate: null });
  assert.equal(validateCreateTaskInput({ title: 'task', dueDate: null }).dueDate, null);
  assert.equal(validateCreateTaskInput({ title: 'task', dueDate: '2026-05-06' }).dueDate, '2026-05-06');
  assert.equal(thrown(() => validateCreateTaskInput({ title: 'task', dueDate: '2026-02-30' })).code, 'DATE_INVALID');
  assert.equal(thrown(() => validateCreateTaskInput({ title: '   ' })).code, 'TITLE_INVALID');
  assert.equal(validateUpdateTaskInput({ title: '  patched  ' }).title, 'patched');
  assert.equal(thrown(() => validateUpdateTaskInput({ dueDate: '2026-13-01' })).code, 'DATE_INVALID');
});
