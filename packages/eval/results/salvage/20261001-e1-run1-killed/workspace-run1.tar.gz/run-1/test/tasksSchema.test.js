'use strict';

/**
 * Database tests for the tasks storage model (slice S2-T03).
 *
 * Covers the declarative schema, the owner-scoped access interface and the
 * migration/persistence behaviour of the DATA_DIR tasks collection:
 *   - the tasks columns (id primary key, owner_id NOT NULL, title NOT NULL,
 *     due_date nullable, done default false, created_at/updated_at ISO 8601)
 *   - the owner_id retrieval path (idx_tasks_owner_id) and the five owner-scoped
 *     operations insertTask / listTasksByOwner / findTaskByIdAndOwner /
 *     updateTaskByIdAndOwner / deleteTaskByIdAndOwner
 *   - the absence of any query form that omits owner_id
 *   - updated_at refreshed on PATCH, equal to created_at on insert, and rows
 *     surviving a process restart because they live under DATA_DIR
 *   - the forward-only, idempotent migration of the tasks collection
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const schema = require('../src/store/tasksSchema.js');
const migration = require('../src/store/tasksMigration.js');
const { createTaskRepository } = require('../src/store/taskRepo.js');

const OWNER_A = '11111111-2222-4333-8444-555555555555';
const OWNER_B = '99999999-8888-4777-8666-555555555555';
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-db-' + (name || 'test') + '-'));
}

function columnByName(name) {
  return schema.COLUMNS.find((column) => column.name === name);
}

test('db AC: the tasks table declares id as the UUID primary key', () => {
  assert.equal(schema.TASKS_TABLE, 'tasks');
  assert.equal(schema.TASKS_FILE_NAME, 'tasks.json');
  assert.equal(schema.PRIMARY_KEY_COLUMN, 'id');
  const id = columnByName('id');
  assert.equal(id.primaryKey, true);
  assert.equal(id.nullable, false);
  assert.equal(id.type, 'uuid');
  const pk = schema.INDEXES.find((index) => index.kind === 'primary-key');
  assert.deepEqual(pk.columns, ['id']);
  assert.equal(pk.unique, true);
});

test('db AC: owner_id is NOT NULL, references users.id and is the owner index', () => {
  const owner = columnByName('owner_id');
  assert.equal(owner.nullable, false);
  assert.equal(owner.type, 'uuid');
  assert.equal(owner.index, 'idx_tasks_owner_id');
  assert.equal(owner.references, 'users.id');
  const index = schema.INDEXES.find((entry) => entry.name === 'idx_tasks_owner_id');
  assert.deepEqual(index.columns, ['owner_id']);
  assert.equal(index.unique, false);
  assert.equal(index.kind, 'secondary');
});

test('db AC: title NOT NULL, due_date NULL and done default false', () => {
  assert.equal(columnByName('title').nullable, false);
  assert.equal(columnByName('due_date').nullable, true);
  assert.equal(columnByName('due_date').defaultValue, null);
  assert.equal(columnByName('done').nullable, false);
  assert.equal(columnByName('done').defaultValue, false);
  assert.equal(columnByName('done').type, 'boolean');
});

test('db AC: created_at and updated_at are NOT NULL ISO 8601 columns', () => {
  assert.equal(columnByName('created_at').nullable, false);
  assert.equal(columnByName('updated_at').nullable, false);
  assert.equal(schema.isIsoTimestamp('2026-05-06T07:08:09.123Z'), true);
  assert.equal(schema.isIsoTimestamp('2026-05-06'), false);
  assert.equal(schema.isIsoTimestamp('2026-05-06T07:08:09Z'), false);
  assert.equal(schema.isIsoTimestamp(''), false);
  assert.equal(schema.isIsoTimestamp(null), false);
});

test('db AC: the declared column order is the persisted model order', () => {
  assert.deepEqual(schema.columnNames(), [
    'id',
    'owner_id',
    'title',
    'due_date',
    'done',
    'created_at',
    'updated_at',
  ]);
  assert.equal(schema.columnDefinition('owner_id').nullable, false);
  assert.equal(schema.columnDefinition('nope'), null);
});

test('db AC: normalise backs the model and rejects a record without owner_id', () => {
  const stamped = schema.normalizeTaskRecord(
    { ownerId: OWNER_A, title: '  write it  ' },
    { now: '2026-05-06T07:08:09.123Z' }
  );
  assert.equal(stamped.ok, true);
  assert.match(stamped.record.id, UUID_PATTERN);
  assert.equal(stamped.record.ownerId, OWNER_A);
  assert.equal(stamped.record.title, 'write it');
  assert.equal(stamped.record.dueDate, null);
  assert.equal(stamped.record.done, false);
  assert.equal(stamped.record.createdAt, '2026-05-06T07:08:09.123Z');
  assert.equal(stamped.record.updatedAt, stamped.record.createdAt);
  assert.deepEqual(stamped.repaired.sort(), ['createdAt', 'done', 'id', 'updatedAt']);

  const ownerless = schema.normalizeTaskRecord({ title: 'no owner' });
  assert.equal(ownerless.ok, false);
  assert.equal(ownerless.record, null);
  assert.equal(ownerless.problems.some((problem) => problem.includes('ownerId')), true);

  const blankTitle = schema.normalizeTaskRecord({ ownerId: OWNER_A, title: '   ' });
  assert.equal(blankTitle.ok, false);
  const badDate = schema.normalizeTaskRecord({ ownerId: OWNER_A, title: 'x', dueDate: '2026-02-30' });
  assert.equal(badDate.ok, false);
  const longTitle = schema.normalizeTaskRecord({ ownerId: OWNER_A, title: 'a'.repeat(101) });
  assert.equal(longTitle.ok, false);
});

test('db AC: strict validation requires every column and keeps emoji as one code point', () => {
  const good = {
    id: 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee',
    ownerId: OWNER_A,
    title: 'x',
    dueDate: null,
    done: false,
    createdAt: '2026-05-06T07:08:09.123Z',
    updatedAt: '2026-05-06T07:08:09.123Z',
  };
  assert.equal(schema.validateTaskRecord(good).ok, true);
  assert.equal(schema.validateTaskRecord(Object.assign({}, good, { dueDate: '2026-01-01' })).ok, true);
  assert.equal(schema.validateTaskRecord(Object.assign({}, good, { done: 'yes' })).ok, false);
  assert.equal(schema.validateTaskRecord(Object.assign({}, good, { updatedAt: 'soon' })).ok, false);
  assert.equal(schema.validateTaskRecord(Object.assign({}, good, { ownerId: '' })).ok, false);

  const emoji = '\u{1F600}';
  assert.equal(schema.countCodePoints(emoji), 1);
  assert.equal(schema.countCodePoints(emoji.repeat(100)), 100);
  const hundred = schema.normalizeTaskRecord({ ownerId: OWNER_A, title: emoji.repeat(100) });
  assert.equal(hundred.ok, true);
  const ohOne = schema.normalizeTaskRecord({ ownerId: OWNER_A, title: emoji.repeat(101) });
  assert.equal(ohOne.ok, false);
});

test('db AC: the column view maps snake_case columns to the persisted camelCase fields', () => {
  const record = {
    id: 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee',
    ownerId: OWNER_B,
    title: 'deploy',
    dueDate: '2026-05-06',
    done: true,
    createdAt: '2026-05-06T07:08:09.123Z',
    updatedAt: '2026-05-07T07:08:09.123Z',
  };
  const view = schema.toColumnView(record);
  assert.deepEqual(Object.keys(view), schema.columnNames());
  assert.equal(view.owner_id, OWNER_B);
  assert.equal(view.due_date, '2026-05-06');
  assert.equal(view.created_at, record.createdAt);
  const back = schema.fromColumnView(view);
  assert.equal(back.ok, true);
  assert.deepEqual(back.record, record);
  assert.equal(schema.toColumnView(null), null);
  assert.equal(schema.fromColumnView(null).ok, false);
});

test('db AC: describeSchema publishes columns, indexes and the owner retrieval path', () => {
  const described = schema.describeSchema();
  assert.equal(described.table, 'tasks');
  assert.equal(described.primaryKey, 'id');
  assert.equal(described.ownerColumn, 'owner_id');
  assert.equal(described.columns.length, 7);
  assert.equal(described.retrievalPath.key, 'owner_id');
  assert.equal(described.retrievalPath.index, 'idx_tasks_owner_id');
  assert.equal(described.retrievalPath.ownerlessQueriesAllowed, false);
  assert.equal(described.operations.length, 5);
  for (const operation of described.operations) {
    assert.equal(operation.ownerRequired, true);
    assert.equal(operation.ownerArgument, 'ownerId');
  }
  assert.equal(described.forbiddenQueryForms.includes('findById(id)'), true);
  assert.equal(schema.FIELD_TO_COLUMN.ownerId, 'owner_id');
  assert.equal(JSON.stringify(described).includes('findById'), true);
});

test('db AC: the five owner-scoped operations are declared with an ownerId argument', () => {
  const names = schema.OWNER_SCOPED_OPERATIONS.map((operation) => operation.name);
  assert.deepEqual(names, [
    'insertTask',
    'listTasksByOwner',
    'findTaskByIdAndOwner',
    'updateTaskByIdAndOwner',
    'deleteTaskByIdAndOwner',
  ]);
  assert.deepEqual(schema.RETRIEVAL_PATH.operations, names);
  for (const operation of schema.OWNER_SCOPED_OPERATIONS) {
    assert.equal(operation.ownerRequired, true);
    assert.equal(operation.ownerArgument, 'ownerId');
    assert.equal(operation.signature.includes('ownerId'), true);
  }
});

test('db AC: the repository exposes no query form that omits ownerId', () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('surface') });
  for (const forbidden of ['findById', 'findTaskById', 'listTasks', 'searchTasks', 'updateTaskById', 'deleteTaskById', 'deleteAllTasks', 'findTaskByIdOnly']) {
    assert.equal(typeof repo[forbidden], 'undefined', forbidden + ' must not exist');
  }
  for (const required of ['insertTask', 'listTasksByOwner', 'findTaskByIdAndOwner', 'updateTaskByIdAndOwner', 'deleteTaskByIdAndOwner']) {
    assert.equal(typeof repo[required], 'function', required + ' must be owner-scoped');
  }
  assert.equal(schema.RETRIEVAL_PATH.ownerlessQueriesAllowed, false);
  assert.equal(schema.FORBIDDEN_QUERY_FORMS.length > 0, true);
});

test('db AC: insertTask stores an owner-scoped row with done false and equal timestamps', async () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('insert') });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: '  first task  ', dueDate: '2026-05-06' });
  assert.equal(created.ok, true);
  const task = created.task;
  assert.match(task.id, UUID_PATTERN);
  assert.equal(task.title, 'first task');
  assert.equal(task.dueDate, '2026-05-06');
  assert.equal(task.done, false);
  assert.equal(task.createdAt, task.updatedAt);
  assert.equal(schema.isIsoTimestamp(task.createdAt), true);

  const record = repo.findTaskByIdAndOwner(task.id, OWNER_A);
  assert.equal(record.ownerId, OWNER_A);
  assert.deepEqual(schema.validateTaskRecord(record).ok, true);
  const rejected = await repo.insertTask({ title: 'no owner' });
  assert.equal(rejected.ok, false);
});

test('db AC: listTasksByOwner returns only that owner rows and search stays scoped', async () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('list') });
  await repo.insertTask({ ownerId: OWNER_A, title: 'alpha' });
  await repo.insertTask({ ownerId: OWNER_A, title: 'beta' });
  await repo.insertTask({ ownerId: OWNER_B, title: 'gamma' });
  const mine = repo.listTasksByOwner(OWNER_A);
  assert.equal(mine.length, 2);
  assert.equal(mine.every((row) => row.ownerId === OWNER_A), true);
  assert.deepEqual(repo.listTasksByOwner(OWNER_B).map((row) => row.title), ['gamma']);
  assert.deepEqual(repo.listTasksByOwner('nobody'), []);
  assert.deepEqual(repo.listTasksByOwner(''), []);
  assert.equal(repo.listByOwner(OWNER_A).length, 2);
});

test('db AC: findTaskByIdAndOwner misses for a wrong or empty owner', async () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('find') });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'private' });
  const id = created.task.id;
  assert.equal(repo.findTaskByIdAndOwner(id, OWNER_A).id, id);
  assert.equal(repo.findTaskByIdAndOwner(id, OWNER_B), null);
  assert.equal(repo.findTaskByIdAndOwner(id, ''), null);
  assert.equal(repo.findTaskByIdAndOwner('no-such-id', OWNER_A), null);
  assert.equal(repo.findByOwner(OWNER_A, id).id, id);
  assert.equal(repo.findTaskByOwnerAndId(OWNER_A, id).id, id);
});

test('db AC: updateTaskByIdAndOwner refreshes updatedAt and is owner-scoped', async () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('update') });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'before' });
  const id = created.task.id;
  await new Promise((resolve) => setTimeout(resolve, 5));
  const updated = await repo.updateTaskByIdAndOwner(id, OWNER_A, { title: '  after  ', done: true });
  assert.equal(updated.ok, true);
  assert.equal(updated.task.title, 'after');
  assert.equal(updated.task.done, true);
  assert.equal(updated.task.createdAt, created.task.createdAt);
  assert.equal(updated.task.updatedAt === updated.task.createdAt, false);
  assert.equal(schema.isIsoTimestamp(updated.task.updatedAt), true);

  const crossUser = await repo.updateTaskByIdAndOwner(id, OWNER_B, { title: 'hijack' });
  assert.equal(crossUser.ok, false);
  assert.equal(crossUser.code, 'NOT_FOUND');
  assert.equal(repo.findTaskByIdAndOwner(id, OWNER_A).title, 'after');

  const badPatch = await repo.updateTaskByIdAndOwner(id, OWNER_A, { title: '   ' });
  assert.equal(badPatch.ok, false);
  assert.equal(badPatch.code, 'TITLE_INVALID');
});

test('db AC: deleteTaskByIdAndOwner removes the row and is owner-scoped', async () => {
  const repo = createTaskRepository({ dataDir: makeDataDir('delete') });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'doomed' });
  const id = created.task.id;
  const crossUser = await repo.deleteTaskByIdAndOwner(id, OWNER_B);
  assert.equal(crossUser.ok, false);
  assert.equal(crossUser.code, 'NOT_FOUND');
  assert.equal(repo.listTasksByOwner(OWNER_A).length, 1);

  const removed = await repo.deleteTaskByIdAndOwner(id, OWNER_A);
  assert.equal(removed.ok, true);
  assert.deepEqual(repo.listTasksByOwner(OWNER_A), []);
  const again = await repo.deleteTaskByIdAndOwner(id, OWNER_A);
  assert.equal(again.ok, false);
  assert.equal(again.code, 'NOT_FOUND');
});

test('db AC: tasks persist under DATA_DIR and survive a repository restart', async () => {
  const dataDir = makeDataDir('persist');
  const repo = createTaskRepository({ dataDir });
  const created = await repo.insertTask({ ownerId: OWNER_A, title: 'survives restart', dueDate: '2026-12-31' });
  await repo.waitForIdle();

  const filePath = path.join(dataDir, 'tasks.json');
  assert.equal(fs.existsSync(filePath), true);
  const stored = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  assert.equal(Array.isArray(stored), true);
  assert.equal(stored.length, 1);
  assert.equal(stored[0].ownerId, OWNER_A);
  assert.equal(stored[0].title, 'survives restart');
  assert.equal(stored[0].done, false);
  assert.equal(stored[0].dueDate, '2026-12-31');
  assert.equal(Object.prototype.hasOwnProperty.call(stored[0], 'owner_id'), false);
  assert.equal(schema.validateTaskRecord(stored[0]).ok, true);

  const reopened = createTaskRepository({ dataDir });
  assert.equal(reopened.size(), 1);
  assert.equal(reopened.findTaskByIdAndOwner(created.task.id, OWNER_A).title, 'survives restart');
  assert.deepEqual(reopened.listTasksByOwner(OWNER_B), []);
  assert.equal(reopened.reload(), 1);
});

test('db AC: migration creates the owner-scoped collection shape and drops owner-less rows', () => {
  const raw = [
    { ownerId: OWNER_A, title: '  keep me  ' },
    { title: 'no owner at all' },
    { owner_id: OWNER_B, title: 'legacy snake case', done: true },
    null,
  ];
  const result = migration.runTasksMigrations(raw, { fromVersion: 0 });
  assert.equal(result.version, schema.SCHEMA_VERSION);
  assert.deepEqual(result.applied.map((entry) => entry.version), [1, 2]);
  assert.equal(result.collection.length, 2);
  const kept = result.collection[0];
  assert.match(kept.id, UUID_PATTERN);
  assert.equal(kept.ownerId, OWNER_A);
  assert.equal(kept.title, 'keep me');
  assert.equal(kept.dueDate, null);
  assert.equal(kept.done, false);
  assert.equal(kept.createdAt, kept.updatedAt);
  assert.equal(result.collection[1].ownerId, OWNER_B);
  assert.equal(result.collection[1].done, true);
  assert.equal(result.rejected.length, 2);
  assert.equal(result.rejected.every((entry) => entry.reason.includes('ownerId')), true);
});

test('db AC: migration is idempotent and a non-array payload becomes an empty collection', () => {
  const once = migration.runTasksMigrations(
    [{ ownerId: OWNER_A, title: 'steady' }],
    { fromVersion: 0, now: '2026-05-06T07:08:09.123Z' }
  );
  const twice = migration.runTasksMigrations(once.collection, { fromVersion: 0, now: '2026-05-06T07:08:09.123Z' });
  assert.deepEqual(twice.collection, once.collection);
  assert.equal(twice.applied.every((entry) => entry.changedRows === 0), true);
  assert.equal(migration.isMigrated(once.collection), true);
  assert.equal(migration.isMigrated([{ title: 'owner-less' }]), false);

  const garbage = migration.runTasksMigrations('not-an-array', { fromVersion: 0 });
  assert.deepEqual(garbage.collection, []);
  assert.equal(garbage.rejected.length, 0);
});

test('db AC: migrateTasksStore rewrites the DATA_DIR file atomically and skips up-to-date stores', async () => {
  const dataDir = makeDataDir('migrate');
  const filePath = path.join(dataDir, 'tasks.json');
  fs.writeFileSync(
    filePath,
    JSON.stringify([{ ownerId: OWNER_A, title: 'legacy row' }, { title: 'orphan' }], null, 2) + '\n',
    'utf8'
  );

  const applied = await migration.migrateTasksStore({ dataDir });
  assert.equal(applied.applied.length, 2);
  assert.equal(applied.rows, 1);
  assert.equal(applied.rejected.length, 1);
  assert.equal(applied.persisted, true);

  const stored = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  assert.equal(stored.length, 1);
  assert.equal(stored[0].ownerId, OWNER_A);
  assert.equal(stored[0].done, false);
  assert.equal(schema.validateTaskRecord(stored[0]).ok, true);
  const leftovers = fs.readdirSync(dataDir).filter((name) => name.endsWith('.tmp'));
  assert.deepEqual(leftovers, []);

  const again = await migration.migrateTasksStore({ dataDir });
  assert.equal(again.changed, false);
  assert.equal(again.applied.every((entry) => entry.changedRows === 0), true);
  const skipped = await migration.migrateTasksStore({ dataDir, fromVersion: schema.SCHEMA_VERSION });
  assert.deepEqual(skipped.applied, []);
  assert.equal(skipped.persisted, false);
  assert.equal(schema.SCHEMA_VERSION, migration.SCHEMA_VERSION);
});

test('db AC: a repository opened over a fresh DATA_DIR starts from an empty migratable collection', async () => {
  const dataDir = makeDataDir('fresh');
  const repo = createTaskRepository({ dataDir });
  assert.equal(repo.size(), 0);
  const report = await migration.migrateTasksStore({ dataDir, persist: false });
  assert.equal(report.rows, 0);
  assert.equal(report.rejected.length, 0);
  assert.equal(migration.isMigrated([]), true);
  assert.equal(schema.TASKS_FILE_NAME, migration.SCHEMA_VERSION === undefined ? '' : 'tasks.json');
});
