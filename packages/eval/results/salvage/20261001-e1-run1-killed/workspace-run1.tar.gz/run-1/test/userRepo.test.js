'use strict';

/**
 * User repository tests: record model, case-insensitive uniqueness, the
 * check-then-insert critical section and the absence of plaintext on disk.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { createUserRepository, UserRepository, normalizeUsername, extractCredential, toPublicUser } =
  require('../src/store/userRepo.js');
const { hashPassword, verifyPassword, toPasswordFields } = require('../src/auth/password.js');

const FAST_PARAMS = Object.freeze({ N: 1024, r: 8, p: 1, keylen: 32 });
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

function makeDataDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'taskboard-users-' + (name || 'test') + '-'));
}

function makeHasher() {
  return {
    hash: (pwd) => hashPassword(pwd, { params: FAST_PARAMS }),
  };
}

function readUsersFile(dataDir) {
  return fs.readFileSync(path.join(dataDir, 'users.json'), 'utf8');
}

async function credentialFor(password) {
  return toPasswordFields(await hashPassword(password, { params: FAST_PARAMS }));
}

test('userRepo: a new user gets a UUID id, the original-case username and an ISO createdAt', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('model'), hasher: makeHasher() });
  const result = await repo.createUser({ username: 'Alice_01', password: 'Zq7-canary-alpha' });
  assert.equal(result.ok, true);
  assert.equal(result.user.username, 'Alice_01');
  assert.match(result.user.id, UUID_PATTERN);
  assert.match(result.user.createdAt, ISO_PATTERN);
  const record = repo.findByUsername('alice_01');
  assert.equal(record.username, 'Alice_01');
  assert.equal(record.usernameLower, 'alice_01');
  assert.equal(record.id, result.user.id);
  assert.equal(JSON.stringify(result.user).includes('password'), false);
});

test('userRepo: username lookup ignores case and the existence check agrees', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('lookup'), hasher: makeHasher() });
  await repo.createUser({ username: 'CaseUser', password: 'Zq7-canary-bravo' });
  assert.equal(repo.existsByUsername('caseuser'), true);
  assert.equal(repo.existsByUsername('CASEUSER'), true);
  assert.equal(repo.existsByUsername('missinguser'), false);
  assert.equal(repo.findByUsername('cAsEuSeR').username, 'CaseUser');
  assert.equal(repo.findByUsername('nobody'), null);
  assert.equal(repo.findByUsername(''), null);
  assert.equal(repo.existsByUsername(''), false);
});

test('userRepo: creating the same username again returns USERNAME_TAKEN without throwing', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('dupe-exact'), hasher: makeHasher() });
  const first = await repo.createUser({ username: 'Duplicate', password: 'Zq7-canary-charlie' });
  assert.equal(first.ok, true);
  const second = await repo.createUser({ username: 'Duplicate', password: 'Zq7-canary-delta' });
  assert.equal(second.ok, false);
  assert.equal(second.code, 'USERNAME_TAKEN');
  assert.equal(repo.size(), 1);
});

test('userRepo: a case-only conflict returns USERNAME_TAKEN (Alice then alice)', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('dupe-case'), hasher: makeHasher() });
  const first = await repo.createUser({ username: 'Alice', password: 'Zq7-canary-echo' });
  assert.equal(first.ok, true);
  const second = await repo.createUser({ username: 'alice', password: 'Zq7-canary-foxtrot' });
  assert.equal(second.ok, false);
  assert.equal(second.code, 'USERNAME_TAKEN');
  assert.equal(repo.size(), 1);
  assert.equal(repo.findByUsername('ALICE').username, 'Alice');
});

test('userRepo: invalid usernames and incomplete credentials are rejected as VALIDATION_ERROR', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('invalid'), hasher: makeHasher() });
  for (const username of ['ab', 'a b', 'has-dash', 'user.name', 'user!', 'x'.repeat(33), '', null, 42, 'Bob\u00e9']) {
    const result = await repo.createUser({ username, password: 'Zq7-canary-golf' });
    assert.equal(result.ok, false, 'username ' + String(username) + ' must be rejected');
    assert.equal(result.code, 'VALIDATION_ERROR');
  }
  const noCredential = await repo.createUser({ username: 'ValidName' });
  assert.equal(noCredential.ok, false);
  assert.equal(noCredential.code, 'VALIDATION_ERROR');
  assert.equal(repo.size(), 0);
});

test('userRepo: createUser validates a raw credential object at the trust boundary', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('credential') });
  const credential = await credentialFor('Zq7-canary-hotel');
  const good = await repo.createUser({ username: 'BoundaryUser', credential });
  assert.equal(good.ok, true);
  const partial = await repo.createUser({ username: 'PartialUser', credential: { algo: 'scrypt', salt: 'abc' } });
  assert.equal(partial.ok, false);
  assert.equal(partial.code, 'VALIDATION_ERROR');
  assert.equal(repo.size(), 1);
  assert.equal(extractCredential({ algo: 'scrypt', salt: 's', params: 'p', hash: 'h' }).password_algo, 'scrypt');
});

test('userRepo: five concurrent registrations of one username yield exactly one success', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('concurrent'), hasher: makeHasher() });
  const attempts = [];
  for (let index = 0; index < 5; index += 1) {
    attempts.push(repo.createUser({ username: 'Race_User', password: 'Zq7-canary-india-' + index }));
  }
  const results = await Promise.all(attempts);
  const successes = results.filter((result) => result.ok === true);
  const conflicts = results.filter((result) => result.ok === false && result.code === 'USERNAME_TAKEN');
  assert.equal(successes.length, 1);
  assert.equal(conflicts.length, 4);
  assert.equal(results.every((result) => result.ok === true || result.code === 'USERNAME_TAKEN'), true);
  assert.equal(repo.size(), 1);
  assert.equal(repo.stats().uniqueKeys, 1);
});

test('userRepo: concurrent case-variant registrations produce exactly one record', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('concurrent-case'), hasher: makeHasher() });
  const names = ['ConcurrentOne', 'concurrentone', 'CONCURRENTONE', 'ConcurrentONE', 'conCurrentOne'];
  const results = await Promise.all(
    names.map((username, index) => repo.createUser({ username, password: 'Zq7-canary-juliet-' + index }))
  );
  assert.equal(results.filter((result) => result.ok === true).length, 1);
  assert.equal(results.filter((result) => result.code === 'USERNAME_TAKEN').length, names.length - 1);
  assert.equal(repo.size(), 1);
});

test('userRepo: the persisted record carries algo/salt/params/hash and no plaintext password', async () => {
  const dataDir = makeDataDir('on-disk');
  const plaintext = 'Zq7-plaintext-canary-999';
  const repo = createUserRepository({ dataDir, hasher: makeHasher() });
  const result = await repo.createUser({ username: 'DiskUser', password: plaintext });
  assert.equal(result.ok, true);

  const filePath = path.join(dataDir, 'users.json');
  const raw = fs.readFileSync(filePath, 'utf8');
  assert.equal(raw.includes(plaintext), false);
  assert.equal(raw.includes('"password":'), false);
  assert.equal(raw.toLowerCase().includes('plaintext'), false);

  const stored = JSON.parse(raw);
  assert.equal(Array.isArray(stored), true);
  assert.equal(stored.length, 1);
  const record = stored[0];
  assert.equal(record.username, 'DiskUser');
  assert.equal(record.usernameLower, 'diskuser');
  assert.equal(record.password_algo, 'scrypt');
  assert.equal(typeof record.password_salt, 'string');
  assert.equal(typeof record.password_params, 'string');
  assert.equal(typeof record.password_hash, 'string');
  assert.equal(record.password_salt.length > 0, true);
  assert.equal(record.password_hash.length > 0, true);
  assert.match(record.password_params, /^scrypt\$N=\d+,r=\d+,p=\d+,keylen=\d+$/);

  const reread = createUserRepository({ dataDir, hasher: makeHasher() });
  assert.equal(reread.size(), 1);
  assert.equal(reread.existsByUsername('diskuser'), true);
});

test('userRepo: reload from disk keeps users intended to be verified by the password module', async () => {
  const dataDir = makeDataDir('reload');
  const repo = createUserRepository({ dataDir, hasher: makeHasher() });
  await repo.createUser({ username: 'ReloadUser', password: 'Zq7-canary-kilo' });
  const reopened = createUserRepository({ dataDir, hasher: makeHasher() });
  const record = reopened.findRecordForAuth('reloaduser');
  assert.equal(record.username, 'ReloadUser');
  assert.equal(await verifyPassword('Zq7-canary-kilo', record), true);
  assert.equal(await verifyPassword('wrong-password-x', record), false);
});

test('userRepo: each stored user has an independent salt and digest', async () => {
  const dataDir = makeDataDir('salts');
  const repo = createUserRepository({ dataDir, hasher: makeHasher() });
  await repo.createUser({ username: 'SaltUserOne', password: 'Zq7-same-password' });
  await repo.createUser({ username: 'SaltUserTwo', password: 'Zq7-same-password' });
  const stored = JSON.parse(readUsersFile(dataDir));
  const [first, second] = stored;
  assert.notEqual(first.password_salt, second.password_salt);
  assert.notEqual(first.password_hash, second.password_hash);
  assert.equal(crypto.timingSafeEqual !== undefined, true);
});

test('userRepo: a stray plaintext key is stripped before the record is written', async () => {
  const dataDir = makeDataDir('sanitize');
  const repo = createUserRepository({ dataDir });
  const credential = await credentialFor('Zq7-canary-lima');
  const dirty = Object.assign({ password: 'Zq7-leaked-value' }, credential);
  const result = await repo.createUser({ username: 'SanitizedUser', credential: dirty });
  assert.equal(result.ok, true);
  assert.equal(Object.prototype.hasOwnProperty.call(result.record, 'password'), false);
  const raw = readUsersFile(dataDir);
  assert.equal(raw.includes('Zq7-leaked-value'), false);
});

test('userRepo: lookups and serialisation never expose credential material', async () => {
  const repo = createUserRepository({ dataDir: makeDataDir('exposure'), hasher: makeHasher() });
  await repo.createUser({ username: 'ExposureUser', password: 'Zq7-canary-mike' });
  const listed = repo.listPublicUsers();
  assert.deepEqual(Object.keys(listed[0]).sort(), ['createdAt', 'id', 'username']);
  assert.equal(JSON.stringify(repo).includes('password_hash'), false);
  assert.equal(JSON.stringify(repo.stats()).includes('password_hash'), false);
  assert.equal(toPublicUser(null), null);
  assert.equal(normalizeUsername('MiXeD'), 'mixed');
  assert.equal(UserRepository.name, 'UserRepository');
  assert.equal(typeof repo.waitForIdle, 'function');
});
