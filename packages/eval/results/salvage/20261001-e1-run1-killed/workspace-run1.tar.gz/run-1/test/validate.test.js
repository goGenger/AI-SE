'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  USERNAME_PATTERN,
  PASSWORD_MIN_LENGTH,
  PASSWORD_MAX_LENGTH,
  ALLOWED_REGISTER_FIELDS,
  normalizeUsername,
  isValidUsername,
  isValidPassword,
  parseJsonText,
  parseJsonBody,
  assertAllowedFields,
  validateCredentialsBody,
  validateRegisterInput,
  validateLoginInput,
} = require('../src/validate.js');
const { AppError } = require('../src/errors/errorEnvelope.js');
const { handleError, errorFor, API_ERROR_CODES } = require('../src/errors/index.js');
const { sendError } = require('../src/http/respond.js');
const { makeFakeRequest, makeFakeResponse } = require('./helpers.js');

const PW8 = 'p'.repeat(8);
const PW72 = 'p'.repeat(72);
const PW73 = 'p'.repeat(73);
const PW7 = 'p'.repeat(7);
const CJK = String.fromCharCode(0x7528, 0x6237, 0x5f, 0x78);

function thrown(fn) {
  try {
    fn();
  } catch (error) {
    return error;
  }
  return null;
}

test('validate AC-07: usernames must match ^[A-Za-z0-9_]{3,32}$', () => {
  assert.equal(USERNAME_PATTERN.source, '^[A-Za-z0-9_]{3,32}$');
  for (const good of ['abc', 'Alice', 'user_1', 'A'.repeat(32)]) {
    assert.equal(isValidUsername(good), true, good);
  }
  const bad = ['ab', '', 'a b', 'ab c', 'Alice!', 'z'.repeat(33), CJK, 'name@x', 'under-score!'];
  for (const value of bad) {
    assert.equal(isValidUsername(value), false, JSON.stringify(value));
  }
  assert.equal(isValidUsername(1234), false);
});

test('validate AC-08: passwords must be 8-72 characters inclusive', () => {
  assert.equal(PASSWORD_MIN_LENGTH, 8);
  assert.equal(PASSWORD_MAX_LENGTH, 72);
  assert.equal(isValidPassword(PW7), false);
  assert.equal(isValidPassword(PW8), true);
  assert.equal(isValidPassword(PW72), true);
  assert.equal(isValidPassword(PW73), false);
  assert.equal(isValidPassword(12345678), false);
});

test('validate: username normalisation lowercases the uniqueness key', () => {
  assert.equal(normalizeUsername('Alice'), 'alice');
  assert.equal(normalizeUsername('ALICE_99'), 'alice_99');
  assert.equal(normalizeUsername(undefined), '');
});

test('validate: malformed JSON is a 400 VALIDATION_ERROR, never an uncaught SyntaxError', () => {
  const error = thrown(() => parseJsonText('{not json'));
  assert.equal(AppError.isAppError(error), true);
  assert.equal(error.code, 'VALIDATION_ERROR');
  assert.equal(error.status, 400);
  assert.equal(/SyntaxError|at /.test(error.message), false);
  const wrongType = thrown(() => parseJsonText('[1,2,3]'));
  assert.equal(wrongType.code, 'VALIDATION_ERROR');
  assert.equal(wrongType.status, 400);
  assert.equal(typeof parseJsonText(''), 'object');
});

test('validate AC: a body field other than username/password is UNKNOWN_FIELD, never ignored', () => {
  assert.deepEqual(ALLOWED_REGISTER_FIELDS, ['username', 'password']);
  const direct = thrown(() => assertAllowedFields({ username: 'alice', password: PW8, extra: 1 }, ALLOWED_REGISTER_FIELDS));
  assert.equal(direct.code, 'UNKNOWN_FIELD');
  assert.equal(direct.status, 400);
  const viaRegister = thrown(() => validateRegisterInput({ username: 'alice', password: PW8, role: 'admin' }));
  assert.equal(viaRegister.code, 'UNKNOWN_FIELD');
  const viaLogin = thrown(() => validateLoginInput({ username: 'alice', password: PW8, token: 't' }));
  assert.equal(viaLogin.code, 'UNKNOWN_FIELD');
});

test('validate: valid credentials return the original username plus the lowercase key', () => {
  const result = validateCredentialsBody({ username: 'Alice', password: PW8 });
  assert.equal(result.username, 'Alice');
  assert.equal(result.usernameLower, 'alice');
  assert.equal(result.password, PW8);
});

test('validate AC-07/AC-08: invalid username or password shapes return 400 VALIDATION_ERROR', () => {
  const cases = [
    { username: 'ab', password: PW8 },
    { username: 'a b', password: PW8 },
    { username: CJK, password: PW8 },
    { username: 'z'.repeat(33), password: PW8 },
    { username: 'alice', password: PW7 },
    { username: 'alice', password: PW73 },
    { username: 'alice' },
    { password: PW8 },
  ];
  for (const body of cases) {
    const error = thrown(() => validateCredentialsBody(body));
    assert.equal(error && error.code, 'VALIDATION_ERROR', JSON.stringify(body));
    assert.equal(error.status, 400);
  }
});

test('validate: rejected input is never echoed back in the error message', () => {
  const error = thrown(() => validateCredentialsBody({ username: 'bad user <script>', password: PW7 }));
  assert.equal(error.code, 'VALIDATION_ERROR');
  assert.equal(error.message.includes('script'), false);
});

test('validate: parseJsonBody maps an unreadable/malformed body to VALIDATION_ERROR', async () => {
  const error = await parseJsonBody(makeFakeRequest({ method: 'POST', body: '{oops' })).then(
    () => null,
    (value) => value
  );
  assert.equal(error.code, 'VALIDATION_ERROR');
  assert.equal(error.status, 400);
  const body = '{"username":"alice","password":"' + PW8 + '"}';
  const good = await parseJsonBody(makeFakeRequest({ method: 'POST', body }));
  assert.deepEqual(good, { username: 'alice', password: PW8 });
});

test('errors AC: handleError always yields the strict { error: { code, message } } envelope', () => {
  const mapped = handleError(new AppError('USERNAME_TAKEN'));
  assert.equal(mapped.status, 409);
  assert.deepEqual(Object.keys(mapped.body), ['error']);
  assert.deepEqual(Object.keys(mapped.body.error), ['code', 'message']);
  assert.equal(mapped.body.error.code, 'USERNAME_TAKEN');
  for (const code of ['VALIDATION_ERROR', 'UNKNOWN_FIELD', 'UNAUTHORIZED', 'INVALID_CREDENTIALS', 'NOT_FOUND']) {
    const entry = handleError(new AppError(code));
    assert.deepEqual(Object.keys(entry.body.error), ['code', 'message']);
  }
});

test('errors AC: status codes match the code map and stray codes are refused', () => {
  const expected = {
    VALIDATION_ERROR: 400,
    UNKNOWN_FIELD: 400,
    UNAUTHORIZED: 401,
    INVALID_CREDENTIALS: 401,
    NOT_FOUND: 404,
    USERNAME_TAKEN: 409,
  };
  for (const [code, status] of Object.entries(expected)) {
    assert.equal(handleError(new AppError(code)).status, status, code);
    assert.equal(API_ERROR_CODES.includes(code), true, code);
  }
  assert.equal(errorFor('NOT_A_CODE').code, 'INTERNAL_ERROR');
  assert.equal(handleError(errorFor('NOT_A_CODE')).status, 500);
});

test('errors AC: unexpected exceptions leak neither stack nor detail', () => {
  const leaked = new Error('boom ' + 'value');
  leaked.stack = 'Error: boom at somewhere';
  const mapped = handleError(leaked);
  assert.equal(mapped.status, 500);
  assert.deepEqual(mapped.body, { error: { code: 'INTERNAL_ERROR', message: 'Internal server error' } });
  const text = JSON.stringify(mapped.body);
  assert.equal(text.includes('boom'), false);
  assert.equal(text.includes('at '), false);
  assert.equal(text.includes('stack'), false);
  for (const value of [null, undefined, 42, 'plain string', Symbol('s')]) {
    const safe = handleError(value);
    assert.equal(safe.status, 500);
    assert.equal(safe.body.error.code, 'INTERNAL_ERROR');
  }
});

test('errors AC: a JSON error response keeps Content-Type application/json', () => {
  const res = makeFakeResponse();
  sendError(res, new AppError('VALIDATION_ERROR'));
  assert.match(String(res.state.headers['content-type']), /application\/json/);
  assert.equal(res.state.status, 400);
  const parsed = JSON.parse(res.state.body);
  assert.deepEqual(Object.keys(parsed), ['error']);
  assert.deepEqual(Object.keys(parsed.error), ['code', 'message']);
});
